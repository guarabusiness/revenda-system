"""Utilidades para enriquecer os eventos de estatística (StatEvent) com
informações sobre dispositivo, navegador, origem do tráfego e país —
tudo calculado localmente, sem depender de nenhum serviço externo:

- Dispositivo/navegador: parsing simples do cabeçalho User-Agent.
- Origem do tráfego: classificação do `document.referrer` enviado pelo
  navegador (Instagram, Facebook, WhatsApp, Google, TikTok, direto, outro).
- País: biblioteca `geoip2fast`, que já vem com uma base de dados própria
  embutida no pacote (não precisa de internet, conta ou chave de API).
  Ela só resolve o país — estado/cidade exigiriam uma base paga (ex.:
  MaxMind GeoLite2 City com licença), que não está incluída aqui.
"""
import re

try:
    from geoip2fast import GeoIP2Fast
    _geoip = GeoIP2Fast()
except Exception:  # pragma: no cover - biblioteca ausente/erro ao carregar a base
    _geoip = None


# ---------------------------------------------------------------------------
# Dispositivo e navegador (a partir do User-Agent)
# ---------------------------------------------------------------------------

def parse_user_agent(ua):
    """Retorna (device_type, browser) a partir da string de User-Agent.
    device_type: 'mobile' | 'tablet' | 'desktop'
    browser: nome curto do navegador/app (Chrome, Safari, Firefox, Edge,
    Samsung Internet, Opera, Instagram, Facebook, Outro)
    """
    ua = ua or ""
    ua_l = ua.lower()

    # Apps que abrem links num navegador embutido (in-app browser) —
    # identificamos antes dos navegadores "de verdade" porque eles também
    # costumam conter "Safari"/"Chrome" na string.
    if "instagram" in ua_l:
        browser = "Instagram"
    elif "fban" in ua_l or "fbav" in ua_l or "fb_iab" in ua_l:
        browser = "Facebook"
    elif "whatsapp" in ua_l:
        browser = "WhatsApp"
    elif "edg/" in ua_l or "edga/" in ua_l or "edgios/" in ua_l:
        browser = "Edge"
    elif "samsungbrowser" in ua_l:
        browser = "Samsung Internet"
    elif "opr/" in ua_l or "opera" in ua_l:
        browser = "Opera"
    elif "firefox" in ua_l or "fxios" in ua_l:
        browser = "Firefox"
    elif "crios" in ua_l or ("chrome" in ua_l and "chromium" not in ua_l):
        browser = "Chrome"
    elif "chromium" in ua_l:
        browser = "Chromium"
    elif "safari" in ua_l:
        browser = "Safari"
    elif ua_l:
        browser = "Outro"
    else:
        browser = None

    if "ipad" in ua_l or ("tablet" in ua_l and "mobile" not in ua_l) or "android" in ua_l and "mobile" not in ua_l:
        device_type = "tablet"
    elif "mobi" in ua_l or "iphone" in ua_l or "ipod" in ua_l or ("android" in ua_l and "mobile" in ua_l):
        device_type = "mobile"
    elif ua_l:
        device_type = "desktop"
    else:
        device_type = None

    return device_type, browser


# ---------------------------------------------------------------------------
# Origem do tráfego (a partir do document.referrer)
# ---------------------------------------------------------------------------

_SOURCE_HOST_MAP = (
    ("instagram.com", "instagram"),
    ("facebook.com", "facebook"),
    ("fb.com", "facebook"),
    ("l.facebook.com", "facebook"),
    ("whatsapp.com", "whatsapp"),
    ("wa.me", "whatsapp"),
    ("tiktok.com", "tiktok"),
    ("google.", "google"),
    ("bing.com", "bing"),
    ("yahoo.", "yahoo"),
    ("duckduckgo.com", "duckduckgo"),
)

TRAFFIC_SOURCE_LABELS = {
    "instagram": "Instagram",
    "facebook": "Facebook",
    "whatsapp": "WhatsApp",
    "tiktok": "TikTok",
    "google": "Google",
    "bing": "Bing",
    "yahoo": "Yahoo",
    "duckduckgo": "DuckDuckGo",
    "direct": "Acesso direto",
    "other": "Outros sites",
}


def classify_referrer(referrer_url, current_host=None):
    """Retorna (referrer_host, traffic_source) a partir da URL de referrer
    enviada pelo navegador (document.referrer). Sem referrer (ou vindo do
    próprio domínio da loja) conta como acesso direto."""
    if not referrer_url:
        return None, "direct"

    match = re.search(r"^https?://([^/]+)", referrer_url.strip(), re.IGNORECASE)
    if not match:
        return None, "direct"

    host = match.group(1).lower()
    host = host.split(":")[0]  # remove porta, se houver
    bare_host = host[4:] if host.startswith("www.") else host

    if current_host and bare_host == current_host.lower().split(":")[0].removeprefix("www."):
        return None, "direct"

    for needle, source in _SOURCE_HOST_MAP:
        if needle in host:
            return host[:255], source

    return host[:255], "other"


# ---------------------------------------------------------------------------
# País por IP (100% local — sem chamada externa)
# ---------------------------------------------------------------------------

def lookup_country(ip_address):
    """Retorna (country_code, country_name) para o IP informado, ou
    (None, None) se não for possível (IP privado/local, base indisponível,
    ou IP não encontrado)."""
    if not ip_address or _geoip is None:
        return None, None
    try:
        result = _geoip.lookup(ip_address)
    except Exception:
        return None, None
    if not result or getattr(result, "is_private", False):
        return None, None
    code = (getattr(result, "country_code", "") or "").strip()
    name = (getattr(result, "country_name", "") or "").strip()
    if not code:
        return None, None
    return code[:2], (name[:80] or None)


def client_ip_from_request(request):
    """Extrai o IP "real" do visitante, considerando proxy reverso
    (Caddy/Nginx) na frente do Flask — usa o primeiro IP de
    X-Forwarded-For quando presente, senão request.remote_addr."""
    forwarded = request.headers.get("X-Forwarded-For", "")
    if forwarded:
        first = forwarded.split(",")[0].strip()
        if first:
            return first
    return request.remote_addr
