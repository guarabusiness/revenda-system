from datetime import datetime, timedelta, timezone

from flask import Blueprint, render_template, request, redirect, url_for, flash, abort, session, g
from flask_login import login_user, logout_user, current_user, login_required

from .models import db, Tenant, SuperAdmin, Plan, Subscription, Order, Customer, StatEvent

superadmin_bp = Blueprint("superadmin", __name__, url_prefix="/superadmin")


def _is_superadmin():
    return current_user.is_authenticated and isinstance(current_user, SuperAdmin)


@superadmin_bp.before_request
def _guard():
    if request.endpoint == "superadmin.login":
        return None
    if not _is_superadmin():
        return redirect(url_for("superadmin.login"))
    return None


@superadmin_bp.route("/login", methods=["GET", "POST"])
def login():
    if _is_superadmin():
        return redirect(url_for("superadmin.dashboard"))
    if request.method == "GET":
        return render_template("superadmin/login.html")

    email = (request.form.get("email") or "").strip().lower()
    password = request.form.get("password") or ""
    admin = SuperAdmin.query.filter_by(email=email).first()
    if not admin or not admin.check_password(password):
        flash("E-mail ou senha inválidos.", "error")
        return render_template("superadmin/login.html", email=email)

    login_user(admin)
    return redirect(url_for("superadmin.dashboard"))


@superadmin_bp.get("/logout")
def logout():
    logout_user()
    return redirect(url_for("superadmin.login"))


@superadmin_bp.get("/")
def dashboard():
    since = datetime.now(timezone.utc) - timedelta(days=30)
    total_tenants = Tenant.query.count()
    active_tenants = Tenant.query.filter_by(active=True).count()
    total_orders_30d = Order.query.filter(Order.created_at >= since).count()
    total_customers = Customer.query.count()
    recent_tenants = Tenant.query.order_by(Tenant.created_at.desc()).limit(8).all()
    return render_template(
        "superadmin/dashboard.html",
        total_tenants=total_tenants,
        active_tenants=active_tenants,
        total_orders_30d=total_orders_30d,
        total_customers=total_customers,
        recent_tenants=recent_tenants,
    )


@superadmin_bp.get("/lojas")
def tenants_list():
    search = (request.args.get("q") or "").strip()
    query = Tenant.query
    if search:
        query = query.filter(db.or_(Tenant.store_name.ilike(f"%{search}%"), Tenant.slug.ilike(f"%{search}%")))
    tenants = query.order_by(Tenant.created_at.desc()).limit(300).all()
    return render_template("superadmin/tenants_list.html", tenants=tenants, search=search)


@superadmin_bp.get("/lojas/<tenant_id>")
def tenant_detail(tenant_id):
    tenant = Tenant.query.get(tenant_id)
    if not tenant:
        abort(404)
    subscription = Subscription.query.filter_by(tenant_id=tenant.id).first()
    plans = Plan.query.order_by(Plan.sort_order).all()
    orders_count = Order.query.filter_by(tenant_id=tenant.id).count()
    customers_count = Customer.query.filter_by(tenant_id=tenant.id).count()
    return render_template(
        "superadmin/tenant_detail.html",
        tenant=tenant, subscription=subscription, plans=plans,
        orders_count=orders_count, customers_count=customers_count,
    )


@superadmin_bp.post("/lojas/<tenant_id>/status")
def tenant_toggle_active(tenant_id):
    tenant = Tenant.query.get(tenant_id)
    if not tenant:
        abort(404)
    tenant.active = not tenant.active
    db.session.commit()
    flash(f"Loja {'ativada' if tenant.active else 'desativada'}.", "success")
    return redirect(url_for("superadmin.tenant_detail", tenant_id=tenant_id))


@superadmin_bp.post("/lojas/<tenant_id>/assinatura")
def tenant_update_subscription(tenant_id):
    tenant = Tenant.query.get(tenant_id)
    if not tenant:
        abort(404)
    plan_id = request.form.get("plan_id") or None
    status = request.form.get("status") or "trial"

    sub = Subscription.query.filter_by(tenant_id=tenant.id).first()
    if not sub:
        sub = Subscription(tenant_id=tenant.id)
        db.session.add(sub)
    sub.plan_id = plan_id
    sub.status = status
    db.session.commit()
    flash("Assinatura atualizada.", "success")
    return redirect(url_for("superadmin.tenant_detail", tenant_id=tenant_id))


# ---------------------------------------------------------------------------
# Planos
# ---------------------------------------------------------------------------

@superadmin_bp.get("/planos")
def plans_list():
    plans = Plan.query.order_by(Plan.sort_order).all()
    return render_template("superadmin/plans_list.html", plans=plans)


@superadmin_bp.post("/planos")
def plan_create():
    code = (request.form.get("code") or "").strip().lower()
    name = (request.form.get("name") or "").strip()
    if not code or not name:
        flash("Informe código e nome do plano.", "error")
        return redirect(url_for("superadmin.plans_list"))
    if Plan.query.filter_by(code=code).first():
        flash("Já existe um plano com esse código.", "error")
        return redirect(url_for("superadmin.plans_list"))

    try:
        price_cents = int(round(float(request.form.get("price") or 0) * 100))
    except ValueError:
        price_cents = 0
    max_products = request.form.get("max_products") or None
    max_orders = request.form.get("max_orders_per_month") or None

    plan = Plan(
        code=code,
        name=name,
        price_cents=price_cents,
        max_products=int(max_products) if max_products else None,
        max_orders_per_month=int(max_orders) if max_orders else None,
        sort_order=Plan.query.count(),
    )
    db.session.add(plan)
    db.session.commit()
    flash("Plano criado.", "success")
    return redirect(url_for("superadmin.plans_list"))


@superadmin_bp.post("/planos/<plan_id>/toggle")
def plan_toggle(plan_id):
    plan = Plan.query.get(plan_id)
    if not plan:
        abort(404)
    plan.active = not plan.active
    db.session.commit()
    return redirect(url_for("superadmin.plans_list"))
