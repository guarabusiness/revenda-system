"""
Endpoint interno consultado pelo proxy reverso (Caddy) antes de emitir um
certificado HTTPS sob demanda para um domínio (Let's Encrypt / ACME).

Sem esse "portão", qualquer domínio (mesmo um que nunca pertenceu a nenhuma
loja) que alguém apontasse via DNS para o IP deste servidor faria o Caddy
tentar emitir certificado para ele — o que desperdiça as chamadas (com limite
por semana) da Let's Encrypt e pode até derrubar a emissão de certificados
para os domínios legítimos das lojas.

Este blueprint responde 200 OK apenas quando o host pedido corresponde a:
  - um Tenant.custom_domain ativo (com ou sem o prefixo "www.");
  - ou um subdomínio "<slug>.BASE_DOMAIN" de um Tenant ativo (se BASE_DOMAIN
    estiver configurado).
Qualquer outro host recebe 404, e o Caddy nunca chega a pedir certificado
para ele.

Não expõe nenhum dado — só 200/404 — então é seguro deixar acessível
publicamente (o Caddy chama via loopback/rede interna, mas não há problema
se for alcançável de fora também).
"""

import os

from flask import Blueprint, request, abort

from .models import Tenant

domain_check_bp = Blueprint("domain_check", __name__)


def _is_allowed_host(host: str) -> bool:
    host = (host or "").strip().lower()
    if not host:
        return False

    # aceita tanto "minhaloja.com.br" quanto "www.minhaloja.com.br" quando
    # o dono da loja cadastrou só a versão sem "www." (ou vice-versa)
    bare_host = host[4:] if host.startswith("www.") else host
    www_host = "www." + bare_host

    match = Tenant.query.filter(
        Tenant.active.is_(True),
        Tenant.custom_domain.in_([bare_host, www_host]),
    ).first()
    if match:
        return True

    base_domain = os.environ.get("BASE_DOMAIN", "").strip().lower()
    if base_domain:
        bare_base = base_domain[4:] if base_domain.startswith("www.") else base_domain
        if bare_host in (bare_base, "www." + bare_base):
            return True
        if bare_host.endswith("." + bare_base):
            slug = bare_host[: -(len(bare_base) + 1)]
            if slug and Tenant.query.filter_by(slug=slug, active=True).first():
                return True

    return False


@domain_check_bp.get("/internal/domain-check")
def domain_check():
    # Caddy's on_demand_tls "ask" manda o domínio requisitado como querystring
    # `?domain=`. Qualquer coisa diferente disso (ex.: alguém abrindo a URL
    # direto no navegador sem esse parâmetro) simplesmente não bate com nada.
    host = request.args.get("domain", "")
    if _is_allowed_host(host):
        return "", 200
    abort(404)
