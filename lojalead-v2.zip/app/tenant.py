import re
from datetime import datetime, timezone

from flask import Blueprint, render_template, request, redirect, url_for, flash, abort, jsonify, session, g
from flask_login import login_user, current_user

from .models import db, Tenant, TenantUser, Document, Customer, Order, new_id
from .password_reset import (
    generate_reset_token,
    find_user_for_token,
    clear_reset_token,
    send_reset_email,
    mail_is_configured,
)

tenant_bp = Blueprint("tenant", __name__)

SLUG_RE = re.compile(r"^[a-z0-9](?:[a-z0-9-]{1,48}[a-z0-9])?$")

def build_default_settings(store_name: str, owner_email: str) -> dict:
    """Monta o bloco settings/system inicial para uma loja recém-criada."""
    return {
        "name": store_name,
        "slogan": "A melhor opção da região",
        "description": "Sistema completo de controle de inventário e gestão de produtos para sua empresa.",
        "currency": "R$",
        "timezone": "America/Sao_Paulo",
        "heroTitle": f"{store_name}",
        "heroSubtitle": "Para quem busca variedade, bom atendimento e uma experiência de compra prática e confiável.",
        "heroBtnText": "Ver Produtos",
        "contactEmail": owner_email,
        "contactPhone": "",
        "contactAddress": "",
        "whatsappNumber": "",
        "showMap": False,
        "mapIframe": "",
        "footerCopyright": f"{store_name} - Todos os direitos reservados",
        "footerFacebook": "",
        "footerInstagram": "",
        "footerBusinessHours": "Segunda a Sexta: 8h às 18h | Sábado: 8h às 12h",
        "showStockStatus": False,
        "hideProductBrand": False,
        "hideViewProductBtn": True,
        "showCategoriesSidebar": True,
        "enableSearch": True,
        "enableCart": True,
        "enableFreeShipping": False,
        "viewProductText": "Ver Produto",
        "desktopColumns": "auto",
        "mobileColumns": "2",
        "itemsPerPage": 12,
        "backupFrequency": "weekly",
        # Modo de exibição do catálogo (grade / lista / cardápio / compacto).
        # Puramente visual — não depende de segmento/tipo de negócio, o admin
        # troca livremente em Configurações > Catálogo.
        "catalogLayout": "grid",
        # Banner de aviso no topo (liga/desliga + texto livre)
        "topBannerEnabled": False,
        "topBannerText": "",
        # Ordenação padrão do catálogo
        "catalogSortDefault": "relevance",
        # Valor mínimo para Frete Grátis (complementa o toggle enableFreeShipping)
        "freeShippingMinValue": 0,
        # Redes sociais extras no rodapé
        "footerTiktok": "",
        "footerYoutube": "",
        # Imagem de fundo customizada do banner
        "heroBackgroundImage": "",
        "heroBackgroundImageDeleteHash": "",
    }



def slugify(text: str) -> str:
    text = text.strip().lower()
    text = re.sub(r"[^a-z0-9]+", "-", text)
    text = re.sub(r"-{2,}", "-", text).strip("-")
    return text[:50] or "loja"


def build_demo_products(category_name: str) -> list:
    """10 produtos de exemplo (título, preço, descrição, imagem real
    correspondente) para que toda loja nova já abra com um catálogo
    populado em vez de vazio. O admin pode editar/excluir cada um depois."""
    img = lambda photo_id: (
        f"https://images.unsplash.com/{photo_id}"
        "?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
    )
    return [
        dict(
            title="Fone de Ouvido Bluetooth",
            price=129.90, oldPrice=179.90,
            description="Fone de ouvido sem fio com Bluetooth 5.0, cancelamento de ruído "
                         "e até 20 horas de bateria. Ideal para música, jogos e ligações.",
            stock=24, brand="SoundMax", freeShipping=True,
            imageUrls=[img("photo-1505740420928-5e560c06d30e")],
        ),
        dict(
            title="Tênis Esportivo Casual",
            price=219.90, oldPrice=None,
            description="Tênis leve e confortável para caminhada e uso do dia a dia, "
                         "com solado emborrachado antiderrapante e cabedal respirável.",
            stock=15, brand="RunFit", freeShipping=False,
            imageUrls=[img("photo-1669671943625-e20799ee5f42")],
        ),
        dict(
            title="Mochila de Couro Sintético",
            price=159.90, oldPrice=199.90,
            description="Mochila espaçosa em couro sintético, com compartimento "
                         "acolchoado para notebook até 15\" e bolsos internos organizadores.",
            stock=10, brand="UrbanPack", freeShipping=True,
            imageUrls=[img("photo-1622560480605-d83c853bc5c3")],
        ),
        dict(
            title="Smartwatch Esportivo",
            price=249.90, oldPrice=299.90,
            description="Relógio inteligente com monitor de frequência cardíaca, "
                         "contador de passos, notificações do celular e resistência à água.",
            stock=18, brand="TechFit", freeShipping=True,
            imageUrls=[img("photo-1551816230-ef5deaed4a26")],
        ),
        dict(
            title="Camiseta Básica Branca",
            price=39.90, oldPrice=None,
            description="Camiseta 100% algodão, corte tradicional e caimento confortável. "
                         "Peça essencial para o guarda-roupa do dia a dia.",
            stock=40, brand="Basics", freeShipping=False,
            imageUrls=[img("photo-1620799139507-2a76f79a2f4d")],
        ),
        dict(
            title="Cafeteira Elétrica",
            price=189.90, oldPrice=229.90,
            description="Cafeteira elétrica com capacidade para 750ml, desligamento "
                         "automático e filtro reutilizável. Prepara seu café rapidamente.",
            stock=8, brand="CasaBrew", freeShipping=True,
            imageUrls=[img("photo-1607273177127-47ec33b5be3f")],
        ),
        dict(
            title="Perfume Eau de Parfum 100ml",
            price=99.90, oldPrice=139.90,
            description="Fragrância marcante e duradoura, frasco de 100ml. "
                         "Ideal para uso diário ou ocasiões especiais.",
            stock=20, brand="Essence", freeShipping=False,
            imageUrls=[img("photo-1619352704218-ab07491b9353")],
        ),
        dict(
            title="Mouse Gamer RGB",
            price=79.90, oldPrice=99.90,
            description="Mouse gamer com iluminação RGB, sensor de alta precisão "
                         "e botões programáveis. Ótimo custo-benefício para jogos.",
            stock=30, brand="PlayTech", freeShipping=True,
            imageUrls=[img("photo-1616296425622-4560a2ad83de")],
        ),
        dict(
            title="Kit de Panelas Antiaderente",
            price=169.90, oldPrice=219.90,
            description="Kit de panelas com revestimento antiaderente, cabos "
                         "ergonômicos e distribuição uniforme de calor.",
            stock=6, brand="CozinhaPro", freeShipping=True,
            imageUrls=[img("photo-1584990347784-da6aaa2a4bbb")],
        ),
        dict(
            title="Bicicleta Aro 29",
            price=899.90, oldPrice=1099.90,
            description="Bicicleta aro 29 com quadro em alumínio, 21 marchas e freios "
                         "a disco. Perfeita para trilhas e uso urbano.",
            stock=4, brand="TrailBike", freeShipping=False,
            imageUrls=[img("photo-1495641417672-bf711cb4365b")],
        ),
    ]


def _seed_default_documents(tenant: Tenant, owner_email: str, store_name: str):
    """Cria as configurações padrão (settings/system e settings/theme), uma
    categoria de exemplo ("teste") e 10 produtos de demonstração para que a
    loja nova já funcione com uma vitrine válida e populada, sem precisar
    que o JS crie os documentos (isso só acontecia quando havia um admin
    logado). Tudo pode ser trocado/excluído depois pelo admin em
    Configurações e no painel de produtos/categorias."""
    system_doc = Document(
        tenant_id=tenant.id,
        collection="settings",
        doc_id="system",
        data=build_default_settings(store_name, owner_email),
    )
    theme_doc = Document(
        tenant_id=tenant.id,
        collection="settings",
        doc_id="theme",
        data={"theme": "light", "darkMode": False},
    )
    db.session.add_all([system_doc, theme_doc])

    # Categoria pré-pronta "teste" (o admin pode renomear/excluir depois).
    category_name = "teste"
    now_iso = datetime.now(timezone.utc).isoformat()
    category_doc = Document(
        tenant_id=tenant.id,
        collection="categories",
        doc_id=new_id(),
        data={"name": category_name, "createdAt": now_iso},
    )
    db.session.add(category_doc)

    # 10 produtos de demonstração, todos na categoria "teste".
    for product in build_demo_products(category_name):
        product_id = new_id()
        product_doc = Document(
            tenant_id=tenant.id,
            collection="products",
            doc_id=product_id,
            data={
                "title": product["title"],
                "price": product["price"],
                "oldPrice": product["oldPrice"],
                "category": category_name,
                "description": product["description"],
                "stock": product["stock"],
                "stockStatus": "in-stock" if product["stock"] > 5 else "low-stock",
                "brand": product["brand"],
                "freeShipping": product["freeShipping"],
                "imageUrls": product["imageUrls"],
                "imageDeleteHashes": [],
                "productId": product_id,
                "createdAt": now_iso,
            },
        )
        db.session.add(product_doc)


def _platform_stats():
    """Números reais da plataforma (contagem simples no banco) exibidos nas
    telas de autenticação: pedidos recebidos via WhatsApp, clientes
    cadastrados e lojas ativas. Falha de forma silenciosa (retorna zeros)
    caso o banco ainda não tenha sido migrado."""
    try:
        return {
            "orders": Order.query.count(),
            "customers": Customer.query.count(),
            "stores": Tenant.query.filter_by(active=True).count(),
        }
    except Exception:
        return {"orders": 0, "customers": 0, "stores": 0}


@tenant_bp.get("/")
def landing():
    domain_tenant = getattr(g, "domain_tenant", None)
    if domain_tenant:
        return _render_storefront(domain_tenant)
    return render_template("signup.html", stats=_platform_stats())


@tenant_bp.get("/signup/check-slug")
def check_slug():
    """Consulta em tempo real (chamada pelo JS da tela de cadastro) se o
    endereço da loja gerado a partir do nome digitado já está em uso."""
    raw = (request.args.get("name") or "").strip()
    slug = slugify(raw)
    if not raw or not SLUG_RE.match(slug):
        return jsonify({"available": False, "slug": slug, "invalid": True})
    taken = Tenant.query.filter_by(slug=slug).first() is not None
    return jsonify({"available": not taken, "slug": slug, "invalid": False})


@tenant_bp.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "GET":
        return render_template("signup.html", stats=_platform_stats())

    store_name = (request.form.get("store_name") or "").strip()
    slug = slugify(request.form.get("slug") or store_name)
    email = (request.form.get("email") or "").strip().lower()
    password = request.form.get("password") or ""

    errors = []
    if not store_name:
        errors.append("Informe o nome da loja.")
    if not SLUG_RE.match(slug):
        errors.append("URL da loja inválida. Use apenas letras, números e hífen.")
    if not email or "@" not in email:
        errors.append("Informe um e-mail válido.")
    if len(password) < 6:
        errors.append("A senha deve ter pelo menos 6 caracteres.")
    if Tenant.query.filter_by(slug=slug).first():
        errors.append("Essa URL de loja já está em uso. Escolha outra.")

    if errors:
        for e in errors:
            flash(e, "error")
        return render_template(
            "signup.html",
            store_name=store_name,
            slug=slug,
            email=email,
            stats=_platform_stats(),
        )

    tenant = Tenant(slug=slug, store_name=store_name)
    db.session.add(tenant)
    db.session.flush()  # garante tenant.id antes de usar em FKs

    owner = TenantUser(tenant_id=tenant.id, email=email)
    owner.set_password(password)
    db.session.add(owner)

    _seed_default_documents(tenant, email, store_name)

    db.session.commit()

    login_user(owner)
    flash("Loja criada com sucesso! Cadastre seus produtos e comece a vender.", "success")
    return redirect(url_for("orders_admin.stats", slug=slug))


@tenant_bp.get("/entrar")
def login_landing():
    """Página de login genérica (sem loja pré-definida): informa apenas
    e-mail + senha (a loja é encontrada automaticamente pelo e-mail).
    Usada a partir da landing/signup."""
    return render_template("login.html", tenant=None, stats=_platform_stats())


@tenant_bp.post("/auth/login-email")
def login_by_email():
    """Login sem informar o endereço/nome da loja: procura a loja do
    usuário pelo e-mail cadastrado (dono geralmente tem conta em uma só
    loja) e autentica direto, sem exigir o slug no formulário."""
    payload = request.get_json(silent=True) or {}
    email = (payload.get("email") or "").strip().lower()
    password = payload.get("password") or ""

    if not email or not password:
        return jsonify({"error": "Informe e-mail e senha."}), 400

    candidates = (
        TenantUser.query.join(Tenant, TenantUser.tenant_id == Tenant.id)
        .filter(TenantUser.email == email, Tenant.active.is_(True))
        .all()
    )
    for user in candidates:
        if user.check_password(password):
            login_user(user)
            session["tenant_id"] = user.tenant_id
            return jsonify({"slug": user.tenant.slug})

    return jsonify({"error": "E-mail ou senha inválidos."}), 401


@tenant_bp.get("/loja/<slug>/login")
def login_page(slug):
    """Página de login já vinculada a uma loja específica (slug fixo)."""
    tenant = Tenant.query.filter_by(slug=slug, active=True).first()
    if not tenant:
        abort(404)
    return render_template("login.html", tenant=tenant, stats=_platform_stats())


@tenant_bp.get("/loja/<slug>")
def storefront(slug):
    tenant = Tenant.query.filter_by(slug=slug, active=True).first()
    if not tenant:
        abort(404)
    return _render_storefront(tenant)


def _render_storefront(tenant):
    """Renderiza a vitrine com metadados de SEO calculados no servidor
    (title/description/OG), já que crawlers nem sempre executam o JS que
    monta esses campos a partir das settings."""
    settings_doc = Document.query.filter_by(
        tenant_id=tenant.id, collection="settings", doc_id="system"
    ).first()
    settings = (settings_doc.data if settings_doc else {}) or {}

    theme_doc = Document.query.filter_by(
        tenant_id=tenant.id, collection="settings", doc_id="theme"
    ).first()
    theme_data = (theme_doc.data if theme_doc else {}) or {}
    theme_id = theme_data.get("theme") or "light"
    dark_mode = bool(theme_data.get("darkMode"))
    body_theme_classes = f"theme-{theme_id}"
    if dark_mode and theme_id != "dark":
        body_theme_classes += " theme-dark"

    # Se quem está abrindo a página já é o admin logado desta loja (sessão
    # restaurada pelo cookie), renderiza direto no modo painel — sem isso,
    # a página nasce como vitrine pública e só vira painel depois que o JS
    # confirma a sessão (fetch assíncrono), causando um flash da vitrine
    # (com a cor do tema real da loja) antes do painel aparecer.
    is_preview = request.args.get("preview") == "1"
    if (
        not is_preview
        and current_user.is_authenticated
        and getattr(current_user, "tenant_id", None) == tenant.id
    ):
        body_theme_classes += " admin-mode"

    seo = {
        "title": tenant.seo_title or settings.get("name") or tenant.store_name,
        "description": (
            tenant.seo_description
            or settings.get("description")
            or f"Confira os produtos de {tenant.store_name}."
        )[:300],
        "keywords": tenant.seo_keywords or "",
        "og_image": tenant.seo_og_image or settings.get("heroBackgroundImage") or "",
    }
    return render_template("storefront.html", tenant=tenant, seo=seo, body_theme_classes=body_theme_classes)


@tenant_bp.get("/loja/<slug>/sitemap.xml")
def sitemap(slug):
    """Sitemap simples da loja: página inicial + uma entrada por produto,
    para ajudar mecanismos de busca a indexar o catálogo."""
    tenant = Tenant.query.filter_by(slug=slug, active=True).first()
    if not tenant:
        abort(404)
    base_url = url_for("tenant.storefront", slug=slug, _external=True)
    products = Document.query.filter_by(tenant_id=tenant.id, collection="products").all()
    urls = [base_url] + [f"{base_url}?produto={p.doc_id}" for p in products]
    xml = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for u in urls:
        xml.append(f"<url><loc>{u}</loc></url>")
    xml.append("</urlset>")
    return "\n".join(xml), 200, {"Content-Type": "application/xml"}


@tenant_bp.get("/loja/<slug>/robots.txt")
def robots(slug):
    tenant = Tenant.query.filter_by(slug=slug, active=True).first()
    if not tenant:
        abort(404)
    sitemap_url = url_for("tenant.sitemap", slug=slug, _external=True)
    body = f"User-agent: *\nAllow: /\nSitemap: {sitemap_url}\n"
    return body, 200, {"Content-Type": "text/plain"}


# ---------------------------------------------------------------------------
# Recuperação de senha ("esqueci minha senha")
# ---------------------------------------------------------------------------

@tenant_bp.route("/esqueci-senha", methods=["GET", "POST"])
def forgot_password_generic():
    """Versão genérica (sem slug na URL): usada a partir da página /entrar,
    quando o visitante ainda não está numa loja específica."""
    prefill_slug = (request.args.get("slug") or "").strip().lower()
    if request.method == "GET":
        return render_template("forgot_password.html", tenant=None, prefill_slug=prefill_slug)
    slug = (request.form.get("slug") or "").strip().lower()
    return _handle_forgot_password(slug, tenant_for_template=None)


@tenant_bp.route("/loja/<slug>/esqueci-senha", methods=["GET", "POST"])
def forgot_password(slug):
    tenant = Tenant.query.filter_by(slug=slug, active=True).first()
    if not tenant:
        abort(404)
    if request.method == "GET":
        return render_template("forgot_password.html", tenant=tenant, prefill_slug=slug)
    return _handle_forgot_password(slug, tenant_for_template=tenant)


def _handle_forgot_password(slug, tenant_for_template):
    tenant = Tenant.query.filter_by(slug=slug, active=True).first()
    email = (request.form.get("email") or "").strip().lower()

    # Sempre mostramos a mesma mensagem de sucesso, exista ou não o e-mail/
    # loja — evita que alguém use este formulário para descobrir se um
    # e-mail está cadastrado em alguma loja.
    generic_success = (
        "Se esse e-mail estiver cadastrado nessa loja, enviamos um link de "
        "redefinição de senha (confira também o spam)."
    )

    user = None
    if tenant and email:
        user = TenantUser.query.filter_by(tenant_id=tenant.id, email=email).first()

    dev_reset_link = None
    if user:
        token = generate_reset_token(user)
        db.session.commit()
        reset_url = url_for("tenant.reset_password", token=token, _external=True)
        sent = send_reset_email(user.email, reset_url, tenant.store_name)
        if not sent:
            # Sem SMTP configurado no servidor: mostramos o link na própria
            # tela (só para uso local/desenvolvimento) em vez de travar o
            # fluxo de quem está testando sem um provedor de e-mail.
            dev_reset_link = reset_url

    flash(generic_success, "success")
    return render_template(
        "forgot_password.html",
        tenant=tenant_for_template,
        prefill_slug=slug,
        submitted=True,
        dev_reset_link=dev_reset_link,
        mail_configured=mail_is_configured(),
    )


@tenant_bp.route("/redefinir-senha/<token>", methods=["GET", "POST"])
def reset_password(token):
    user = find_user_for_token(token, TenantUser)
    if not user:
        flash("Esse link de redefinição é inválido ou já expirou. Solicite um novo.", "error")
        return redirect(url_for("tenant.forgot_password_generic"))

    tenant = Tenant.query.get(user.tenant_id)

    if request.method == "GET":
        return render_template("reset_password.html", tenant=tenant, token=token)

    password = request.form.get("password") or ""
    password_confirm = request.form.get("password_confirm") or ""

    if len(password) < 6:
        flash("A senha deve ter pelo menos 6 caracteres.", "error")
        return render_template("reset_password.html", tenant=tenant, token=token)
    if password != password_confirm:
        flash("As senhas não coincidem.", "error")
        return render_template("reset_password.html", tenant=tenant, token=token)

    user.set_password(password)
    clear_reset_token(user)
    db.session.commit()

    flash("Senha redefinida com sucesso! Faça login com a nova senha.", "success")
    return redirect(url_for("tenant.login_page", slug=tenant.slug))
