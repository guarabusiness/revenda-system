import os
import uuid
from datetime import datetime, timezone

from flask import Blueprint, jsonify, request, session, g, abort, current_app, url_for
from flask_login import login_user, logout_user, current_user, login_required
from werkzeug.utils import secure_filename

from .models import db, Tenant, TenantUser, Document

api_bp = Blueprint("api", __name__, url_prefix="/api/<slug>")

SERVER_TIMESTAMP_SENTINEL = "__SERVER_TIMESTAMP__"

ALLOWED_IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}
MAX_UPLOAD_BYTES = 8 * 1024 * 1024  # 8 MB por imagem


def _resolve_tenant(slug):
    tenant = Tenant.query.filter_by(slug=slug, active=True).first()
    if not tenant:
        abort(404, description="Loja não encontrada")
    g.tenant = tenant
    return tenant


def _current_tenant_matches(tenant):
    """Garante que o usuário logado pertence a este tenant (multi-tenant isolation)."""
    return current_user.is_authenticated and current_user.tenant_id == tenant.id


def _resolve_server_timestamps(data):
    if isinstance(data, dict):
        out = {}
        for k, v in data.items():
            if v == SERVER_TIMESTAMP_SENTINEL:
                out[k] = datetime.now(timezone.utc).isoformat()
            else:
                out[k] = _resolve_server_timestamps(v)
        return out
    if isinstance(data, list):
        return [_resolve_server_timestamps(v) for v in data]
    return data


# ---------------------------------------------------------------------------
# Auth (escopado por loja/tenant)
# ---------------------------------------------------------------------------

@api_bp.post("/auth/login")
def login(slug):
    tenant = _resolve_tenant(slug)
    payload = request.get_json(silent=True) or {}
    email = (payload.get("email") or "").strip().lower()
    password = payload.get("password") or ""

    user = TenantUser.query.filter_by(tenant_id=tenant.id, email=email).first()
    if not user or not user.check_password(password):
        return jsonify({"error": "Email ou senha inválidos"}), 401

    login_user(user)
    session["tenant_id"] = tenant.id
    return jsonify({"uid": user.id, "email": user.email})


@api_bp.post("/auth/logout")
def logout(slug):
    _resolve_tenant(slug)
    logout_user()
    return jsonify({"ok": True})


@api_bp.get("/auth/me")
def me(slug):
    tenant = _resolve_tenant(slug)
    if _current_tenant_matches(tenant):
        return jsonify({"uid": current_user.id, "email": current_user.email})
    return jsonify(None)




@api_bp.post("/auth/change-password")
def change_password(slug):
    """Troca de senha feita de dentro do painel (usuário já logado),
    diferente do fluxo de 'esqueci minha senha': aqui é preciso confirmar a
    senha atual, não um token por e-mail."""
    tenant = _resolve_tenant(slug)
    _require_owner(tenant)

    payload = request.get_json(silent=True) or {}
    current_password = payload.get("current_password") or ""
    new_password = payload.get("new_password") or ""

    if not current_user.check_password(current_password):
        return jsonify({"error": "Senha atual incorreta."}), 400
    if len(new_password) < 6:
        return jsonify({"error": "A nova senha deve ter pelo menos 6 caracteres."}), 400
    if current_user.check_password(new_password):
        return jsonify({"error": "A nova senha precisa ser diferente da atual."}), 400

    current_user.set_password(new_password)
    db.session.commit()
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Documentos genéricos (equivalente a coleções do Firestore)
# ---------------------------------------------------------------------------

@api_bp.get("/docs/<collection>")
def list_docs(slug, collection):
    tenant = _resolve_tenant(slug)
    q = Document.query.filter_by(tenant_id=tenant.id, collection=collection)
    docs = q.all()

    order_by = request.args.get("orderBy")
    direction = request.args.get("dir", "asc")

    results = [d.to_public() for d in docs]

    if order_by:
        def sort_key(item):
            val = item.get(order_by)
            # None/ausente vai para o final, independente da direção
            return (val is None, val if val is not None else "")

        results.sort(key=sort_key, reverse=(direction == "desc"))

    return jsonify(results)


@api_bp.get("/docs/<collection>/<doc_id>")
def get_doc(slug, collection, doc_id):
    tenant = _resolve_tenant(slug)
    doc = Document.query.filter_by(tenant_id=tenant.id, collection=collection, doc_id=doc_id).first()
    if not doc:
        return jsonify({"exists": False, "id": doc_id})
    body = doc.to_public()
    body["exists"] = True
    return jsonify(body)


def _require_owner(tenant):
    if not _current_tenant_matches(tenant):
        abort(403, description="Não autenticado para esta loja")


@api_bp.put("/docs/<collection>/<doc_id>")
def set_doc(slug, collection, doc_id):
    """Equivalente a .doc(id).set(data) do Firestore (upsert, substitui o documento)."""
    tenant = _resolve_tenant(slug)
    _require_owner(tenant)

    payload = _resolve_server_timestamps(request.get_json(silent=True) or {})

    doc = Document.query.filter_by(tenant_id=tenant.id, collection=collection, doc_id=doc_id).first()
    if doc:
        doc.data = payload
    else:
        doc = Document(tenant_id=tenant.id, collection=collection, doc_id=doc_id, data=payload)
        db.session.add(doc)
    db.session.commit()
    return jsonify(doc.to_public())


@api_bp.patch("/docs/<collection>/<doc_id>")
def update_doc(slug, collection, doc_id):
    """Equivalente a .doc(id).update(data) do Firestore (merge parcial)."""
    tenant = _resolve_tenant(slug)
    _require_owner(tenant)

    payload = _resolve_server_timestamps(request.get_json(silent=True) or {})

    doc = Document.query.filter_by(tenant_id=tenant.id, collection=collection, doc_id=doc_id).first()
    if not doc:
        return jsonify({"error": "Documento não existe"}), 404

    merged = dict(doc.data or {})
    merged.update(payload)
    doc.data = merged
    db.session.commit()
    return jsonify(doc.to_public())


@api_bp.delete("/docs/<collection>/<doc_id>")
def delete_doc(slug, collection, doc_id):
    tenant = _resolve_tenant(slug)
    _require_owner(tenant)

    doc = Document.query.filter_by(tenant_id=tenant.id, collection=collection, doc_id=doc_id).first()
    if doc:
        db.session.delete(doc)
        db.session.commit()
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Upload de imagens — armazenado em disco, na própria máquina do servidor.
# Nenhuma imagem é enviada para serviços externos (Firebase, imgBB, etc).
# ---------------------------------------------------------------------------

def _tenant_upload_dir(tenant):
    upload_root = current_app.config["UPLOAD_FOLDER"]
    tenant_dir = os.path.join(upload_root, tenant.slug)
    os.makedirs(tenant_dir, exist_ok=True)
    return tenant_dir


@api_bp.post("/upload")
def upload_image(slug):
    tenant = _resolve_tenant(slug)
    _require_owner(tenant)

    file = request.files.get("image")
    if not file or not file.filename:
        return jsonify({"error": "Nenhuma imagem enviada"}), 400

    ext = secure_filename(file.filename).rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if ext not in ALLOWED_IMAGE_EXTENSIONS:
        return jsonify({"error": "Formato de imagem não suportado"}), 400

    file.seek(0, os.SEEK_END)
    size = file.tell()
    file.seek(0)
    if size > MAX_UPLOAD_BYTES:
        return jsonify({"error": "Imagem muito grande (máximo 8MB)"}), 400

    image_bytes = file.read()

    filename = f"{uuid.uuid4().hex}.{ext}"
    dest_path = os.path.join(_tenant_upload_dir(tenant), filename)
    with open(dest_path, "wb") as f:
        f.write(image_bytes)

    url = url_for("api.serve_upload", slug=slug, filename=filename)
    # "deleteHash" mantém compatibilidade de nome com o fluxo antigo (imgBB);
    # aqui é simplesmente o nome do arquivo salvo no disco.
    return jsonify({"url": url, "deleteHash": filename})


@api_bp.get("/uploads/<path:filename>")
def serve_upload(slug, filename):
    tenant = _resolve_tenant(slug)
    from flask import send_from_directory

    return send_from_directory(_tenant_upload_dir(tenant), filename)


@api_bp.delete("/upload/<path:filename>")
def delete_upload(slug, filename):
    tenant = _resolve_tenant(slug)
    _require_owner(tenant)

    safe_name = secure_filename(filename)
    path = os.path.join(_tenant_upload_dir(tenant), safe_name)
    if os.path.exists(path):
        os.remove(path)
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": "Arquivo não encontrado"}), 404
