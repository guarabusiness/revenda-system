from urllib.parse import quote

from flask import Blueprint, jsonify, request, abort, g

from .models import (
    db, Tenant, Document, Customer, Order, OrderStatusEvent, StatEvent,
    DELIVERY_TYPES,
)
from .traffic_utils import parse_user_agent, classify_referrer, lookup_country, client_ip_from_request

checkout_bp = Blueprint("checkout", __name__, url_prefix="/api/<slug>")


def _resolve_tenant(slug):
    tenant = Tenant.query.filter_by(slug=slug, active=True).first()
    if not tenant:
        abort(404, description="Loja não encontrada")
    g.tenant = tenant
    return tenant


def _whatsapp_number(tenant):
    doc = Document.query.filter_by(tenant_id=tenant.id, collection="settings", doc_id="system").first()
    return ((doc.data or {}).get("whatsappNumber") if doc else "") or ""


def _fmt_brl(value):
    """Formata um número como moeda pt-BR (R$ 1.234,56) sem tocar em texto
    ao redor — nunca aplicar este replace na string inteira."""
    return f"{value:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def format_whatsapp_message(tenant, order, customer):
    """Monta uma mensagem de pedido organizada e legível para o WhatsApp."""
    lines = [f"*Novo pedido #{order.order_number}* — {tenant.store_name}", ""]
    lines.append(f"*Cliente:* {customer.name}")
    lines.append(f"*Telefone:* {customer.phone}")
    lines.append("")
    lines.append("*Itens:*")
    for i, item in enumerate(order.items, start=1):
        qty = item.get("quantity", 1)
        price = float(item.get("price", 0))
        line_total = price * qty
        piece = f"{i}. {item.get('title')} — R$ {_fmt_brl(price)}"
        if qty > 1:
            piece += f" x {qty} = R$ {_fmt_brl(line_total)}"
        lines.append(piece)
    lines.append("")
    lines.append(f"*Subtotal:* R$ {_fmt_brl(order.subtotal)}")
    if order.shipping_fee:
        lines.append(f"*Entrega:* R$ {_fmt_brl(order.shipping_fee)}")
    lines.append(f"*Total:* R$ {_fmt_brl(order.total)}")
    lines.append("")
    if order.delivery_type == "entrega":
        lines.append("*Forma de recebimento:* Entrega")
        if order.delivery_address:
            lines.append(f"*Endereço:* {order.delivery_address}")
    else:
        lines.append("*Forma de recebimento:* Retirada no local")
    if order.payment_method:
        lines.append(f"*Pagamento:* {order.payment_method}")
    if order.notes:
        lines.append(f"*Observações:* {order.notes}")
    lines.append("")
    lines.append(f"Pedido nº {order.order_number}")
    return "\n".join(lines)


@checkout_bp.post("/checkout")
def checkout(slug):
    tenant = _resolve_tenant(slug)
    payload = request.get_json(silent=True) or {}

    items = payload.get("items") or []
    if not isinstance(items, list) or not items:
        return jsonify({"error": "O carrinho está vazio."}), 400

    name = (payload.get("name") or "").strip()
    phone = (payload.get("phone") or "").strip()
    if not name or not phone:
        return jsonify({"error": "Informe nome e telefone para finalizar o pedido."}), 400

    delivery_type = payload.get("deliveryType") or "retirada"
    if delivery_type not in DELIVERY_TYPES:
        delivery_type = "retirada"
    address = (payload.get("address") or "").strip() or None
    if delivery_type == "entrega" and not address:
        return jsonify({"error": "Informe o endereço de entrega."}), 400

    payment_method = (payload.get("paymentMethod") or "").strip() or None
    notes = (payload.get("notes") or "").strip() or None

    subtotal = 0.0
    clean_items = []
    for item in items:
        try:
            price = float(item.get("price", 0))
            qty = max(1, int(item.get("quantity", 1)))
        except (TypeError, ValueError):
            continue
        subtotal += price * qty
        clean_items.append({
            "id": item.get("id"),
            "title": item.get("title") or "Produto",
            "price": price,
            "quantity": qty,
        })
    if not clean_items:
        return jsonify({"error": "O carrinho está vazio."}), 400

    settings_doc = Document.query.filter_by(tenant_id=tenant.id, collection="settings", doc_id="system").first()
    settings = (settings_doc.data or {}) if settings_doc else {}
    shipping_fee = 0.0
    if delivery_type == "entrega" and settings.get("enableFreeShipping"):
        min_value = float(settings.get("freeShippingMinValue") or 0)
        if min_value <= 0 or subtotal < min_value:
            shipping_fee = float(payload.get("shippingFee") or 0)
    elif delivery_type == "entrega":
        shipping_fee = float(payload.get("shippingFee") or 0)

    total = subtotal + shipping_fee

    customer = Customer.query.filter_by(tenant_id=tenant.id, phone=phone).first()
    if customer:
        customer.name = name
        if address and not customer.address:
            customer.address = address
    else:
        customer = Customer(tenant_id=tenant.id, name=name, phone=phone, address=address)
        db.session.add(customer)
        db.session.flush()

    order = Order(
        tenant_id=tenant.id,
        customer_id=customer.id,
        order_number=tenant.next_order_number(),
        status="novo",
        delivery_type=delivery_type,
        delivery_address=address,
        payment_method=payment_method,
        notes=notes,
        items=clean_items,
        subtotal=subtotal,
        shipping_fee=shipping_fee,
        total=total,
    )
    db.session.add(order)
    db.session.flush()

    order.whatsapp_message = format_whatsapp_message(tenant, order, customer)
    db.session.add(OrderStatusEvent(order_id=order.id, status="novo", note="Pedido criado pelo cliente"))
    device_type, browser = parse_user_agent(request.headers.get("User-Agent"))
    country_code, country_name = lookup_country(client_ip_from_request(request))
    db.session.add(StatEvent(
        tenant_id=tenant.id, event_type="order", ref_id=order.id,
        device_type=device_type, browser=browser,
        country_code=country_code, country_name=country_name,
    ))
    db.session.commit()

    number = _whatsapp_number(tenant)
    whatsapp_url = f"https://wa.me/{number}?text={quote(order.whatsapp_message)}" if number else None

    return jsonify({
        "orderId": order.id,
        "orderNumber": order.order_number,
        "message": order.whatsapp_message,
        "whatsappUrl": whatsapp_url,
    })


# ---------------------------------------------------------------------------
# Tracking leve de estatísticas (visitas, visualização de produto, add ao
# carrinho). Chamado via fetch/sendBeacon pelo script.js da vitrine.
# ---------------------------------------------------------------------------

ALLOWED_EVENT_TYPES = {"visit", "product_view", "cart_add", "order", "heartbeat"}


@checkout_bp.post("/stats/track")
def track_event(slug):
    tenant = _resolve_tenant(slug)
    payload = request.get_json(silent=True) or {}
    event_type = payload.get("type")
    if event_type not in ALLOWED_EVENT_TYPES:
        return jsonify({"ok": False}), 400
    ref_id = payload.get("refId")
    visitor_id = (payload.get("visitorId") or "")[:40] or None

    device_type, browser = parse_user_agent(request.headers.get("User-Agent"))
    referrer_host, traffic_source = classify_referrer(payload.get("referrer"), request.host)
    country_code, country_name = lookup_country(client_ip_from_request(request))

    db.session.add(StatEvent(
        tenant_id=tenant.id,
        event_type=event_type,
        ref_id=ref_id,
        visitor_id=visitor_id,
        referrer_host=referrer_host,
        traffic_source=traffic_source,
        device_type=device_type,
        browser=browser,
        country_code=country_code,
        country_name=country_name,
    ))
    db.session.commit()
    return jsonify({"ok": True})
