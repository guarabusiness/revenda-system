/**
 * backend-client.js
 * -----------------------------------------------------------------------
 * Cliente 100% local/self-hosted: NÃO usa Firebase nem nenhum serviço de
 * terceiros. Toda autenticação e todos os dados (produtos, categorias,
 * configurações, imagens) são enviados via fetch() para o backend Python
 * (Flask) rodando na própria máquina que hospeda este servidor, que por
 * sua vez persiste tudo em banco de dados/disco locais.
 *
 * A API exposta em `window.appBackend` imita, de propósito, o formato
 * usado pelo script.js original (auth() / firestore() com
 * collection/doc/get/set/update/delete/add/orderBy) para que a lógica de
 * negócio existente continuasse funcionando sem reescrever tudo — mas o
 * transporte e o armazenamento são 100% próprios, sem nenhuma dependência
 * do Firebase.
 *
 * Superfície coberta (é tudo que o script.js usa):
 *   appBackend.initializeApp()                          -> no-op
 *   appBackend.auth()
 *     .currentUser
 *     .signInWithEmailAndPassword(email, senha)
 *     .signOut()
 *     .onAuthStateChanged(callback)
 *   appBackend.firestore()
 *     .collection(nome)
 *       .doc(id?)                 // sem id -> gera um novo (uuid)
 *         .get() / .set(obj) / .update(obj) / .delete()
 *       .add(obj)
 *       .orderBy(campo, 'asc'|'desc').get()
 *   appBackend.firestore.FieldValue.serverTimestamp()
 * -----------------------------------------------------------------------
 */
(function (global) {
  const SLUG = global.TENANT_SLUG;
  const API_ROOT = `/api/${SLUG}`;

  function uuid() {
    if (global.crypto && global.crypto.randomUUID) return global.crypto.randomUUID().replace(/-/g, '');
    return 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'.replace(/x/g, () =>
      ((Math.random() * 16) | 0).toString(16)
    );
  }

  async function apiFetch(path, options = {}) {
    const res = await fetch(`${API_ROOT}${path}`, {
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      ...options,
    });
    if (!res.ok) {
      let message = `Erro na API (${res.status})`;
      try {
        const body = await res.json();
        message = body.error || body.description || message;
      } catch (e) {
        /* ignore */
      }
      throw new Error(message);
    }
    if (res.status === 204) return null;
    return res.json();
  }

  // ---------------------------------------------------------------------
  // Auth
  // ---------------------------------------------------------------------
  class AuthShim {
    constructor() {
      this.currentUser = null;
      this._ready = false;
      this._listeners = [];
      this._restoreSession();
    }

    async _restoreSession() {
      try {
        const user = await apiFetch('/auth/me');
        this.currentUser = user || null;
      } catch (e) {
        this.currentUser = null;
      }
      this._ready = true;
      this._emit();
    }

    _emit() {
      this._listeners.forEach((cb) => cb(this.currentUser));
    }

    onAuthStateChanged(cb) {
      this._listeners.push(cb);
      // Só dispara imediatamente se a sessão já foi restaurada. Do
      // contrário, notificar agora passaria "null" de forma prematura
      // (antes da checagem real terminar), fazendo a vitrine pública
      // aparecer rapidamente antes do painel administrativo assumir —
      // o "flash vermelho" na transição. Quando a checagem terminar,
      // _emit() já cuida de notificar com o valor definitivo.
      if (this._ready) {
        cb(this.currentUser);
      }
      return () => {
        this._listeners = this._listeners.filter((l) => l !== cb);
      };
    }

    signInWithEmailAndPassword(email, password) {
      return apiFetch('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      })
        .then((user) => {
          this.currentUser = user;
          this._emit();
          return { user };
        })
        .catch((err) => {
          // Formato de erro parecido com o do Firebase Auth
          const wrapped = new Error(err.message);
          wrapped.code = 'auth/invalid-credential';
          throw wrapped;
        });
    }

    signOut() {
      return apiFetch('/auth/logout', { method: 'POST' }).then(() => {
        this.currentUser = null;
        this._emit();
      });
    }
  }

  // ---------------------------------------------------------------------
  // Firestore
  // ---------------------------------------------------------------------
  class DocSnapshot {
    constructor(id, data, exists) {
      this.id = id;
      this._data = data || {};
      this.exists = exists;
    }
    data() {
      return this._data;
    }
  }

  class DocRef {
    constructor(collectionName, id) {
      this.collectionName = collectionName;
      this.id = id || uuid();
    }
    get() {
      return apiFetch(`/docs/${this.collectionName}/${this.id}`).then(
        (body) => new DocSnapshot(this.id, body, !!body.exists)
      );
    }
    set(data) {
      return apiFetch(`/docs/${this.collectionName}/${this.id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      });
    }
    update(data) {
      return apiFetch(`/docs/${this.collectionName}/${this.id}`, {
        method: 'PATCH',
        body: JSON.stringify(data),
      });
    }
    delete() {
      return apiFetch(`/docs/${this.collectionName}/${this.id}`, {
        method: 'DELETE',
      });
    }
  }

  class QuerySnapshot {
    constructor(docs) {
      this.docs = docs.map((d) => new DocSnapshot(d.id, d, true));
      this.size = this.docs.length;
      this.empty = this.docs.length === 0;
    }
    forEach(cb) {
      this.docs.forEach(cb);
    }
  }

  class CollectionRef {
    constructor(name) {
      this.name = name;
      this._orderBy = null;
      this._dir = 'asc';
    }
    doc(id) {
      return new DocRef(this.name, id);
    }
    add(data) {
      const ref = new DocRef(this.name);
      return ref.set(data).then(() => ref);
    }
    orderBy(field, dir) {
      this._orderBy = field;
      this._dir = dir || 'asc';
      return this;
    }
    get() {
      const params = new URLSearchParams();
      if (this._orderBy) {
        params.set('orderBy', this._orderBy);
        params.set('dir', this._dir);
      }
      const qs = params.toString() ? `?${params.toString()}` : '';
      return apiFetch(`/docs/${this.name}${qs}`).then((list) => new QuerySnapshot(list));
    }
  }

  class FirestoreShim {
    collection(name) {
      return new CollectionRef(name);
    }
  }

  // ---------------------------------------------------------------------
  // Namespace global `appBackend` (100% local, sem Firebase)
  // ---------------------------------------------------------------------
  const authInstance = new AuthShim();
  const firestoreInstance = new FirestoreShim();

  global.appBackend = {
    TENANT_SLUG: SLUG,
    initializeApp() {
      /* no-op: o tenant já é resolvido via TENANT_SLUG/sessão */
    },
    auth() {
      return authInstance;
    },
    firestore() {
      return firestoreInstance;
    },
  };

  // appBackend.firestore.FieldValue.serverTimestamp()
  global.appBackend.firestore.FieldValue = {
    serverTimestamp() {
      return '__SERVER_TIMESTAMP__';
    },
  };
})(window);
