        // Backend local (self-hosted) - roda no mesmo servidor Flask desta loja.
        // Nenhum dado ou imagem é enviado para serviços de terceiros: tudo
        // fica salvo no banco/disco da própria máquina que hospeda o servidor.
        try {
            appBackend.initializeApp();
        } catch (error) {
            console.error("Erro ao inicializar o backend:", error);
        }

        const auth = appBackend.auth();
        const db = appBackend.firestore();
        
        // DOM Elements
        // Loading Screen Elements
        const loadingOverlay = document.getElementById('loading-overlay');
        const loadingComponentText = document.getElementById('loading-component');
        
        // O tema e o modo (painel administrativo x vitrine pública) já
        // chegam corretos no próprio HTML renderizado pelo servidor (ver
        // app/tenant.py: body_theme_classes), então não há mais necessidade
        // de esconder o conteúdo atrás de uma tela de carregamento — a
        // loja/painel já abre direto, sem nenhuma transição ou flash.
        if (loadingOverlay) {
            loadingOverlay.style.display = 'none';
        }

        // Elementos principais
        const loginModal = document.getElementById('login-modal');
        const addProductModal = document.getElementById('add-product-modal');
        const addCategoryModal = document.getElementById('add-category-modal');
        const galleryModal = document.getElementById('gallery-modal');
        const productModal = document.getElementById('product-modal');
        const quickStockModal = document.getElementById('quick-stock-modal');
        const adminControls = document.getElementById('admin-controls');
        const loginForm = document.getElementById('login-form');
        const sidebarLoginLink = document.getElementById('sidebar-login-link');
        const adminLogoutBtn = document.getElementById('admin-logout-btn');
        const sidebarCategoriesToggle = document.getElementById('sidebar-categories-toggle');
        const sidebarCategoriesSubmenu = document.getElementById('sidebar-categories-submenu');
        const productForm = document.getElementById('product-form');
        const categoryForm = document.getElementById('category-form');
        const quickStockForm = document.getElementById('quick-stock-form');
        const productsGrid = document.getElementById('products-grid');
        const categoriesGrid = document.getElementById('categories-grid');
        const addProductBtn = document.getElementById('add-product-btn');
        const addCategoryBtn = document.getElementById('add-category-btn');
        const closeModals = document.querySelectorAll('.close-modal');
        const productModalClose = document.querySelector('.product-modal-close');
        const loginMessage = document.getElementById('login-message');
        const productMessage = document.getElementById('product-message');
        const categoryMessage = document.getElementById('category-message');
        const loadingSpinner = document.getElementById('loading-spinner');
        const imageUpload = document.getElementById('product-image-upload');
        const imagePreviewContainer = document.getElementById('image-preview-container');
        const galleryMainImage = document.getElementById('gallery-main-image');
        const galleryThumbnails = document.getElementById('gallery-thumbnails');
        const galleryClose = document.querySelector('.gallery-close');
        const galleryPrev = document.querySelector('.gallery-prev');
        const galleryNext = document.querySelector('.gallery-next');
        const imageCount = document.getElementById('image-count');
        const toast = document.getElementById('toast');
        const toastMessage = document.getElementById('toast-message');
        const productCategorySelect = document.getElementById('product-category');
        const productFormSubmit = document.getElementById('product-form-submit');
        const editProductId = document.getElementById('edit-product-id');
        const productFreeShippingCheckbox = document.getElementById('product-free-shipping');
        const productFreeShippingGroup = document.getElementById('product-free-shipping-group');
        const productPromoToggle = document.getElementById('product-promo-toggle');
        const productOldPriceGroup = document.getElementById('product-old-price-group');
        const productDescriptionToggle = document.getElementById('product-description-toggle');
        const productDescriptionGroup = document.getElementById('product-description-group');
        const productDescriptionInput = document.getElementById('product-description');
        const productModalPriceContainer = document.getElementById('product-modal-price-container');
        const shareButtonsContainer = document.getElementById('share-buttons');
        const viewProductsBtn = document.getElementById('view-products-btn');
        const heroTitle = document.getElementById('hero-title');
        const heroSubtitle = document.getElementById('hero-subtitle');
        
        // Elementos do modal de produto expandido
        const productModalMainImg = document.getElementById('product-modal-main-img');
        const productModalThumbnails = document.getElementById('product-modal-thumbnails');
        const productModalTitleElem = document.getElementById('product-modal-title');
        const productModalStock = document.getElementById('product-modal-stock');
        const productModalDescription = document.getElementById('product-modal-description');
        const productModalFeatures = document.getElementById('product-modal-features');
        const productActionButtons = document.getElementById('product-action-buttons');
        
        // Elementos do WhatsApp
        const whatsappBtn = document.getElementById('whatsapp-btn');
        const whatsappNumber = document.getElementById('whatsapp-number');
        
        // Elementos do modal de estoque rápido
        const quickStockProductName = document.getElementById('quick-stock-product-name');
        const quickStockQuantity = document.getElementById('quick-stock-quantity');
        const quickStockProductId = document.getElementById('quick-stock-product-id');
        const decreaseStockBtn = document.getElementById('decrease-stock');
        const increaseStockBtn = document.getElementById('increase-stock');
        
        // Elementos de busca
        const searchInput = document.getElementById('search-input');
        const searchButton = document.getElementById('search-button');
        const searchContainer = document.querySelector('.search-container');
        const headerContent = document.querySelector('.header-content');
        
        // Elementos das abas de admin
        const adminTabs = document.querySelectorAll('.admin-tab');
        const adminContents = document.querySelectorAll('.admin-content');
        
        // Configurações do sistema - Elementos expandidos
        const systemNameInput = document.getElementById('system-name');
        const systemSloganInput = document.getElementById('system-slogan');
        const systemDescriptionInput = document.getElementById('system-description');
        const systemCurrencyInput = document.getElementById('system-currency');
        const systemTimezoneInput = document.getElementById('system-timezone');
        const contactEmailInput = document.getElementById('contact-email');
        
        // Hero Settings Inputs
        const heroTitleInput = document.getElementById('hero-title-input');
        const heroSubtitleInput = document.getElementById('hero-subtitle-input');
        const heroBtnTextInput = document.getElementById('hero-btn-text-input');
        
        const contactPhoneInput = document.getElementById('contact-phone');
        const contactAddressInput = document.getElementById('contact-address');
        const saveSystemSettingsBtn = document.getElementById('save-system-settings');
        const resetSystemSettingsBtn = document.getElementById('reset-system-settings');
        
        // Map Settings Elements
        const showMapCheckbox = document.getElementById('show-map');
        const mapIframeInput = document.getElementById('map-iframe-code');
        const mapSection = document.getElementById('location-map-section');
        const mapContainer = document.getElementById('map-container');
        
        // Configurações do rodapé
        const footerCopyrightInput = document.getElementById('footer-copyright-text');
        const footerFacebookInput = document.getElementById('footer-facebook');
        const footerInstagramInput = document.getElementById('footer-instagram');
        const footerTiktokInput = document.getElementById('footer-tiktok');
        const footerYoutubeInput = document.getElementById('footer-youtube');
        const footerBusinessHoursInput = document.getElementById('footer-business-hours');
        
        // Elementos do rodapé para atualização
        const footerSystemName = document.getElementById('footer-system-name');
        const footerSystemDescription = document.getElementById('footer-system-description');
        const footerAddress = document.getElementById('footer-address');
        const footerPhone = document.getElementById('footer-phone');
        const footerEmail = document.getElementById('footer-email');
        const footerCopyright = document.getElementById('footer-copyright');
        const footerFacebookLink = document.getElementById('footer-facebook-link');
        const footerInstagramLink = document.getElementById('footer-instagram-link');
        const footerTiktokLink = document.getElementById('footer-tiktok-link');
        const footerYoutubeLink = document.getElementById('footer-youtube-link');
        const footerWhatsappLink = document.getElementById('footer-whatsapp-link');
        const footerBusinessHours = document.getElementById('footer-business-hours');
        
        // Configurações de exibição
        const showStockStatus = document.getElementById('show-stock-status');
        const hideProductBrand = document.getElementById('hide-product-brand');
        const hideViewProductBtn = document.getElementById('hide-view-product-btn');
        const showCategoriesSidebar = document.getElementById('show-categories-sidebar');
        const enableSearch = document.getElementById('enable-search');
        const enableCartCheckbox = document.getElementById('enable-cart');
        const enableFreeShipping = document.getElementById('enable-free-shipping');
        const freeShippingMinValueInput = document.getElementById('free-shipping-min-value');
        const viewProductTextInput = document.getElementById('view-product-text');
        const desktopColumnsInput = document.getElementById('desktop-columns');
        const mobileColumnsInput = document.getElementById('mobile-columns');
        const displayControls = document.querySelectorAll('.display-control-btn');
        const catalogSortDefaultSelect = document.getElementById('catalog-sort-default');
        
        // Configurações de tema
        const themeSelector = document.getElementById('theme-selector');
        const darkMode = document.getElementById('dark-mode');

        // Banner de aviso no topo
        const topBannerEnabledCheckbox = document.getElementById('top-banner-enabled');
        const topBannerTextInput = document.getElementById('top-banner-text-input');
        const topAnnouncementBanner = document.getElementById('top-announcement-banner');
        const topAnnouncementText = document.getElementById('top-announcement-text');

        // Imagem de fundo do banner
        const heroBgImageInput = document.getElementById('hero-bg-image-input');
        const heroBgPreviewWrapper = document.getElementById('hero-bg-preview-wrapper');
        const heroBgPreview = document.getElementById('hero-bg-preview');
        const removeHeroBgBtn = document.getElementById('remove-hero-bg-btn');
        const heroSection = document.getElementById('hero-section');
        let heroBackgroundImageUrl = '';
        let heroBackgroundImageDeleteHash = '';
        let pendingHeroBgUpload = null;

        // Logo da loja
        const storeLogoImageInput = document.getElementById('store-logo-image-input');
        const storeLogoPreviewWrapper = document.getElementById('store-logo-preview-wrapper');
        const storeLogoPreview = document.getElementById('store-logo-preview');
        const removeStoreLogoBtn = document.getElementById('remove-store-logo-btn');
        const storeLogoIcon = document.getElementById('store-logo-icon');
        const storeLogoImg = document.getElementById('store-logo-img');
        let storeLogoUrl = '';
        let storeLogoDeleteHash = '';

        // Modo de exibição do catálogo (grade / lista / cardápio / compacto)
        const catalogLayoutSelect = document.getElementById('catalog-layout-select');
        
        // Backup e exportação
        const exportProductsBtn = document.getElementById('export-products-btn');
        const backupSystemBtn = document.getElementById('backup-system-btn');
        const backupFrequency = document.getElementById('backup-frequency');
        
        // Estatísticas
        const statProducts = document.getElementById('stat-products');
        const statCategories = document.getElementById('stat-categories');
        const statLastUpdate = document.getElementById('stat-last-update');
        const statLastUpdateDetail = document.getElementById('stat-last-update-detail');
        
        // Elementos do carrinho
        const cartBtn = document.getElementById('cart-btn');
        const cartBadge = document.getElementById('cart-badge');
        const cartSidebar = document.getElementById('cart-sidebar');
        const closeCartBtn = document.getElementById('close-cart');
        const cartContent = document.getElementById('cart-content');
        const cartTotalPrice = document.getElementById('cart-total-price');
        const freeShippingProgress = document.getElementById('free-shipping-progress');
        const checkoutBtn = document.getElementById('checkout-btn');
        const clearCartBtn = document.getElementById('clear-cart-btn');
        const miniCart = document.getElementById('mini-cart');
        const miniCartOverlay = document.getElementById('mini-cart-overlay');
        const continueShoppingBtn = document.getElementById('continue-shopping-btn');
        const goToCartBtn = document.getElementById('go-to-cart-btn');
        
        // Variáveis globais
        let currentImageIndex = 0;
        let currentGalleryImages = [];
        let selectedFiles = [];
        let currentCategory = 'all';
        let allProducts = [];
        let allCategories = [];
        let currentProductModalImages = [];
        let currentProductModalIndex = 0;
        let isCategoriesSubmenuOpen = false;
        let isEditingProduct = false;
        let currentEditingProductId = null;
        let currentEditingProductImages = [];
        let currentSearchQuery = '';
        let currentProductForSharing = null;
        let systemSettings = {};
        let itemsPerPage = 12;
        let currentTheme = 'light';
        let currentColor = '#CC0000';
        let currentAdminTab = 'manage-products'; // Aba ativa do admin
        
        // Configurações do WhatsApp
        let whatsappSettings = {
            number: "5527996316212"
        };

        // Sistema de última atualização
        let lastUpdateData = {
            timestamp: null
        };

        // Carrinho de compras
        let shoppingCart = {
            items: [],
            total: 0
        };

        // Sidebar Elements
        const sidebarToggle = document.getElementById('sidebar-toggle');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebar-overlay');
        const sidebarMenuItems = document.querySelectorAll('.sidebar-menu a:not(.has-submenu a)');

        // Função para mostrar notificação toast
        function showToast(message, type = 'success') {
            const icon = toast.querySelector('i');
            toastMessage.textContent = message;
            toast.className = `toast ${type} show`;
            
            if (type === 'success') {
                icon.className = 'fas fa-check-circle';
            } else if (type === 'error') {
                icon.className = 'fas fa-times-circle';
            } else { // info or default
                icon.className = 'fas fa-info-circle';
            }

            setTimeout(() => {
                toast.classList.remove('show');
            }, 3000);
        }

        // Função para calcular porcentagem de desconto
        function calculateDiscountPercentage(originalPrice, salePrice) {
            if (!originalPrice || originalPrice <= salePrice) return 0;
            return Math.round(((originalPrice - salePrice) / originalPrice) * 100);
        }

        // Função para embaralhar array (Fisher-Yates shuffle)
        function shuffleArray(array) {
            const newArray = [...array];
            for (let i = newArray.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
            }
            return newArray;
        }

        // Definir os temas disponíveis
        const availableThemes = [
            {
                id: 'light',
                name: 'Claro',
                colors: ['#f9f9f9', '#FFFFFF', '#CC0000', '#990000']
            },
            {
                id: 'dark',
                name: 'Escuro',
                colors: ['#121212', '#1e1e1e', '#CC0000', '#990000']
            },
            {
                id: 'blue',
                name: 'Azul',
                colors: ['#f9f9f9', '#FFFFFF', '#0066CC', '#004C99']
            },
            {
                id: 'green',
                name: 'Verde',
                colors: ['#f9f9f9', '#FFFFFF', '#009900', '#007700']
            },
            {
                id: 'purple',
                name: 'Roxo',
                colors: ['#f9f9f9', '#FFFFFF', '#663399', '#552288']
            },
            {
                id: 'orange',
                name: 'Laranja',
                colors: ['#f9f9f9', '#FFFFFF', '#FF6600', '#CC5500']
            },
            {
                id: 'pink',
                name: 'Rosa',
                colors: ['#f9f9f9', '#FFFFFF', '#E91E63', '#C2185B']
            },
            {
                id: 'gray',
                name: 'Cinza',
                colors: ['#f9f9f9', '#FFFFFF', '#607D8B', '#455A64']
            },
            {
                id: 'teal',
                name: 'Verde-azulado',
                colors: ['#f9f9f9', '#FFFFFF', '#008080', '#006666']
            },
            {
                id: 'indigo',
                name: 'Índigo',
                colors: ['#f9f9f9', '#FFFFFF', '#4B0082', '#3A0066']
            },
            {
                id: 'yellow',
                name: 'Amarelo',
                colors: ['#f9f9f9', '#FFFFFF', '#FFD700', '#CCAD00']
            },
            {
                id: 'brown',
                name: 'Marrom',
                colors: ['#f9f9f9', '#FFFFFF', '#8B4513', '#6B3610']
            },
            {
                id: 'cyan',
                name: 'Ciano',
                colors: ['#f9f9f9', '#FFFFFF', '#00BCD4', '#0097A7']
            },
            {
                id: 'lime',
                name: 'Lima',
                colors: ['#f9f9f9', '#FFFFFF', '#CDDC39', '#AFB42B']
            },
            {
                id: 'deep-orange',
                name: 'Laranja Escuro',
                colors: ['#f9f9f9', '#FFFFFF', '#FF5722', '#E64A19']
            },
            {
                id: 'deep-purple',
                name: 'Roxo Escuro',
                colors: ['#f9f9f9', '#FFFFFF', '#673AB7', '#512DA8']
            },
            {
                id: 'light-blue',
                name: 'Azul Claro',
                colors: ['#f9f9f9', '#FFFFFF', '#03A9F4', '#0288D1']
            },
            {
                id: 'light-green',
                name: 'Verde Claro',
                colors: ['#f9f9f9', '#FFFFFF', '#8BC34A', '#689F38']
            },
            {
                id: 'amber',
                name: 'Âmbar',
                colors: ['#f9f9f9', '#FFFFFF', '#FFC107', '#FFA000']
            },
            {
                id: 'gradient',
                name: 'Gradiente',
                colors: ['#667eea', '#764ba2', '#667eea', '#5a67d8']
            },
            {
                id: 'minimal',
                name: 'Minimalista',
                colors: ['#FFFFFF', '#FFFFFF', '#2C3E50', '#1A252F']
            },
            {
                id: 'neon',
                name: 'Neon',
                colors: ['#0A0A0A', '#1A1A1A', '#00FF9D', '#00CC7A']
            },
            {
                id: 'coral',
                name: 'Coral',
                colors: ['#f9f9f9', '#FFFFFF', '#FF7F50', '#E56A3C']
            },
            {
                id: 'emerald',
                name: 'Esmeralda',
                colors: ['#f9f9f9', '#FFFFFF', '#2ECC71', '#27AE60']
            },
            {
                id: 'burgundy',
                name: 'Vinho',
                colors: ['#f9f9f9', '#FFFFFF', '#800020', '#5C0017']
            },
            {
                id: 'navy',
                name: 'Marinho',
                colors: ['#f9f9f9', '#FFFFFF', '#001F54', '#001438']
            },
            {
                id: 'mint',
                name: 'Menta',
                colors: ['#f9f9f9', '#FFFFFF', '#00C9A7', '#00A88C']
            },
            {
                id: 'sunset',
                name: 'Pôr do Sol',
                colors: ['#FFB88C', '#DE6262', '#FFB88C', '#DE6262']
            },
            {
                id: 'ocean',
                name: 'Oceano',
                colors: ['#2193b0', '#6dd5ed', '#2193b0', '#1a7590']
            },
            {
                id: 'rose-gold',
                name: 'Rosé',
                colors: ['#f9f9f9', '#FFFFFF', '#B76E79', '#9A5A64']
            },
            {
                id: 'slate',
                name: 'Ardósia',
                colors: ['#f9f9f9', '#FFFFFF', '#2F4858', '#1F313B']
            }
        ];


        let currentCatalogLayout = 'grid';

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text == null ? '' : String(text);
            return div.innerHTML;
        }

        // ---------------------------------------------------------------
        // Modo de exibição do catálogo: várias formas de apresentar os
        // produtos na vitrine (grade, lista, cardápio, compacto). Isso é
        // só uma questão visual — não depende do tipo/segmento de negócio,
        // qualquer loja pode escolher o modo que fizer mais sentido.
        // ---------------------------------------------------------------
        function applyCatalogLayout() {
            const layout = (catalogLayoutSelect && catalogLayoutSelect.value) || 'grid';
            currentCatalogLayout = layout;
            if (!productsGrid) return;
            productsGrid.classList.remove('catalog-layout-list', 'catalog-layout-menu', 'catalog-layout-compact');
            if (layout === 'list') {
                productsGrid.classList.add('catalog-layout-list');
            } else if (layout === 'menu') {
                productsGrid.classList.add('catalog-layout-menu');
            } else if (layout === 'compact') {
                productsGrid.classList.add('catalog-layout-compact');
            }
        }

        // Pré-visualização em tempo real: ao trocar o modo de exibição, já
        // aplica a classe e redesenha os cards (sem precisar salvar antes).
        if (catalogLayoutSelect) {
            catalogLayoutSelect.addEventListener('change', () => {
                applyCatalogLayout();
                syncCatalogLayoutPicker();
                if (typeof filterAndDisplayProducts === 'function') {
                    filterAndDisplayProducts();
                }
            });
        }

        // Seletor visual (cards com desenho) do modo de exibição do catálogo.
        // O <select> continua sendo a "fonte da verdade" (todo o resto do
        // código já lê/escreve nele); os cards só espelham e disparam o
        // evento 'change' dele, pra reaproveitar a lógica existente.
        const catalogLayoutPicker = document.getElementById('catalog-layout-picker');
        const catalogLayoutOptions = catalogLayoutPicker
            ? Array.from(catalogLayoutPicker.querySelectorAll('.catalog-layout-option'))
            : [];

        function syncCatalogLayoutPicker() {
            if (!catalogLayoutSelect) return;
            const current = catalogLayoutSelect.value || 'grid';
            catalogLayoutOptions.forEach((option) => {
                const isActive = option.dataset.layout === current;
                option.classList.toggle('active', isActive);
                const radio = option.querySelector('input[type="radio"]');
                if (radio) radio.checked = isActive;
            });
        }

        catalogLayoutOptions.forEach((option) => {
            option.addEventListener('click', () => {
                if (!catalogLayoutSelect) return;
                const layout = option.dataset.layout;
                if (catalogLayoutSelect.value === layout) return;
                catalogLayoutSelect.value = layout;
                catalogLayoutSelect.dispatchEvent(new Event('change'));
            });
        });

        syncCatalogLayoutPicker();

        // Função para aplicar tema
        function applyTheme(themeId, color = null) {
            // Remover todas as classes de tema
            document.body.classList.remove('theme-light', 'theme-dark', 'theme-blue', 'theme-green', 'theme-purple', 'theme-orange', 'theme-pink', 'theme-gray', 'theme-teal', 'theme-indigo', 'theme-yellow', 'theme-brown', 'theme-cyan', 'theme-lime', 'theme-deep-orange', 'theme-deep-purple', 'theme-light-blue', 'theme-light-green', 'theme-amber', 'theme-gradient', 'theme-minimal', 'theme-neon', 'theme-coral', 'theme-emerald', 'theme-burgundy', 'theme-navy', 'theme-mint', 'theme-sunset', 'theme-ocean', 'theme-rose-gold', 'theme-slate');
            
            // Aplicar novo tema
            document.body.classList.add(`theme-${themeId}`);
            currentTheme = themeId;
            
            // Salvar no localStorage para visitantes
            localStorage.setItem('guaraestoque_theme', themeId);
            
            // Atualizar controles na interface admin
            if (auth.currentUser) {
                updateThemeControls(themeId);
            }
        }

        // Função para carregar tema salvo
        function loadSavedTheme() {
            const savedTheme = localStorage.getItem('guaraestoque_theme') || 'light';
            const savedDarkMode = localStorage.getItem('guaraestoque_darkmode') === 'true';
            
            applyTheme(savedTheme);
            
            // Aplicar modo escuro se necessário
            if (savedDarkMode && savedTheme !== 'dark') {
                document.body.classList.add('theme-dark');
            }
            
            // Atualizar controles na interface admin
            if (auth.currentUser) {
                updateThemeControls(savedTheme);
                darkMode.checked = savedDarkMode;
            }
        }

        // Função para atualizar controles de tema
        function updateThemeControls(themeId) {
            // Atualizar seleção de tema
            const themeOptions = document.querySelectorAll('.theme-option');
            themeOptions.forEach(option => {
                option.classList.remove('selected');
                if (option.dataset.theme === themeId) {
                    option.classList.add('selected');
                }
            });
            
            // Atualizar checkboxes
            darkMode.checked = document.body.classList.contains('theme-dark');
        }

        // Função para carregar temas na interface
        function loadThemesInterface() {
            // Limpar containers
            themeSelector.innerHTML = '';
            
            // Adicionar opções de tema
            availableThemes.forEach(theme => {
                const themeOption = document.createElement('div');
                themeOption.className = 'theme-option';
                themeOption.dataset.theme = theme.id;
                
                const colorsHtml = theme.colors.map(color => 
                    `<div class="theme-preview-color" style="background: ${color};"></div>`
                ).join('');
                
                themeOption.innerHTML = `
                    <div class="theme-preview-colors">
                        ${colorsHtml}
                    </div>
                    <div class="theme-option-name">${theme.name}</div>
                `;
                
                themeOption.addEventListener('click', () => {
                    applyTheme(theme.id);
                    
                    // Salvar configuração se admin
                    if (auth.currentUser) {
                        saveThemeToFirestore();
                    }
                });
                
                themeSelector.appendChild(themeOption);
            });
        }

        // Função para salvar tema no Firestore
        function saveThemeToFirestore() {
            if (!auth.currentUser) return;
            
            const themeData = {
                theme: currentTheme,
                darkMode: darkMode.checked,
                updatedAt: appBackend.firestore.FieldValue.serverTimestamp()
            };
            
            db.collection('settings').doc('theme').set(themeData)
                .then(() => {
                    console.log('Tema salvo no Firestore');
                })
                .catch(error => {
                    console.error('Erro ao salvar tema:', error);
                });
        }

        // Função para carregar tema do Firestore
        function loadThemeFromFirestore() {
            db.collection('settings').doc('theme').get()
                .then(doc => {
                    if (doc.exists) {
                        const themeData = doc.data();
                        currentTheme = themeData.theme || 'light';
                        
                        // Aplicar tema
                        applyTheme(currentTheme);
                        
                        // Aplicar modo escuro se necessário
                        if (themeData.darkMode && currentTheme !== 'dark') {
                            document.body.classList.add('theme-dark');
                        }
                        
                        // Atualizar controles
                        if (auth.currentUser) {
                            updateThemeControls(currentTheme);
                            darkMode.checked = themeData.darkMode || false;
                        }
                    } else {
                        // Usar tema padrão
                        loadSavedTheme();
                    }
                })
                .catch(error => {
                    console.error('Erro ao carregar tema:', error);
                    loadSavedTheme();
                });
        }

        // Aplicar modo escuro
        darkMode.addEventListener('change', () => {
            if (darkMode.checked && !document.body.classList.contains('theme-dark')) {
                document.body.classList.add('theme-dark');
            } else if (!darkMode.checked && currentTheme !== 'dark') {
                document.body.classList.remove('theme-dark');
            }
            
            if (auth.currentUser) {
                saveThemeToFirestore();
            }
        });

        // Sidebar Functions
        function openSidebar() {
            sidebar.classList.add('active');
            sidebarOverlay.classList.add('active');
            document.body.classList.add('sidebar-open');
        }

        function closeSidebar() {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
            document.body.classList.remove('sidebar-open');
        }

        // Toggle submenu de categorias
        function toggleCategoriesSubmenu() {
            isCategoriesSubmenuOpen = !isCategoriesSubmenuOpen;
            sidebarCategoriesSubmenu.classList.toggle('active');
            
            const toggleIcon = sidebarCategoriesToggle.querySelector('.sidebar-menu-toggle');
            if (isCategoriesSubmenuOpen) {
                toggleIcon.classList.add('rotated');
            } else {
                toggleIcon.classList.remove('rotated');
            }
        }

        // Sidebar Event Listeners
        sidebarToggle.addEventListener('click', () => {
            if (sidebar.classList.contains('active')) {
                closeSidebar();
            } else {
                openSidebar();
            }
        });
        sidebarOverlay.addEventListener('click', closeSidebar);

        // Toggle submenu de categorias
        sidebarCategoriesToggle.addEventListener('click', (e) => {
            e.preventDefault();
            toggleCategoriesSubmenu();
        });

        // Menu item click handlers
        sidebarMenuItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                
                // Remove active class from all items
                document.querySelectorAll('.sidebar-menu a').forEach(menuItem => {
                    menuItem.classList.remove('active');
                });
                
                // Add active class to clicked item
                item.classList.add('active');
                
                // Get section from data attribute
                const section = item.getAttribute('data-section');
                
                // Handle different sections
                switch(section) {
                    case 'inicio':
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                        break;
                    case 'produtos':
                        const productsSection = document.querySelector('#products-section');
                        if (productsSection) {
                            productsSection.scrollIntoView({ behavior: 'smooth' });
                        }
                        break;
                    case 'localizacao':
                        const locationSection = document.getElementById('location-map-section');
                        if (locationSection) {
                            locationSection.scrollIntoView({ behavior: 'smooth' });
                        }
                        break;
                    case 'contato':
                        const footer2 = document.querySelector('footer');
                        if (footer2) {
                            footer2.scrollIntoView({ behavior: 'smooth' });
                        }
                        break;
                    case 'login':
                        loginModal.style.display = 'flex';
                        break;
                    case 'logout':
                        auth.signOut();
                        break;
                }
                
                // Close sidebar after selection
                closeSidebar();
            });
        });

        // Botão "Sair" no cabeçalho do painel do administrador
        if (adminLogoutBtn) {
            adminLogoutBtn.addEventListener('click', () => {
                auth.signOut();
            });
        }

        // Botão "Ver Produtos" do hero
        viewProductsBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const productsSection = document.getElementById('products-section');
            if (productsSection) {
                productsSection.scrollIntoView({ behavior: 'smooth' });
            }
        });

        // Close sidebar on escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && sidebar.classList.contains('active')) {
                closeSidebar();
            }
        });
        
        // Funções do Carrinho
        function openCart() {
            cartSidebar.classList.add('active');
            renderCartItems();
        }
        
        function closeCart() {
            cartSidebar.classList.remove('active');
        }
        
        function showMiniCart() {
            miniCart.classList.add('active');
            miniCartOverlay.classList.add('active');
        }
        
        function hideMiniCart() {
            miniCart.classList.remove('active');
            miniCartOverlay.classList.remove('active');
        }
        
        function addToCart(product) {
            // Verificar se o produto já está no carrinho
            const existingItemIndex = shoppingCart.items.findIndex(item => item.id === product.id);
            
            if (existingItemIndex !== -1) {
                // Se já existe, incrementar a quantidade
                shoppingCart.items[existingItemIndex].quantity += 1;
            } else {
                // Se não existe, adicionar novo item
                shoppingCart.items.push({
                    id: product.id,
                    title: product.title,
                    price: product.price,
                    image: product.images[0],
                    quantity: 1
                });
            }
            
            // Atualizar total
            updateCartTotal();
            
            // Atualizar badge
            updateCartBadge();
            
            // Salvar no localStorage
            saveCartToLocalStorage();
            
            // Mostrar mini-carrinho
            showMiniCart();
            
            // Mostrar mensagem
            showToast('Produto adicionado ao carrinho!');

            trackStatEvent('cart_add', product.id);
        }
        
        function removeFromCart(productId) {
            shoppingCart.items = shoppingCart.items.filter(item => item.id !== productId);
            updateCartTotal();
            updateCartBadge();
            saveCartToLocalStorage();
            renderCartItems();
            showToast('Produto removido do carrinho!');
        }
        
        function updateCartItemQuantity(productId, newQuantity) {
            if (newQuantity < 1) {
                removeFromCart(productId);
                return;
            }
            
            const itemIndex = shoppingCart.items.findIndex(item => item.id === productId);
            if (itemIndex !== -1) {
                shoppingCart.items[itemIndex].quantity = newQuantity;
                updateCartTotal();
                updateCartBadge();
                saveCartToLocalStorage();
                renderCartItems();
            }
        }
        
        function updateCartTotal() {
            shoppingCart.total = shoppingCart.items.reduce((total, item) => {
                return total + (item.price * item.quantity);
            }, 0);
            
            cartTotalPrice.textContent = `R$ ${shoppingCart.total.toLocaleString('pt-BR', {minimumFractionDigits: 2})}`;
            updateFreeShippingProgress();
        }
        
        // Mostra quanto falta para o cliente atingir o Frete Grátis (se configurado)
        function updateFreeShippingProgress() {
            if (!freeShippingProgress) return;
            const enabled = systemSettings && systemSettings.enableFreeShipping;
            const minValue = (systemSettings && parseFloat(systemSettings.freeShippingMinValue)) || 0;
            if (!enabled || minValue <= 0) {
                freeShippingProgress.style.display = 'none';
                return;
            }
            const remaining = minValue - shoppingCart.total;
            if (remaining > 0) {
                freeShippingProgress.style.display = 'block';
                freeShippingProgress.innerHTML = `<i class="fas fa-truck"></i> Faltam R$ ${remaining.toLocaleString('pt-BR', {minimumFractionDigits: 2})} para Frete Grátis`;
                freeShippingProgress.classList.remove('free-shipping-reached');
            } else {
                freeShippingProgress.style.display = 'block';
                freeShippingProgress.innerHTML = `<i class="fas fa-check-circle"></i> Você ganhou Frete Grátis!`;
                freeShippingProgress.classList.add('free-shipping-reached');
            }
        }
        
        function updateCartBadge() {
            const totalItems = shoppingCart.items.reduce((total, item) => total + item.quantity, 0);
            cartBadge.textContent = totalItems;
            cartBadge.style.display = totalItems > 0 ? 'flex' : 'none';
        }
        
        function renderCartItems() {
            cartContent.innerHTML = '';
            
            if (shoppingCart.items.length === 0) {
                cartContent.innerHTML = `
                    <div class="cart-empty">
                        <i class="fas fa-shopping-bag"></i>
                        <h3>Sua sacola está vazia</h3>
                        <p>Adicione produtos para começar sua compra</p>
                    </div>
                `;
                return;
            }
            
            const itemsContainer = document.createElement('div');
            itemsContainer.className = 'cart-items';
            
            shoppingCart.items.forEach(item => {
                const itemElement = document.createElement('div');
                itemElement.className = 'cart-item';
                
                itemElement.innerHTML = `
                    <div class="cart-item-image">
                        <img src="${item.image}" alt="${item.title}">
                    </div>
                    <div class="cart-item-details">
                        <div class="cart-item-title">${item.title}</div>
                        <div class="cart-item-price">R$ ${item.price.toLocaleString('pt-BR', {minimumFractionDigits: 2})}</div>
                        <div class="cart-quantity-controls">
                            <button class="cart-quantity-btn decrease-quantity" data-id="${item.id}">-</button>
                            <span class="cart-quantity">${item.quantity}</span>
                            <button class="cart-quantity-btn increase-quantity" data-id="${item.id}">+</button>
                        </div>
                    </div>
                    <button class="cart-item-remove" data-id="${item.id}">&times;</button>
                `;
                
                itemsContainer.appendChild(itemElement);
            });
            
            cartContent.appendChild(itemsContainer);
            
            // Adicionar eventos aos botões
            document.querySelectorAll('.decrease-quantity').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const productId = e.target.closest('.decrease-quantity').dataset.id;
                    const item = shoppingCart.items.find(item => item.id === productId);
                    if (item) {
                        updateCartItemQuantity(productId, item.quantity - 1);
                    }
                });
            });
            
            document.querySelectorAll('.increase-quantity').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const productId = e.target.closest('.increase-quantity').dataset.id;
                    const item = shoppingCart.items.find(item => item.id === productId);
                    if (item) {
                        updateCartItemQuantity(productId, item.quantity + 1);
                    }
                });
            });
            
            document.querySelectorAll('.cart-item-remove').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const productId = e.target.closest('.cart-item-remove').dataset.id;
                    removeFromCart(productId);
                });
            });
        }
        
        function clearCart() {
            if (shoppingCart.items.length === 0) {
                showToast('O carrinho já está vazio!', 'error');
                return;
            }
            
            if (confirm('Tem certeza que deseja limpar seu carrinho de compras?')) {
                shoppingCart.items = [];
                updateCartTotal();
                updateCartBadge();
                saveCartToLocalStorage();
                renderCartItems();
                showToast('Carrinho limpo com sucesso!');
            }
        }
        
        function saveCartToLocalStorage() {
            localStorage.setItem('guaraestoque_cart', JSON.stringify(shoppingCart));
        }
        
        function loadCartFromLocalStorage() {
            const savedCart = localStorage.getItem('guaraestoque_cart');
            if (savedCart) {
                shoppingCart = JSON.parse(savedCart);
                updateCartBadge();
                updateCartTotal();
            }
        }
        
        // ---------------------------------------------------------------
        // Finalizar Compra via WhatsApp: sem modal, sem pedir nome/telefone
        // aqui na vitrine. Monta a mensagem com os itens do carrinho e abre
        // o WhatsApp direto — o cliente informa nome, endereço e forma de
        // pagamento já conversando com a loja por lá.
        // ---------------------------------------------------------------
        function checkout() {
            if (shoppingCart.items.length === 0) {
                showToast('Adicione produtos ao carrinho antes de finalizar!', 'error');
                return;
            }
            if (!whatsappSettings.number) {
                showToast('Esta loja ainda não configurou o WhatsApp.', 'error');
                return;
            }

            const lines = ['Olá! Gostaria de fazer o seguinte pedido:', ''];
            shoppingCart.items.forEach(function (item, i) {
                const lineTotal = item.price * item.quantity;
                let piece = `${i + 1}. ${item.title} — R$ ${item.price.toLocaleString('pt-BR', {minimumFractionDigits: 2})}`;
                if (item.quantity > 1) {
                    piece += ` x ${item.quantity} = R$ ${lineTotal.toLocaleString('pt-BR', {minimumFractionDigits: 2})}`;
                }
                lines.push(piece);
            });
            lines.push('');
            lines.push(`Total: R$ ${shoppingCart.total.toLocaleString('pt-BR', {minimumFractionDigits: 2})}`);

            const whatsappUrl = `https://wa.me/${whatsappSettings.number}?text=${encodeURIComponent(lines.join('\n'))}`;

            // Sem pedido criado no banco (não coletamos nome/telefone aqui),
            // mas ainda registra o evento leve de estatística — é o que
            // alimenta o card "Pedidos" e o gráfico na página Estatísticas.
            trackStatEvent('order');

            closeCart();
            window.open(whatsappUrl, '_blank');
        }

        // ---------------------------------------------------------------
        // Estatísticas leves: visita à loja, visualização de produto e
        // adição ao carrinho. Falhas de rede aqui nunca devem quebrar a
        // navegação do cliente na vitrine.
        // ---------------------------------------------------------------
        // Identificador do visitante (não é nome/e-mail — só um código
        // aleatório salvo no navegador) para contar "online agora" e
        // visitantes únicos, sem precisar de login/cookie de sessão.
        function getVisitorId() {
            try {
                var key = 'll_visitor_id';
                var id = localStorage.getItem(key);
                if (!id) {
                    id = 'v_' + Math.random().toString(36).slice(2) + Date.now().toString(36);
                    localStorage.setItem(key, id);
                }
                return id;
            } catch (e) {
                return null;
            }
        }

        function trackStatEvent(type, refId) {
            if (!window.TENANT_SLUG) return;
            try {
                fetch(`/api/${window.TENANT_SLUG}/stats/track`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        type: type,
                        refId: refId || null,
                        visitorId: getVisitorId(),
                        referrer: document.referrer || null,
                    }),
                    keepalive: true,
                }).catch(function () {});
            } catch (e) { /* estatística é best-effort */ }
        }
        trackStatEvent('visit');

        // "Online agora": um pequeno sinal de vida a cada 25s enquanto a
        // aba estiver aberta e visível, pra alimentar o contador no painel
        // Estatísticas. Pausa quando a aba está em segundo plano, pra não
        // inflar o número com abas esquecidas abertas.
        (function setupHeartbeat() {
            var HEARTBEAT_MS = 25000;
            var timer = null;
            function beat() {
                if (document.visibilityState === 'visible') {
                    trackStatEvent('heartbeat');
                }
            }
            function start() {
                if (timer) return;
                beat();
                timer = setInterval(beat, HEARTBEAT_MS);
            }
            function stop() {
                if (timer) {
                    clearInterval(timer);
                    timer = null;
                }
            }
            document.addEventListener('visibilitychange', function () {
                if (document.visibilityState === 'visible') start();
                else stop();
            });
            start();
        })();
        
        // Event Listeners do Carrinho
        cartBtn.addEventListener('click', openCart);
        closeCartBtn.addEventListener('click', closeCart);
        clearCartBtn.addEventListener('click', clearCart);
        checkoutBtn.addEventListener('click', checkout);
        continueShoppingBtn.addEventListener('click', hideMiniCart);
        goToCartBtn.addEventListener('click', () => {
            hideMiniCart();
            openCart();
        });
        
        // Fechar mini-carrinho ao clicar no overlay
        miniCartOverlay.addEventListener('click', hideMiniCart);
        
        // Função para alternar entre abas do admin
        function switchAdminTab(tabId) {
            // Remover classe active de todas as abas e conteúdos
            adminTabs.forEach(tab => tab.classList.remove('active'));
            adminContents.forEach(content => content.classList.remove('active'));
            
            // Adicionar classe active à aba selecionada e seu conteúdo
            const selectedTab = document.querySelector(`.admin-tab[data-tab="${tabId}"]`);
            const selectedContent = document.getElementById(`tab-${tabId}`);
            
            if (selectedTab && selectedContent) {
                selectedTab.classList.add('active');
                selectedContent.classList.add('active');
                currentAdminTab = tabId;
                
                // Se for a aba de gerenciar categorias, carregar as categorias
                if (tabId === 'manage-categories') {
                    loadCategoriesManagement();
                }
                
                // Controlar visibilidade dos produtos baseado na aba
                const productsSection = document.getElementById('products-section');
                const productsGrid = document.getElementById('products-grid');
                
                if (auth.currentUser) {
                    if (tabId === 'manage-products') {
                        if (productsSection) productsSection.style.display = '';
                        if (productsGrid) productsGrid.style.display = '';
                    } else {
                        if (productsSection) productsSection.style.display = 'none';
                        if (productsGrid) productsGrid.style.display = 'none';
                    }
                }
            }
        }
        
        // Event Listeners das abas do admin
        adminTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const tabId = tab.getAttribute('data-tab');
                switchAdminTab(tabId);
            });
        });
        
        // Event Listeners
        addProductBtn.addEventListener('click', () => {
            isEditingProduct = false;
            document.getElementById('product-modal-title').textContent = 'Adicionar Novo Produto';
            productFormSubmit.textContent = 'Adicionar Produto';
            editProductId.value = '';
            productForm.reset();
            
            // Mostrar/ocultar opção de frete grátis baseado na configuração
            if (systemSettings.enableFreeShipping) {
                productFreeShippingGroup.style.display = 'block';
            } else {
                productFreeShippingGroup.style.display = 'none';
            }
            productFreeShippingCheckbox.checked = false;
            
            // Resetar toggles de promoção e descrição para o padrão
            if (productPromoToggle) productPromoToggle.checked = false;
            if (productOldPriceGroup) productOldPriceGroup.style.display = 'none';
            if (productDescriptionToggle) productDescriptionToggle.checked = true;
            if (productDescriptionGroup) productDescriptionGroup.style.display = 'block';
            if (productDescriptionInput) productDescriptionInput.required = true;
            
            imagePreviewContainer.innerHTML = '';
            selectedFiles = [];
            currentEditingProductImages = [];
            addProductModal.style.display = 'flex';
        });
        
        addCategoryBtn.addEventListener('click', () => {
            addCategoryModal.style.display = 'flex';
        });

        // Minha Conta: trocar a própria senha (fora do fluxo de "esqueci senha")
        const changePasswordForm = document.getElementById('change-password-form');
        const changePasswordMessage = document.getElementById('change-password-message');
        if (changePasswordForm) {
            changePasswordForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                const current_password = document.getElementById('current-password').value;
                const new_password = document.getElementById('new-password').value;

                changePasswordMessage.style.color = 'var(--text)';
                changePasswordMessage.textContent = 'Salvando...';

                try {
                    const response = await fetch(`/api/${window.TENANT_SLUG}/auth/change-password`, {
                        method: 'POST',
                        credentials: 'same-origin',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ current_password, new_password }),
                    });
                    const body = await response.json().catch(() => ({}));
                    if (!response.ok) {
                        throw new Error(body.error || 'Não foi possível trocar a senha.');
                    }
                    changePasswordMessage.style.color = 'var(--primary)';
                    changePasswordMessage.textContent = 'Senha alterada com sucesso!';
                    changePasswordForm.reset();
                } catch (error) {
                    changePasswordMessage.style.color = '#cc0000';
                    changePasswordMessage.textContent = error.message;
                }
            });
        }

        closeModals.forEach(btn => {
            btn.addEventListener('click', () => {
                loginModal.style.display = 'none';
                addProductModal.style.display = 'none';
                addCategoryModal.style.display = 'none';
                quickStockModal.style.display = 'none';
                // Fecha também qualquer outro modal genérico que contenha o botão clicado.
                const parentModal = btn.closest('.modal');
                if (parentModal) parentModal.style.display = 'none';
            });
        });
        
        galleryClose.addEventListener('click', () => {
            galleryModal.style.display = 'none';
        });
        
        productModalClose.addEventListener('click', () => {
            productModal.style.display = 'none';
        });
        
        // WhatsApp button
        whatsappBtn.addEventListener('click', () => {
            const whatsappUrl = `https://wa.me/${whatsappSettings.number}`;
            window.open(whatsappUrl, '_blank');
        });
        
        // Controles de estoque rápido
        decreaseStockBtn.addEventListener('click', () => {
            const currentValue = parseInt(quickStockQuantity.value) || 0;
            if (currentValue > 0) {
                quickStockQuantity.value = currentValue - 1;
            }
        });
        
        increaseStockBtn.addEventListener('click', () => {
            const currentValue = parseInt(quickStockQuantity.value) || 0;
            quickStockQuantity.value = currentValue + 1;
        });
        
        // Salvar configurações do sistema
        saveSystemSettingsBtn.addEventListener('click', () => {
            saveSystemSettings();
        });
        
        // Restaurar configurações padrão
        resetSystemSettingsBtn.addEventListener('click', () => {
            if (confirm('Tem certeza que deseja restaurar todas as configurações para os valores padrão?\n\nEsta ação irá redefinir:\n• Configurações gerais do sistema\n• Configurações de contato\n• Configurações do rodapé\n• Configurações de exibição\n• Configurações de tema\n\nEsta ação não pode ser desfeita.')) {
                resetSystemSettings();
            }
        });

        // ============================================================
        // NAVEGAÇÃO LATERAL DE CONFIGURAÇÕES
        // ============================================================
        const settingsNavItems = document.querySelectorAll('.settings-nav-item');
        const settingsPanelsContainer = document.getElementById('settings-panels');
        const settingsUnsavedIndicator = document.getElementById('settings-unsaved-indicator');

        settingsNavItems.forEach(item => {
            item.addEventListener('click', () => {
                const targetId = item.getAttribute('data-settings-section');
                const targetEl = document.getElementById(targetId);
                if (targetEl) {
                    targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
                settingsNavItems.forEach(i => i.classList.remove('active'));
                item.classList.add('active');
            });
        });

        // Destacar automaticamente o item de nav conforme a rolagem do painel
        if (settingsPanelsContainer && 'IntersectionObserver' in window) {
            const settingsSectionObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const navItem = document.querySelector(`.settings-nav-item[data-settings-section="${entry.target.id}"]`);
                        if (navItem) {
                            settingsNavItems.forEach(i => i.classList.remove('active'));
                            navItem.classList.add('active');
                        }
                    }
                });
            }, { root: null, rootMargin: '-20% 0px -70% 0px', threshold: 0 });

            document.querySelectorAll('.settings-section').forEach(section => {
                settingsSectionObserver.observe(section);
            });
        }

        // Indicador de alterações não salvas: aparece quando algum campo de configurações é alterado
        if (settingsPanelsContainer && settingsUnsavedIndicator) {
            settingsPanelsContainer.addEventListener('input', () => {
                settingsUnsavedIndicator.classList.add('visible');
            });
            settingsPanelsContainer.addEventListener('change', () => {
                settingsUnsavedIndicator.classList.add('visible');
            });
            saveSystemSettingsBtn.addEventListener('click', () => {
                settingsUnsavedIndicator.classList.remove('visible');
            });
            resetSystemSettingsBtn.addEventListener('click', () => {
                settingsUnsavedIndicator.classList.remove('visible');
            });
        }
        
        // Controles de exibição (itens por página)
        displayControls.forEach(btn => {
            btn.addEventListener('click', () => {
                displayControls.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                itemsPerPage = parseInt(btn.getAttribute('data-items'));
                filterAndDisplayProducts();
                
                // Salvar configuração se admin
                if (auth.currentUser) {
                    saveSystemSettings();
                }
            });
        });
        
        // Botão de exportação
        exportProductsBtn.addEventListener('click', () => {
            exportProductsToCSV();
        });
        
        // Botão de backup
        backupSystemBtn.addEventListener('click', () => {
            createSystemBackup();
        });
        
        // Função de busca
        searchButton.addEventListener('click', performSearch);
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                performSearch();
            }
        });
        
        function performSearch() {
            if (!enableSearch.checked) return;
            
            currentSearchQuery = searchInput.value.trim().toLowerCase();
            filterAndDisplayProducts();
        }
        
        function filterAndDisplayProducts() {
            loadingSpinner.style.display = 'block';
            productsGrid.innerHTML = '';
            productsGrid.appendChild(loadingSpinner);
            
            setTimeout(() => {
                let filteredProducts = allProducts;
                
                // Filtrar por categoria
                if (currentCategory !== 'all') {
                    filteredProducts = filteredProducts.filter(product => 
                        product.category === currentCategory
                    );
                }
                
                // Filtrar por busca
                if (currentSearchQuery) {
                    filteredProducts = filteredProducts.filter(product => 
                        product.title.toLowerCase().includes(currentSearchQuery) ||
                        (product.description || '').toLowerCase().includes(currentSearchQuery) ||
                        (product.brand && product.brand.toLowerCase().includes(currentSearchQuery)) ||
                        product.category.toLowerCase().includes(currentSearchQuery)
                    );
                }
                
                // Ordenação padrão do catálogo (configurável em Exibição)
                const sortMode = (systemSettings && systemSettings.catalogSortDefault) || 'relevance';
                filteredProducts = applyCatalogSort(filteredProducts, sortMode);
                
                // Limitar por página
                const paginatedProducts = filteredProducts.slice(0, itemsPerPage);
                
                // Exibir produtos filtrados
                productsGrid.innerHTML = '';
                
                if (paginatedProducts.length === 0) {
                    productsGrid.innerHTML = `
                        <div class="search-empty">
                            <i class="fas fa-search"></i>
                            <h3>Nenhum produto encontrado</h3>
                            <p>${currentSearchQuery ? `Não encontramos resultados para "${currentSearchQuery}"` : 'Não há produtos nesta categoria.'}</p>
                            ${currentSearchQuery ? `<button id="clear-search" class="btn btn-primary" style="margin-top: 1rem;">Limpar busca</button>` : ''}
                        </div>
                    `;
                    
                    if (currentSearchQuery) {
                        document.getElementById('clear-search').addEventListener('click', () => {
                            searchInput.value = '';
                            currentSearchQuery = '';
                            filterAndDisplayProducts();
                        });
                    }
                } else {
                    paginatedProducts.forEach(product => {
                        displayProductCard(product.id, product, product.images);
                    });
                }
                
                loadingSpinner.style.display = 'none';
            }, 300);
        }
        
        window.addEventListener('click', (e) => {
            if (e.target === loginModal) {
                loginModal.style.display = 'none';
            }
            if (e.target === addProductModal) {
                addProductModal.style.display = 'none';
            }
            if (e.target === addCategoryModal) {
                addCategoryModal.style.display = 'none';
            }
            if (e.target === galleryModal) {
                galleryModal.style.display = 'none';
            }
            if (e.target === productModal) {
                productModal.style.display = 'none';
            }
            if (e.target === quickStockModal) {
                quickStockModal.style.display = 'none';
            }
            if (e.target === miniCartOverlay) {
                hideMiniCart();
            }
        });
        
        // Preview das imagens selecionadas
        imageUpload.addEventListener('change', function(e) {
            const files = e.target.files;
            selectedFiles = Array.from(files);
            imagePreviewContainer.innerHTML = '';
            
            if (files.length > 0) {
                for (let i = 0; i < files.length; i++) {
                    const file = files[i];
                    const reader = new FileReader();
                    
                    reader.onload = function(event) {
                        const previewDiv = document.createElement('div');
                        previewDiv.className = 'image-preview';
                        previewDiv.innerHTML = `
                            <img src="${event.target.result}" alt="Preview">
                            <button type="button" class="remove-image" data-index="${i}">&times;</button>
                        `;
                        imagePreviewContainer.appendChild(previewDiv);
                    };
                    
                    reader.readAsDataURL(file);
                }
            }
        });
        
        // Remover imagem selecionada
        imagePreviewContainer.addEventListener('click', (e) => {
            if (e.target.classList.contains('remove-image')) {
                const index = parseInt(e.target.getAttribute('data-index'));
                selectedFiles.splice(index, 1);
                
                // Recriar a lista de visualização
                imagePreviewContainer.innerHTML = '';
                if (selectedFiles.length > 0) {
                    selectedFiles.forEach((file, i) => {
                        const reader = new FileReader();
                        reader.onload = function(event) {
                            const previewDiv = document.createElement('div');
                            previewDiv.className = 'image-preview';
                            previewDiv.innerHTML = `
                                <img src="${event.target.result}" alt="Preview">
                                <button type="button" class="remove-image" data-index="${i}">&times;</button>
                            `;
                            imagePreviewContainer.appendChild(previewDiv);
                        };
                        reader.readAsDataURL(file);
                    });
                }
            }
        });
        
        // Navegação da galeria
        galleryPrev.addEventListener('click', () => {
            if (currentGalleryImages.length > 0) {
                currentImageIndex = (currentImageIndex - 1 + currentGalleryImages.length) % currentGalleryImages.length;
                updateGalleryImage();
            }
        });
        
        galleryNext.addEventListener('click', () => {
            if (currentGalleryImages.length > 0) {
                currentImageIndex = (currentImageIndex + 1) % currentGalleryImages.length;
                updateGalleryImage();
            }
        });
        
        // Atualizar imagem principal da galeria
        function updateGalleryImage() {
            if (currentGalleryImages.length > 0) {
                galleryMainImage.src = currentGalleryImages[currentImageIndex];
                imageCount.textContent = `${currentImageIndex + 1} / ${currentGalleryImages.length}`;
                
                // Atualizar thumbnails ativos
                const thumbnails = galleryThumbnails.querySelectorAll('.gallery-thumbnail');
                thumbnails.forEach((thumb, index) => {
                    if (index === currentImageIndex) {
                        thumb.classList.add('active');
                    } else {
                        thumb.classList.remove('active');
                    }
                });
            }
        }
        
        // Atualizar thumbnails no modal de produto
        function updateProductModalThumbnails() {
            productModalThumbnails.innerHTML = '';
            
            currentProductModalImages.forEach((img, index) => {
                const thumbnail = document.createElement('div');
                thumbnail.className = `product-modal-thumbnail ${index === currentProductModalIndex ? 'active' : ''}`;
                thumbnail.innerHTML = `<img src="${img}" alt="Thumbnail ${index + 1}">`;
                thumbnail.addEventListener('click', () => {
                    currentProductModalIndex = index;
                    productModalMainImg.src = img;
                    updateProductModalThumbnails();
                });
                productModalThumbnails.appendChild(thumbnail);
            });
        }
        
        // Login form
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            auth.signInWithEmailAndPassword(email, password)
                .then((userCredential) => {
                    loginModal.style.display = 'none';
                    loginMessage.textContent = '';
                    loginForm.reset();
                    showToast('Login realizado com sucesso!');
                })
                .catch((error) => {
                    loginMessage.textContent = 'Erro no login: ' + error.message;
                });
        });
        
        // Toggle: Ativar promoção (mostra/oculta o campo de preço original)
        if (productPromoToggle) {
            productPromoToggle.addEventListener('change', () => {
                if (productPromoToggle.checked) {
                    productOldPriceGroup.style.display = 'block';
                } else {
                    productOldPriceGroup.style.display = 'none';
                    document.getElementById('product-old-price').value = '';
                }
            });
        }

        // Toggle: Habilitar descrição (mostra/oculta e torna obrigatório o campo de descrição)
        if (productDescriptionToggle) {
            productDescriptionToggle.addEventListener('change', () => {
                if (productDescriptionToggle.checked) {
                    productDescriptionGroup.style.display = 'block';
                    productDescriptionInput.required = true;
                } else {
                    productDescriptionGroup.style.display = 'none';
                    productDescriptionInput.required = false;
                    productDescriptionInput.value = '';
                }
            });
        }

        // Product form
        productForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            // Get form values
            const title = document.getElementById('product-title').value;
            const price = document.getElementById('product-price').value;
            const oldPrice = (productPromoToggle && productPromoToggle.checked) ? document.getElementById('product-old-price').value : '';
            const category = document.getElementById('product-category').value;
            const description = (productDescriptionToggle && productDescriptionToggle.checked) ? document.getElementById('product-description').value : '';
            const stock = document.getElementById('product-stock').value;
            const brand = document.getElementById('product-brand').value;
            const freeShipping = productFreeShippingCheckbox.checked;
            
            // Determine stock status
            let stockStatus = 'in-stock';
            if (stock <= 0) {
                stockStatus = 'out-of-stock';
            } else if (stock <= 5) {
                stockStatus = 'low-stock';
            }
            
            // Se estamos editando um produto existente
            if (isEditingProduct && currentEditingProductId) {
                productMessage.textContent = 'Atualizando produto...';
                productMessage.style.color = 'var(--text)';
                
                try {
                    // Preparar dados para atualização
                    const updateData = {
                        title,
                        price: parseFloat(price),
                        oldPrice: oldPrice ? parseFloat(oldPrice) : null,
                        category,
                        description,
                        stock: parseInt(stock),
                        stockStatus,
                        brand: brand || '',
                        freeShipping: freeShipping,
                        updatedAt: appBackend.firestore.FieldValue.serverTimestamp()
                    };
                    
                    // Se há novas imagens, fazer upload
                    if (selectedFiles.length > 0) {
                        const imageData = [];
                        for (const file of selectedFiles) {
                            const imageInfo = await uploadImageToServer(file);
                            imageData.push(imageInfo);
                        }
                        
                        updateData.imageUrls = [...currentEditingProductImages, ...imageData.map(img => img.url)];
                        updateData.imageDeleteHashes = updateData.imageDeleteHashes ? [...updateData.imageDeleteHashes, ...imageData.map(img => img.deleteHash)] : imageData.map(img => img.deleteHash);
                    }
                    
                    // Atualizar produto no Firestore
                    await db.collection('products').doc(currentEditingProductId).update(updateData);
                    
                    productMessage.textContent = 'Produto atualizado com sucesso!';
                    productMessage.style.color = 'var(--success)';
                    showToast('Produto atualizado com sucesso!');
                    
                    setTimeout(() => {
                        addProductModal.style.display = 'none';
                        productMessage.textContent = '';
                        productForm.reset();
                        imagePreviewContainer.innerHTML = '';
                        selectedFiles = [];
                        currentEditingProductImages = [];
                        loadProducts();
                    }, 1500);
                    
                } catch (error) {
                    productMessage.textContent = 'Erro ao atualizar produto: ' + error.message;
                    productMessage.style.color = 'var(--primary)';
                    console.error('Erro detalhado:', error);
                }
                
            } else {
                // Adicionar novo produto
                
                // Verificar se imagens foram selecionadas
                if (selectedFiles.length === 0) {
                    productMessage.textContent = 'Por favor, selecione pelo menos uma imagem.';
                    productMessage.style.color = 'var(--primary)';
                    return;
                }
                
                // Upload das imagens para o servidor local
                productMessage.textContent = 'Enviando imagens...';
                productMessage.style.color = 'var(--text)';
                
                try {
                    const imageData = [];
                    for (const file of selectedFiles) {
                        const imageInfo = await uploadImageToServer(file);
                        imageData.push(imageInfo);
                    }
                    
                    // Gerar um ID único para o produto
                    const productId = db.collection('products').doc().id;
                    
                    // Add product to Firestore
                    db.collection('products').doc(productId).set({
                        title,
                        price: parseFloat(price),
                        oldPrice: oldPrice ? parseFloat(oldPrice) : null,
                        category,
                        description,
                        stock: parseInt(stock),
                        stockStatus,
                        brand: brand || '',
                        freeShipping: freeShipping,
                        imageUrls: imageData.map(img => img.url),
                        imageDeleteHashes: imageData.map(img => img.deleteHash),
                        productId: productId, // Salvar o ID como campo também
                        createdAt: appBackend.firestore.FieldValue.serverTimestamp()
                    })
                    .then(() => {
                        productMessage.textContent = 'Produto adicionado com sucesso!';
                        productMessage.style.color = 'var(--success)';
                        productForm.reset();
                        imagePreviewContainer.innerHTML = '';
                        selectedFiles = [];
                        showToast('Produto adicionado com sucesso!');
                        setTimeout(() => {
                            addProductModal.style.display = 'none';
                            productMessage.textContent = '';
                            loadProducts();
                        }, 1500);
                    })
                    .catch((error) => {
                        productMessage.textContent = 'Erro ao adicionar produto: ' + error.message;
                        productMessage.style.color = 'var(--primary)';
                        console.error('Erro detalhado:', error);
                    });
                    
                } catch (error) {
                    productMessage.textContent = 'Erro no upload das imagens: ' + error.message;
                    productMessage.style.color = 'var(--primary)';
                }
            }
        });
        
        // Formulário de categoria
        categoryForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const categoryName = document.getElementById('category-name').value.trim();
            
            // Verificar se categoria já existe
            const categoryExists = allCategories.some(cat => 
                cat.name.toLowerCase() === categoryName.toLowerCase()
            );
            
            if (categoryExists) {
                categoryMessage.textContent = 'Esta categoria já existe.';
                categoryMessage.style.color = 'var(--primary)';
                return;
            }
            
            // Adicionar categoria sem emoji
            db.collection('categories').add({
                name: categoryName,
                createdAt: appBackend.firestore.FieldValue.serverTimestamp()
            })
            .then(() => {
                categoryMessage.textContent = 'Categoria criada com sucesso!';
                categoryMessage.style.color = 'var(--success)';
                categoryForm.reset();
                showToast('Categoria criada com sucesso!');
                setTimeout(() => {
                    addCategoryModal.style.display = 'none';
                    categoryMessage.textContent = '';
                    loadCategories();
                    // Recarregar a seção de gerenciamento se estiver na aba de categorias
                    if (currentAdminTab === 'manage-categories') {
                        loadCategoriesManagement();
                    }
                }, 1500);
            })
            .catch((error) => {
                categoryMessage.textContent = 'Erro ao criar categoria: ' + error.message;
                categoryMessage.style.color = 'var(--primary)';
            });
        });
        
        // Formulário de estoque rápido
        quickStockForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const productId = quickStockProductId.value;
            const newStock = parseInt(quickStockQuantity.value);
            
            if (isNaN(newStock) || newStock < 0) {
                showToast('Quantidade inválida', 'error');
                return;
            }
            
            // Determine stock status
            let stockStatus = 'in-stock';
            if (newStock <= 0) {
                stockStatus = 'out-of-stock';
            } else if (newStock <= 5) {
                stockStatus = 'low-stock';
            }
            
            db.collection('products').doc(productId).update({
                stock: newStock,
                stockStatus: stockStatus,
                updatedAt: appBackend.firestore.FieldValue.serverTimestamp()
            })
            .then(() => {
                showToast('Estoque atualizado com sucesso!');
                quickStockModal.style.display = 'none';
                loadProducts();
            })
            .catch((error) => {
                showToast('Erro ao atualizar estoque: ' + error.message, 'error');
            });
        });
        
        // Função para fazer upload da imagem para o próprio servidor
        // (arquivo fica salvo em disco, na máquina que hospeda o backend)
        async function uploadImageToServer(imageFile) {
            const formData = new FormData();
            formData.append('image', imageFile);

            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 30000);

            let response;
            try {
                response = await fetch(`/api/${window.TENANT_SLUG}/upload`, {
                    method: 'POST',
                    credentials: 'same-origin',
                    body: formData,
                    signal: controller.signal
                });
            } catch (error) {
                if (error.name === 'AbortError') {
                    throw new Error('O envio da imagem demorou demais e foi cancelado. Tente novamente.');
                }
                throw new Error('Não foi possível conectar ao servidor para enviar a imagem. Verifique se o servidor está no ar e tente novamente.');
            } finally {
                clearTimeout(timeoutId);
            }

            const data = await response.json().catch(() => ({}));

            if (response.ok) {
                return {
                    url: data.url,
                    deleteHash: data.deleteHash
                };
            } else {
                throw new Error(data.error || 'Falha no upload da imagem');
            }
        }

        // Função para deletar imagem salva no servidor
        async function deleteImageFromServer(deleteHash) {
            if (!deleteHash) {
                console.error('Nenhum identificador de arquivo fornecido');
                return false;
            }

            try {
                const response = await fetch(`/api/${window.TENANT_SLUG}/upload/${deleteHash}`, {
                    method: 'DELETE',
                    credentials: 'same-origin'
                });

                const data = await response.json();

                if (data.ok) {
                    console.log('Imagem deletada com sucesso do servidor:', deleteHash);
                    return true;
                } else {
                    console.error('Falha ao deletar imagem do servidor:', data.error);
                    return false;
                }
            } catch (error) {
                console.error('Erro ao deletar imagem do servidor:', error);
                return false;
            }
        }
        
        // Função para deletar categoria
        async function deleteCategory(categoryId) {
            if (!confirm('Tem certeza que deseja excluir esta categoria? Os produtos desta categoria permanecerão, mas ficarão sem categoria associada.')) {
                return;
            }
            
            try {
                await db.collection('categories').doc(categoryId).delete();
                showToast('Categoria excluída com sucesso!');
                loadCategories();
                if (currentAdminTab === 'manage-categories') {
                    loadCategoriesManagement();
                }
            } catch (error) {
                console.error('Erro ao excluir categoria:', error);
                showToast('Erro ao excluir categoria: ' + error.message, 'error');
            }
        }
        
        // Função para deletar produto
        async function deleteProduct(productId) {
            if (!confirm('Tem certeza que deseja apagar este produto? Esta ação não pode ser desfeita.')) {
                return;
            }

            try {
                showToast('Apagando produto...', 'info');

                const productRef = db.collection('products').doc(productId);
                const doc = await productRef.get();

                if (!doc.exists) {
                    showToast('Produto não encontrado.', 'error');
                    return;
                }

                const productData = doc.data();
                const deleteHashes = productData.imageDeleteHashes || [];

                // Deletar imagens do servidor local
                if (deleteHashes.length > 0) {
                    console.log(`Tentando apagar ${deleteHashes.length} imagens do servidor.`);
                    const deletePromises = deleteHashes.map(hash => deleteImageFromServer(hash));
                    await Promise.all(deletePromises);
                }

                // Deletar produto do Firestore
                await productRef.delete();

                showToast('Produto apagado com sucesso!');
                loadProducts(); // Recarregar a lista de produtos

            } catch (error) {
                console.error('Erro ao apagar produto:', error);
                showToast('Erro ao apagar produto: ' + error.message, 'error');
            }
        }

        // Função para abrir modal de edição de produto
        function openEditProductModal(product) {
            isEditingProduct = true;
            currentEditingProductId = product.id;
            currentEditingProductImages = product.images || [];
            
            document.getElementById('product-modal-title').textContent = 'Editar Produto';
            productFormSubmit.textContent = 'Atualizar Produto';
            editProductId.value = product.id;
            
            // Preencher formulário com dados do produto
            document.getElementById('product-title').value = product.title;
            document.getElementById('product-price').value = product.price;
            document.getElementById('product-old-price').value = product.oldPrice || '';
            document.getElementById('product-category').value = product.category;
            document.getElementById('product-description').value = product.description || '';

            // Configurar toggle de promoção conforme existência de preço original
            if (productPromoToggle) {
                productPromoToggle.checked = !!product.oldPrice;
                productOldPriceGroup.style.display = product.oldPrice ? 'block' : 'none';
            }

            // Configurar toggle de descrição conforme existência de descrição
            if (productDescriptionToggle) {
                const hasDescription = !!(product.description && product.description.trim());
                productDescriptionToggle.checked = hasDescription;
                productDescriptionGroup.style.display = hasDescription ? 'block' : 'none';
                productDescriptionInput.required = hasDescription;
            }

            document.getElementById('product-stock').value = product.stock;
            document.getElementById('product-brand').value = product.brand || '';
            
            // Configurar checkbox de frete grátis
            if (systemSettings.enableFreeShipping) {
                productFreeShippingGroup.style.display = 'block';
                productFreeShippingCheckbox.checked = product.freeShipping === true;
            } else {
                productFreeShippingGroup.style.display = 'none';
            }
            
            // Mostrar imagens existentes
            imagePreviewContainer.innerHTML = '';
            if (product.images && product.images.length > 0) {
                product.images.forEach((img, index) => {
                    const previewDiv = document.createElement('div');
                    previewDiv.className = 'image-preview';
                    previewDiv.innerHTML = `
                        <img src="${img}" alt="Preview ${index + 1}">
                        <button type="button" class="remove-image" data-index="${index}" data-existing="true">&times;</button>
                    `;
                    imagePreviewContainer.appendChild(previewDiv);
                });
            }
            
            addProductModal.style.display = 'flex';
        }
        
        // Função para abrir modal de estoque rápido
        function openQuickStockModal(product) {
            quickStockProductName.textContent = `Atualizar estoque de: ${product.title}`;
            quickStockQuantity.value = product.stock;
            quickStockProductId.value = product.id;
            quickStockModal.style.display = 'flex';
        }
        
        // Função para gerar link único do produto
        function generateProductLink(productId) {
            const baseUrl = window.location.origin + window.location.pathname;
            return `${baseUrl}?product=${productId}`;
        }
        
        // Função para criar botões de compartilhamento
        function createShareButtons(product) {
            shareButtonsContainer.innerHTML = '';
            const productLink = generateProductLink(product.id);
            const productTitle = encodeURIComponent(product.title);
            const productDescription = encodeURIComponent((product.description || '').substring(0, 100) + '...');
            
            // WhatsApp
            const whatsappBtn = document.createElement('a');
            whatsappBtn.className = 'share-btn whatsapp-share';
            whatsappBtn.href = `https://wa.me/?text=${encodeURIComponent(`Confira este produto: ${product.title} - ${productLink}`)}`;
            whatsappBtn.target = '_blank';
            whatsappBtn.innerHTML = '<i class="fab fa-whatsapp"></i> WhatsApp';
            shareButtonsContainer.appendChild(whatsappBtn);
            
            // Facebook
            const facebookBtn = document.createElement('a');
            facebookBtn.className = 'share-btn facebook-share';
            facebookBtn.href = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(productLink)}&quote=${productTitle}`;
            facebookBtn.target = '_blank';
            facebookBtn.innerHTML = '<i class="fab fa-facebook-f"></i> Facebook';
            shareButtonsContainer.appendChild(facebookBtn);
            
            // Instagram (link para app ou web)
            const instagramBtn = document.createElement('a');
            instagramBtn.className = 'share-btn instagram-share';
            instagramBtn.href = `https://www.instagram.com/?url=${encodeURIComponent(productLink)}`;
            instagramBtn.target = '_blank';
            instagramBtn.innerHTML = '<i class="fab fa-instagram"></i> Instagram';
            shareButtonsContainer.appendChild(instagramBtn);
            
            // Copiar link
            const copyLinkBtn = document.createElement('a');
            copyLinkBtn.className = 'share-btn copy-link-share';
            copyLinkBtn.href = '#';
            copyLinkBtn.innerHTML = '<i class="fas fa-copy"></i> Copiar Link';
            copyLinkBtn.addEventListener('click', (e) => {
                e.preventDefault();
                copyToClipboard(productLink);
            });
            shareButtonsContainer.appendChild(copyLinkBtn);
        }
        
        // Função para copiar link para a área de transferência
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                showToast('Link copiado para a área de transferência!');
            }).catch(err => {
                console.error('Erro ao copiar: ', err);
                showToast('Erro ao copiar link', 'error');
            });
        }
        
        // Verificar se há um parâmetro de produto na URL
        function checkUrlForProduct() {
            const urlParams = new URLSearchParams(window.location.search);
            const productId = urlParams.get('product');
            
            if (productId) {
                // Buscar produto pelo ID
                db.collection('products').doc(productId).get()
                    .then(doc => {
                        if (doc.exists) {
                            const product = doc.data();
                            openProductModal({
                                id: productId,
                                ...product,
                                images: product.imageUrls || []
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Erro ao buscar produto:', error);
                    });
            }
        }
        
        // Função para criar exibição de preços com desconto (preço antigo acima do atual)
        function createPriceDisplay(product) {
            const priceContainer = document.createElement('div');
            priceContainer.className = 'price-old-above';
            
            if (product.oldPrice && product.oldPrice > product.price) {
                // Calcular porcentagem de desconto
                const discountPercent = calculateDiscountPercentage(product.oldPrice, product.price);
                
                // Preço original riscado acima (vermelho)
                const oldPriceSpan = document.createElement('span');
                oldPriceSpan.className = 'old-price';
                oldPriceSpan.textContent = `De: R$ ${product.oldPrice.toLocaleString('pt-BR', {minimumFractionDigits: 2})}`;
                priceContainer.appendChild(oldPriceSpan);
                
                // Preço atual em preto (maior)
                const priceSpan = document.createElement('span');
                priceSpan.className = 'current-price';
                priceSpan.textContent = `Por: R$ ${product.price.toLocaleString('pt-BR', {minimumFractionDigits: 2})}`;
                priceContainer.appendChild(priceSpan);
                
                // Badge de desconto VERDE
                const discountBadge = document.createElement('span');
                discountBadge.className = 'discount-percentage';
                discountBadge.textContent = `${discountPercent}% OFF`;
                discountBadge.style.marginTop = '5px';
                discountBadge.style.display = 'inline-block';
                priceContainer.appendChild(discountBadge);
                
                // Texto de economia
                const savings = product.oldPrice - product.price;
                const savingsSpan = document.createElement('span');
                savingsSpan.style.color = 'var(--success)';
                savingsSpan.style.fontSize = '0.9rem';
                savingsSpan.style.marginTop = '3px';
                savingsSpan.textContent = `Economize R$ ${savings.toLocaleString('pt-BR', {minimumFractionDigits: 2})}`;
                priceContainer.appendChild(savingsSpan);
            } else {
                // Apenas preço atual em preto
                const priceSpan = document.createElement('span');
                priceSpan.className = 'current-price';
                priceSpan.textContent = `R$ ${product.price.toLocaleString('pt-BR', {minimumFractionDigits: 2})}`;
                priceContainer.appendChild(priceSpan);
            }
            
            return priceContainer;
        }
        
        // Função para abrir modal de produto expandido
        function openProductModal(product) {
            currentProductForSharing = product;
            trackStatEvent('product_view', product.id);
            
            // Definir imagens
            currentProductModalImages = product.images;
            currentProductModalIndex = 0;
            
            // Atualizar imagem principal
            productModalMainImg.src = product.images[0];
            
            // Atualizar thumbnails
            updateProductModalThumbnails();
            
            // Atualizar informações do produto
            productModalTitleElem.textContent = product.title;
            
            // Atualizar preços (com preço antigo acima)
            productModalPriceContainer.innerHTML = '';
            productModalPriceContainer.appendChild(createPriceDisplay(product));
            
            // Determinar texto do status do estoque
            let stockText = '';
            let stockClass = '';
            
            if (showStockStatus.checked) {
                productModalStock.style.display = '';
                switch(product.stockStatus) {
                    case 'in-stock':
                        stockText = `Em estoque (${product.stock} unidades)`;
                        stockClass = 'in-stock';
                        break;
                    case 'low-stock':
                        stockText = `Estoque baixo (${product.stock} unidades)`;
                        stockClass = 'low-stock';
                        break;
                    case 'out-of-stock':
                        stockText = 'Fora de estoque';
                        stockClass = 'out-of-stock';
                        break;
                    default:
                        if (product.stock > 5) {
                            stockText = `Em estoque (${product.stock} unidades)`;
                            stockClass = 'in-stock';
                        } else if (product.stock > 0) {
                            stockText = `Estoque baixo (${product.stock} unidades)`;
                            stockClass = 'low-stock';
                        } else {
                            stockText = 'Fora de estoque';
                            stockClass = 'out-of-stock';
                        }
                }
                productModalStock.textContent = stockText;
                productModalStock.className = `product-modal-stock ${stockClass}`;
            } else {
                productModalStock.style.display = 'none';
            }
            
            // Atualizar descrição
            if (product.description && product.description.trim()) {
                productModalDescription.textContent = product.description;
                productModalDescription.style.display = 'block';
            } else {
                productModalDescription.textContent = '';
                productModalDescription.style.display = 'none';
            }
            
            // Atualizar features
            productModalFeatures.innerHTML = '';
            
            // Adicionar categoria (sem emoji)
            const categoryFeature = document.createElement('div');
            categoryFeature.className = 'product-modal-feature';
            categoryFeature.innerHTML = `<i class="fas fa-tag"></i> ${product.category}`;
            productModalFeatures.appendChild(categoryFeature);
            
            // Adicionar marca se existir
            if (product.brand && !hideProductBrand.checked) {
                const brandFeature = document.createElement('div');
                brandFeature.className = 'product-modal-feature';
                brandFeature.innerHTML = `<i class="fas fa-industry"></i> ${product.brand}`;
                productModalFeatures.appendChild(brandFeature);
            }
            
            // Adicionar feature de frete grátis se aplicável
            if (product.freeShipping) {
                const freeShippingFeature = document.createElement('div');
                freeShippingFeature.className = 'product-modal-feature';
                freeShippingFeature.style.color = 'var(--success)';
                freeShippingFeature.style.fontWeight = 'bold';
                freeShippingFeature.innerHTML = `<i class="fas fa-truck"></i> Frete Grátis para este produto`;
                productModalFeatures.appendChild(freeShippingFeature);
            }
            
            // Atualizar botões de ação - COMPRAR AGORA e ADICIONAR AO CARRINHO
            productActionButtons.innerHTML = '';
            
            // Botão "COMPRAR AGORA" - redireciona para WhatsApp
            const buyNowBtn = document.createElement('button');
            buyNowBtn.className = 'buy-now-btn';
            buyNowBtn.innerHTML = '<i class="fab fa-whatsapp"></i> Comprar Agora';
            buyNowBtn.addEventListener('click', () => {
                const message = `Esse item (${product.title}) está disponível?`;
                const whatsappUrl = `https://wa.me/${whatsappSettings.number}?text=${encodeURIComponent(message)}`;
                window.open(whatsappUrl, '_blank');
            });
            productActionButtons.appendChild(buyNowBtn);
            
            // Botão "ADICIONAR AO CARRINHO" - adiciona à sacola
            if (systemSettings.enableCart !== false) {
                const addToCartBtn = document.createElement('button');
                addToCartBtn.className = 'add-to-cart-btn';
                addToCartBtn.innerHTML = '<i class="fas fa-shopping-bag"></i> Adicionar ao Carrinho';
                addToCartBtn.addEventListener('click', () => {
                    addToCart(product);
                    productModal.style.display = 'none';
                });
                productActionButtons.appendChild(addToCartBtn);
            }
            
            // Se o usuário for admin, adicionar botões de edição e exclusão
            if (auth.currentUser) {
                // Botão de Editar
                const editBtn = document.createElement('button');
                editBtn.className = 'product-modal-action-btn product-modal-edit';
                editBtn.innerHTML = '<i class="fas fa-edit"></i> Editar Produto';
                editBtn.addEventListener('click', () => {
                    productModal.style.display = 'none';
                    openEditProductModal(product);
                });
                productActionButtons.appendChild(editBtn);

                // Botão de Apagar
                const deleteBtn = document.createElement('button');
                deleteBtn.className = 'product-modal-action-btn product-modal-delete';
                deleteBtn.innerHTML = '<i class="fas fa-trash"></i> Apagar Produto';
                deleteBtn.addEventListener('click', () => {
                    productModal.style.display = 'none';
                    deleteProduct(product.id);
                });
                productActionButtons.appendChild(deleteBtn);
            }

            // Criar botões de compartilhamento
            createShareButtons(product);
            
            // Mostrar modal
            productModal.style.display = 'flex';
        }
        
        // Abrir galeria de imagens
        function openGallery(images) {
            currentGalleryImages = images;
            currentImageIndex = 0;
            
            // Atualizar a galeria
            galleryThumbnails.innerHTML = '';
            images.forEach((img, index) => {
                const thumb = document.createElement('div');
                thumb.className = 'gallery-thumbnail';
                if (index === 0) thumb.classList.add('active');
                thumb.innerHTML = `<img src="${img}" alt="Thumbnail ${index + 1}">`;
                thumb.addEventListener('click', () => {
                    currentImageIndex = index;
                    updateGalleryImage();
                });
                galleryThumbnails.appendChild(thumb);
            });
            
            updateGalleryImage();
            galleryModal.style.display = 'flex';
        }
        
        // Carregar configurações do sistema
        function loadSystemSettings() {
            db.collection('settings').doc('system').get()
                .then(doc => {
                    if (doc.exists) {
                        const data = doc.data();
                        systemSettings = data;
                        
                        // Configurações gerais
                        systemNameInput.value = data.name || 'LojaLead';
                        systemSloganInput.value = data.slogan || 'A melhor opção de Guarapari';
                        systemDescriptionInput.value = data.description || 'Sistema completo de controle de inventário e gestão de produtos para sua empresa.';
                        systemCurrencyInput.value = data.currency || 'R$';
                        systemTimezoneInput.value = data.timezone || 'America/Sao_Paulo';
                        
                        // Configurações do Banner
                        heroTitleInput.value = data.heroTitle || 'LojaLead - A melhor opção de Guarapari';
                        heroSubtitleInput.value = data.heroSubtitle || 'Para quem busca variedade, bom atendimento e uma experiência de compra prática e confiável.';
                        heroBtnTextInput.value = data.heroBtnText || 'Ver Produtos';
                        
                        // Configurações de contato
                        contactEmailInput.value = data.contactEmail || 'contato@lojalead.com';
                        contactPhoneInput.value = data.contactPhone || '(27) 99631-6212';
                        contactAddressInput.value = data.contactAddress || 'Av. Comercial, 1234, Centro, Guarapari-ES';
                        whatsappNumber.value = data.whatsappNumber || '5527996316212';
                        whatsappSettings.number = data.whatsappNumber || '5527996316212';
                        
                        // Map settings
                        showMapCheckbox.checked = data.showMap === true;
                        mapIframeInput.value = data.mapIframe || '';
                        
                        // Configurações do rodapé
                        footerCopyrightInput.value = data.footerCopyright || 'LojaLead - Todos os direitos reservados';
                        footerFacebookInput.value = data.footerFacebook || '';
                        footerInstagramInput.value = data.footerInstagram || '';
                        if (footerTiktokInput) footerTiktokInput.value = data.footerTiktok || '';
                        if (footerYoutubeInput) footerYoutubeInput.value = data.footerYoutube || '';
                        footerBusinessHoursInput.value = data.footerBusinessHours || 'Segunda a Sexta: 8h às 18h | Sábado: 8h às 12h';
                        
                        // Configurações de exibição
                        showStockStatus.checked = data.showStockStatus === true;
                        hideProductBrand.checked = data.hideProductBrand === true;
                        hideViewProductBtn.checked = data.hideViewProductBtn !== false;
                        showCategoriesSidebar.checked = data.showCategoriesSidebar !== false;
                        enableSearch.checked = data.enableSearch !== false;
                        enableCartCheckbox.checked = data.enableCart !== false;
                        enableFreeShipping.checked = data.enableFreeShipping === true;
                        if (freeShippingMinValueInput) freeShippingMinValueInput.value = data.freeShippingMinValue || 0;
                        viewProductTextInput.value = data.viewProductText || 'Ver Produto';
                        desktopColumnsInput.value = data.desktopColumns || 'auto';
                        mobileColumnsInput.value = data.mobileColumns || '2';
                        if (catalogSortDefaultSelect) catalogSortDefaultSelect.value = data.catalogSortDefault || 'relevance';
                        
                        // Banner de aviso no topo
                        if (topBannerEnabledCheckbox) topBannerEnabledCheckbox.checked = data.topBannerEnabled === true;
                        if (topBannerTextInput) topBannerTextInput.value = data.topBannerText || '';
                        applyTopBanner(data);
                        
                        // Imagem de fundo do banner
                        heroBackgroundImageUrl = data.heroBackgroundImage || '';
                        heroBackgroundImageDeleteHash = data.heroBackgroundImageDeleteHash || '';
                        if (heroBackgroundImageUrl && heroBgPreview) {
                            heroBgPreview.src = heroBackgroundImageUrl;
                            heroBgPreviewWrapper.style.display = 'block';
                            removeHeroBgBtn.style.display = 'inline-block';
                        } else if (heroBgPreviewWrapper) {
                            heroBgPreviewWrapper.style.display = 'none';
                            removeHeroBgBtn.style.display = 'none';
                        }
                        applyHeroBackground(data);

                        // Logo da loja
                        storeLogoUrl = data.storeLogo || '';
                        storeLogoDeleteHash = data.storeLogoDeleteHash || '';
                        if (storeLogoUrl && storeLogoPreview) {
                            storeLogoPreview.src = storeLogoUrl;
                            storeLogoPreviewWrapper.style.display = 'block';
                            removeStoreLogoBtn.style.display = 'inline-block';
                        } else if (storeLogoPreviewWrapper) {
                            storeLogoPreviewWrapper.style.display = 'none';
                            removeStoreLogoBtn.style.display = 'none';
                        }
                        applyStoreLogo(data);
                        
                        // Items per page
                        itemsPerPage = data.itemsPerPage || 12;
                        
                        // Atualizar controles de exibição
                        displayControls.forEach(btn => {
                            btn.classList.remove('active');
                            if (parseInt(btn.getAttribute('data-items')) === itemsPerPage) {
                                btn.classList.add('active');
                            }
                        });
                        
                        // Configurações de tema já são carregadas separadamente
                        
                        // Modo de exibição do catálogo
                        if (catalogLayoutSelect) catalogLayoutSelect.value = data.catalogLayout || 'grid';
                        applyCatalogLayout();
                        syncCatalogLayoutPicker();
                        
                        // Backup e exportação
                        backupFrequency.value = data.backupFrequency || 'weekly';
                        
                        // Última atualização
                        if (data.updatedAt) {
                            const lastUpdate = data.updatedAt.toDate ? data.updatedAt.toDate() : new Date(data.updatedAt);
                            updateLastUpdateDisplay(lastUpdate);
                        }
                        
                        // Atualizar footer
                        updateFooter();
                        
                        // Aplicar configurações de exibição
                        applyDisplaySettings();
                        
                        // Aplicar configurações de grid
                        applyGridSettings();
                        
                        // Atualizar mapa
                        updateMapDisplay();
                        
                        // Atualizar título da página
                        document.querySelector('.logo span').textContent = systemNameInput.value;
                        document.title = systemNameInput.value + ' - Controle de Inventário';
                        
                        // Atualizar Banner
                        heroTitle.textContent = heroTitleInput.value;
                        heroSubtitle.textContent = heroSubtitleInput.value;
                        viewProductsBtn.textContent = heroBtnTextInput.value;
                    } else {
                        // Se não existir configurações salvas, criar com valores padrão
                        saveDefaultSystemSettings();
                    }
                })
                .catch(error => {
                    console.error('Erro ao carregar configurações do sistema:', error);
                    // Em caso de erro, criar configurações padrão
                    saveDefaultSystemSettings();
                });
        }
        
        // Função para salvar configurações padrão do sistema
        function saveDefaultSystemSettings() {
            const defaultSettings = {
                // Configurações gerais
                name: 'LojaLead',
                slogan: 'A melhor opção de Guarapari',
                description: 'Sistema completo de controle de inventário e gestão de produtos para sua empresa.',
                currency: 'R$',
                timezone: 'America/Sao_Paulo',
                
                // Configurações do Banner
                heroTitle: 'LojaLead - A melhor opção de Guarapari',
                heroSubtitle: 'Para quem busca variedade, bom atendimento e uma experiência de compra prática e confiável.',
                heroBtnText: 'Ver Produtos',
                
                // Configurações de contato
                contactEmail: 'contato@guaraestoque.com',
                contactPhone: '(27) 99631-6212',
                contactAddress: 'Av. Comercial, 1234, Centro, Guarapari-ES',
                whatsappNumber: '5527996316212',
                
                // Map settings
                showMap: false,
                mapIframe: '',
                
                // Configurações do rodapé
                footerCopyright: 'LojaLead - Todos os direitos reservados',
                footerFacebook: '',
                footerInstagram: '',
                footerTiktok: '',
                footerYoutube: '',
                footerBusinessHours: 'Segunda a Sexta: 8h às 18h | Sábado: 8h às 12h',
                
                // Configurações de exibição
                showStockStatus: false,
                hideProductBrand: false,
                hideViewProductBtn: true,
                showCategoriesSidebar: true,
                enableSearch: true,
                enableCart: true,
                enableFreeShipping: false,
                freeShippingMinValue: 0,
                viewProductText: 'Ver Produto',
                desktopColumns: 'auto',
                mobileColumns: '2',
                itemsPerPage: 12,
                catalogSortDefault: 'relevance',
                
                // Banner de aviso no topo
                topBannerEnabled: false,
                topBannerText: '',
                
                // Imagem de fundo do banner
                heroBackgroundImage: '',
                heroBackgroundImageDeleteHash: '',

                // Logo da loja
                storeLogo: '',
                storeLogoDeleteHash: '',
                
                // Modo de exibição do catálogo
                catalogLayout: 'grid',
                
                // Backup e exportação
                backupFrequency: 'weekly',
                
                updatedAt: appBackend.firestore.FieldValue.serverTimestamp()
            };
            
            if (auth.currentUser) {
                db.collection('settings').doc('system').set(defaultSettings)
                .then(() => {
                    systemSettings = defaultSettings;
                    whatsappSettings.number = defaultSettings.whatsappNumber;
                    
                    // Atualizar interface
                    systemNameInput.value = defaultSettings.name;
                    systemSloganInput.value = defaultSettings.slogan;
                    systemDescriptionInput.value = defaultSettings.description;
                    systemCurrencyInput.value = defaultSettings.currency;
                    systemTimezoneInput.value = defaultSettings.timezone;
                    
                    heroTitleInput.value = defaultSettings.heroTitle;
                    heroSubtitleInput.value = defaultSettings.heroSubtitle;
                    heroBtnTextInput.value = defaultSettings.heroBtnText;
                    
                    contactEmailInput.value = defaultSettings.contactEmail;
                    contactPhoneInput.value = defaultSettings.contactPhone;
                    contactAddressInput.value = defaultSettings.contactAddress;
                    whatsappNumber.value = defaultSettings.whatsappNumber;
                    
                    showMapCheckbox.checked = defaultSettings.showMap;
                    mapIframeInput.value = defaultSettings.mapIframe;
                    
                    footerCopyrightInput.value = defaultSettings.footerCopyright;
                    footerFacebookInput.value = defaultSettings.footerFacebook;
                    footerInstagramInput.value = defaultSettings.footerInstagram;
                    if (footerTiktokInput) footerTiktokInput.value = defaultSettings.footerTiktok;
                    if (footerYoutubeInput) footerYoutubeInput.value = defaultSettings.footerYoutube;
                    footerBusinessHoursInput.value = defaultSettings.footerBusinessHours;
                    
                    showStockStatus.checked = defaultSettings.showStockStatus;
                    hideProductBrand.checked = defaultSettings.hideProductBrand;
                    showCategoriesSidebar.checked = defaultSettings.showCategoriesSidebar;
                    enableSearch.checked = defaultSettings.enableSearch;
                    enableCartCheckbox.checked = defaultSettings.enableCart;
                    enableFreeShipping.checked = defaultSettings.enableFreeShipping;
                    if (freeShippingMinValueInput) freeShippingMinValueInput.value = defaultSettings.freeShippingMinValue;
                    viewProductTextInput.value = defaultSettings.viewProductText;
                    desktopColumnsInput.value = defaultSettings.desktopColumns;
                    mobileColumnsInput.value = defaultSettings.mobileColumns;
                    itemsPerPage = defaultSettings.itemsPerPage;
                    if (catalogSortDefaultSelect) catalogSortDefaultSelect.value = defaultSettings.catalogSortDefault;
                    backupFrequency.value = defaultSettings.backupFrequency;
                    
                    if (topBannerEnabledCheckbox) topBannerEnabledCheckbox.checked = defaultSettings.topBannerEnabled;
                    if (topBannerTextInput) topBannerTextInput.value = defaultSettings.topBannerText;
                    applyTopBanner(defaultSettings);
                    
                    heroBackgroundImageUrl = '';
                    heroBackgroundImageDeleteHash = '';
                    if (heroBgPreviewWrapper) heroBgPreviewWrapper.style.display = 'none';
                    if (removeHeroBgBtn) removeHeroBgBtn.style.display = 'none';
                    applyHeroBackground(defaultSettings);

                    storeLogoUrl = '';
                    storeLogoDeleteHash = '';
                    if (storeLogoPreviewWrapper) storeLogoPreviewWrapper.style.display = 'none';
                    if (removeStoreLogoBtn) removeStoreLogoBtn.style.display = 'none';
                    applyStoreLogo(defaultSettings);
                    
                    if (catalogLayoutSelect) catalogLayoutSelect.value = defaultSettings.catalogLayout;
                    applyCatalogLayout();
                    syncCatalogLayoutPicker();
                    
                    // Atualizar controles de exibição
                    displayControls.forEach(btn => {
                        btn.classList.remove('active');
                        if (parseInt(btn.getAttribute('data-items')) === itemsPerPage) {
                            btn.classList.add('active');
                        }
                    });
                    
                    // Atualizar footer
                    updateFooter();
                    
                    // Aplicar configurações de exibição
                    applyDisplaySettings();
                    
                    // Aplicar configurações de grid
                    applyGridSettings();
                    
                    // Atualizar mapa
                    updateMapDisplay();
                    
                    // Atualizar Banner
                    heroTitle.textContent = defaultSettings.heroTitle;
                    heroSubtitle.textContent = defaultSettings.heroSubtitle;
                    viewProductsBtn.textContent = defaultSettings.heroBtnText;
                    
                    console.log('Configurações padrão salvas no Firestore');
                })
                .catch(error => {
                    console.error('Erro ao salvar configurações padrão:', error);
                });
            }
        }
        
        // Atualizar exibição da última atualização
        function updateLastUpdateDisplay(date) {
            if (!date) return;
            
            const now = new Date();
            const diffMs = now - date;
            const diffMins = Math.floor(diffMs / (1000 * 60));
            const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
            const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
            
            let timeText = '';
            if (diffMins < 1) {
                timeText = 'agora mesmo';
            } else if (diffMins < 60) {
                timeText = `há ${diffMins} minuto${diffMins !== 1 ? 's' : ''}`;
            } else if (diffHours < 24) {
                timeText = `há ${diffHours} hora${diffHours !== 1 ? 's' : ''}`;
                if (diffHours === 1) {
                    const remainingMins = diffMins - 60;
                    if (remainingMins > 0) {
                        timeText += ` e ${remainingMins} minuto${remainingMins !== 1 ? 's' : ''}`;
                    }
                }
            } else if (diffDays === 1) {
                timeText = 'ontem';
            } else if (diffDays < 7) {
                timeText = `há ${diffDays} dia${diffDays !== 1 ? 's' : ''}`;
            } else {
                timeText = date.toLocaleDateString('pt-BR');
            }
            
            statLastUpdate.textContent = timeText;
            statLastUpdateDetail.textContent = `Data: ${date.toLocaleDateString('pt-BR')} às ${date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
            lastUpdateData.timestamp = date;
        }
        
        // Salvar configurações do sistema
        function saveSystemSettings() {
            const settings = {
                // Configurações gerais
                name: systemNameInput.value,
                slogan: systemSloganInput.value,
                description: systemDescriptionInput.value,
                currency: systemCurrencyInput.value,
                timezone: systemTimezoneInput.value,
                
                // Configurações do Banner
                heroTitle: heroTitleInput.value,
                heroSubtitle: heroSubtitleInput.value,
                heroBtnText: heroBtnTextInput.value,
                
                // Configurações de contato
                contactEmail: contactEmailInput.value,
                contactPhone: contactPhoneInput.value,
                contactAddress: contactAddressInput.value,
                whatsappNumber: whatsappNumber.value,
                
                // Map settings
                showMap: showMapCheckbox.checked,
                mapIframe: mapIframeInput.value,
                
                // Configurações do rodapé
                footerCopyright: footerCopyrightInput.value,
                footerFacebook: footerFacebookInput.value,
                footerInstagram: footerInstagramInput.value,
                footerTiktok: footerTiktokInput ? footerTiktokInput.value : '',
                footerYoutube: footerYoutubeInput ? footerYoutubeInput.value : '',
                footerBusinessHours: footerBusinessHoursInput.value,
                
                // Configurações de exibição
                showStockStatus: showStockStatus.checked,
                hideProductBrand: hideProductBrand.checked,
                hideViewProductBtn: hideViewProductBtn.checked,
                showCategoriesSidebar: showCategoriesSidebar.checked,
                enableSearch: enableSearch.checked,
                enableCart: enableCartCheckbox.checked,
                enableFreeShipping: enableFreeShipping.checked,
                freeShippingMinValue: freeShippingMinValueInput ? (parseFloat(freeShippingMinValueInput.value) || 0) : 0,
                viewProductText: viewProductTextInput.value,
                desktopColumns: desktopColumnsInput.value,
                mobileColumns: mobileColumnsInput.value,
                itemsPerPage: itemsPerPage,
                catalogSortDefault: catalogSortDefaultSelect ? catalogSortDefaultSelect.value : 'relevance',
                
                // Banner de aviso no topo
                topBannerEnabled: topBannerEnabledCheckbox ? topBannerEnabledCheckbox.checked : false,
                topBannerText: topBannerTextInput ? topBannerTextInput.value : '',
                
                // Imagem de fundo do banner (já enviada via upload; aqui só referenciamos a URL atual)
                heroBackgroundImage: heroBackgroundImageUrl,
                heroBackgroundImageDeleteHash: heroBackgroundImageDeleteHash,

                // Logo da loja (já enviada via upload; aqui só referenciamos a URL atual)
                storeLogo: storeLogoUrl,
                storeLogoDeleteHash: storeLogoDeleteHash,
                
                // Configurações de tema (cor do tema em si) são salvas separadamente
                
                // Modo de exibição do catálogo
                catalogLayout: catalogLayoutSelect ? catalogLayoutSelect.value : 'grid',
                
                // Backup e exportação
                backupFrequency: backupFrequency.value,
                
                updatedAt: appBackend.firestore.FieldValue.serverTimestamp()
            };
            
            // Salvar no Firestore
            if (auth.currentUser) {
                db.collection('settings').doc('system').set(settings)
                .then(() => {
                    systemSettings = settings;
                    whatsappSettings.number = settings.whatsappNumber;
                    
                    // Atualizar última atualização
                    const now = new Date();
                    updateLastUpdateDisplay(now);
                    
                    // Atualizar footer
                    updateFooter();
                    
                    // Aplicar configurações de exibição
                    applyDisplaySettings();
                    
                    // Aplicar configurações de grid
                    applyGridSettings();
                    
                    // Aplicar modo de exibição do catálogo
                    applyCatalogLayout();
                    
                    // Atualizar mapa
                    updateMapDisplay();
                    
                    // Atualizar título da página
                    document.querySelector('.logo span').textContent = settings.name;
                    document.title = settings.name + ' - Controle de Inventário';
                    
                    // Atualizar Banner
                    heroTitle.textContent = settings.heroTitle;
                    heroSubtitle.textContent = settings.heroSubtitle;
                    viewProductsBtn.textContent = settings.heroBtnText;
                    applyHeroBackground(settings);

                    // Atualizar logo
                    applyStoreLogo(settings);
                    
                    // Aplicar banner de aviso no topo
                    applyTopBanner(settings);
                    
                    showToast('Configurações do sistema salvas com sucesso!');
                })
                .catch(error => {
                    console.error('Erro ao salvar configurações:', error);
                    showToast('Erro ao salvar configurações', 'error');
                });
            } else {
                showToast('Faça login para salvar as configurações', 'error');
            }
        }
        
        // Aplicar configurações de grid (colunas)
        function applyGridSettings() {
            const desktopCols = desktopColumnsInput.value || 'auto';
            const mobileCols = mobileColumnsInput.value || '2';
            
            const styleId = 'dynamic-grid-style';
            let styleEl = document.getElementById(styleId);
            if (!styleEl) {
                styleEl = document.createElement('style');
                styleEl.id = styleId;
                document.head.appendChild(styleEl);
            }
            
            let css = '';
            
            // Desktop
            if (desktopCols === 'auto') {
                css += `
                    @media (min-width: 769px) {
                        .products-grid {
                            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)) !important;
                        }
                    }
                `;
            } else {
                css += `
                    @media (min-width: 769px) {
                        .products-grid {
                            grid-template-columns: repeat(${desktopCols}, 1fr) !important;
                        }
                    }
                `;
            }
            
            // Mobile
            // Ajuste automático do gap para 3 ou mais colunas para evitar quebra de layout
            const gapStyle = parseInt(mobileCols) >= 3 ? 'gap: 0.5rem !important;' : '';
            
            css += `
                @media (max-width: 768px) {
                    .products-grid {
                        grid-template-columns: repeat(${mobileCols}, 1fr) !important;
                        ${gapStyle}
                    }
                }
            `;
            
            styleEl.textContent = css;
        }
        
        // Aplicar banner de aviso no topo
        function applyTopBanner(settings) {
            if (!topAnnouncementBanner) return;
            const enabled = !!(settings && settings.topBannerEnabled);
            const text = (settings && settings.topBannerText) || '';
            if (enabled && text) {
                topAnnouncementText.textContent = text;
                topAnnouncementBanner.style.display = 'block';
            } else {
                topAnnouncementBanner.style.display = 'none';
            }
        }

        // Aplicar imagem de fundo customizada do banner
        function applyHeroBackground(settings) {
            if (!heroSection) return;
            const url = settings && settings.heroBackgroundImage;
            if (url) {
                heroSection.style.backgroundImage = `linear-gradient(rgba(0,0,0,0.35), rgba(0,0,0,0.35)), url('${url}')`;
                heroSection.style.backgroundSize = 'cover';
                heroSection.style.backgroundPosition = 'center';
            } else {
                heroSection.style.backgroundImage = '';
            }
        }

        // Aplicar logo customizada no cabeçalho (substitui o ícone+texto padrão)
        function applyStoreLogo(settings) {
            const url = settings && settings.storeLogo;
            const storeLogoText = document.getElementById('store-logo-text');
            if (url) {
                if (storeLogoImg) {
                    storeLogoImg.src = url;
                    storeLogoImg.style.display = 'block';
                }
                if (storeLogoIcon) storeLogoIcon.style.display = 'none';
                if (storeLogoText) storeLogoText.style.display = 'none';
            } else {
                if (storeLogoImg) {
                    storeLogoImg.style.display = 'none';
                    storeLogoImg.src = '';
                }
                if (storeLogoIcon) storeLogoIcon.style.display = '';
                if (storeLogoText) storeLogoText.style.display = '';
            }
        }

        // Ordena a lista de produtos de acordo com a ordenação padrão configurada
        function applyCatalogSort(products, sortMode) {
            const sorted = products.slice();
            switch (sortMode) {
                case 'price-asc':
                    sorted.sort((a, b) => (a.price || 0) - (b.price || 0));
                    break;
                case 'price-desc':
                    sorted.sort((a, b) => (b.price || 0) - (a.price || 0));
                    break;
                case 'name-asc':
                    sorted.sort((a, b) => (a.title || '').localeCompare(b.title || ''));
                    break;
                case 'newest':
                    sorted.sort((a, b) => {
                        const aTime = a.createdAt && a.createdAt.seconds ? a.createdAt.seconds : 0;
                        const bTime = b.createdAt && b.createdAt.seconds ? b.createdAt.seconds : 0;
                        return bTime - aTime;
                    });
                    break;
                default:
                    // relevância: mantém a ordem original (como veio do backend)
                    break;
            }
            return sorted;
        }

        // Upload/troca/remoção da imagem de fundo do banner
        async function handleHeroBgImageChange(file) {
            if (!file) return;
            try {
                const uploaded = await uploadImageToServer(file);
                // Se já havia uma imagem anterior salva, apaga a antiga do servidor
                if (heroBackgroundImageDeleteHash) {
                    deleteImageFromServer(heroBackgroundImageDeleteHash);
                }
                heroBackgroundImageUrl = uploaded.url;
                heroBackgroundImageDeleteHash = uploaded.deleteHash;
                if (heroBgPreview) heroBgPreview.src = uploaded.url;
                if (heroBgPreviewWrapper) heroBgPreviewWrapper.style.display = 'block';
                if (removeHeroBgBtn) removeHeroBgBtn.style.display = 'inline-block';
                showToast('Imagem de fundo enviada. Clique em "Salvar Configurações" para aplicar.');
            } catch (error) {
                console.error('Erro ao enviar imagem de fundo do banner:', error);
                showToast('Erro ao enviar imagem de fundo', 'error');
            }
        }

        function handleRemoveHeroBg() {
            if (heroBackgroundImageDeleteHash) {
                deleteImageFromServer(heroBackgroundImageDeleteHash);
            }
            heroBackgroundImageUrl = '';
            heroBackgroundImageDeleteHash = '';
            if (heroBgPreview) heroBgPreview.src = '';
            if (heroBgPreviewWrapper) heroBgPreviewWrapper.style.display = 'none';
            if (removeHeroBgBtn) removeHeroBgBtn.style.display = 'none';
            if (heroBgImageInput) heroBgImageInput.value = '';
        }

        if (heroBgImageInput) {
            heroBgImageInput.addEventListener('change', (e) => {
                const file = e.target.files && e.target.files[0];
                if (file) handleHeroBgImageChange(file);
            });
        }
        if (removeHeroBgBtn) {
            removeHeroBgBtn.addEventListener('click', handleRemoveHeroBg);
        }

        // Upload/troca/remoção da logo da loja
        async function handleStoreLogoChange(file) {
            if (!file) return;
            try {
                const uploaded = await uploadImageToServer(file);
                if (storeLogoDeleteHash) {
                    deleteImageFromServer(storeLogoDeleteHash);
                }
                storeLogoUrl = uploaded.url;
                storeLogoDeleteHash = uploaded.deleteHash;
                if (storeLogoPreview) storeLogoPreview.src = uploaded.url;
                if (storeLogoPreviewWrapper) storeLogoPreviewWrapper.style.display = 'block';
                if (removeStoreLogoBtn) removeStoreLogoBtn.style.display = 'inline-block';
                showToast('Logo enviada. Clique em "Salvar Configurações" para aplicar.');
            } catch (error) {
                console.error('Erro ao enviar logo:', error);
                showToast('Erro ao enviar logo', 'error');
            }
        }

        function handleRemoveStoreLogo() {
            if (storeLogoDeleteHash) {
                deleteImageFromServer(storeLogoDeleteHash);
            }
            storeLogoUrl = '';
            storeLogoDeleteHash = '';
            if (storeLogoPreview) storeLogoPreview.src = '';
            if (storeLogoPreviewWrapper) storeLogoPreviewWrapper.style.display = 'none';
            if (removeStoreLogoBtn) removeStoreLogoBtn.style.display = 'none';
            if (storeLogoImageInput) storeLogoImageInput.value = '';
        }

        if (storeLogoImageInput) {
            storeLogoImageInput.addEventListener('change', (e) => {
                const file = e.target.files && e.target.files[0];
                if (file) handleStoreLogoChange(file);
            });
        }
        if (removeStoreLogoBtn) {
            removeStoreLogoBtn.addEventListener('click', handleRemoveStoreLogo);
        }

        // Aplicar configurações de exibição
        function applyDisplaySettings() {
            // Aplicar configurações de busca
            if (enableSearch && searchInput) {
                if (searchContainer) {
                    searchContainer.style.display = enableSearch.checked ? 'flex' : 'none';
                }
                if (headerContent) {
                    headerContent.style.justifyContent = enableSearch.checked ? 'space-between' : 'center';
                }
            }
            
            // Aplicar configurações da sidebar de categorias
            if (showCategoriesSidebar && sidebarCategoriesToggle) {
                const categoriesItem = sidebarCategoriesToggle.closest('li');
                if (categoriesItem) {
                    categoriesItem.style.display = showCategoriesSidebar.checked ? 'block' : 'none';
                }
            }
            
            // Aplicar configurações do carrinho
            if (enableCartCheckbox && cartBtn) {
                const isCartEnabled = enableCartCheckbox.checked;
                cartBtn.style.display = isCartEnabled ? 'flex' : 'none';
            }
            
            // Recarregar produtos para aplicar itens por página
            filterAndDisplayProducts();
        }
        
        // Restaurar configurações padrão
        function resetSystemSettings() {
            // Configurações gerais
            systemNameInput.value = 'LojaLead';
            systemSloganInput.value = 'A melhor opção de Guarapari';
            systemDescriptionInput.value = 'Sistema completo de controle de inventário e gestão de produtos para sua empresa.';
            systemCurrencyInput.value = 'R$';
            systemTimezoneInput.value = 'America/Sao_Paulo';
            
            // Configurações do Banner
            heroTitleInput.value = 'LojaLead - A melhor opção de Guarapari';
            heroSubtitleInput.value = 'Para quem busca variedade, bom atendimento e uma experiência de compra prática e confiável.';
            heroBtnTextInput.value = 'Ver Produtos';
            
            // Configurações de contato
            contactEmailInput.value = 'contato@lojalead.com';
            contactPhoneInput.value = '(27) 99631-6212';
            contactAddressInput.value = 'Av. Comercial, 1234, Centro, Guarapari-ES';
            whatsappNumber.value = '5527996316212';
            
            // Map settings
            showMapCheckbox.checked = false;
            mapIframeInput.value = '';
            
            // Configurações do rodapé
            footerCopyrightInput.value = 'LojaLead - Todos os direitos reservados';
            footerFacebookInput.value = '';
            footerInstagramInput.value = '';
            if (footerTiktokInput) footerTiktokInput.value = '';
            if (footerYoutubeInput) footerYoutubeInput.value = '';
            footerBusinessHoursInput.value = 'Segunda a Sexta: 8h às 18h | Sábado: 8h às 12h';
            
            // Configurações de exibição
            showStockStatus.checked = false;
            hideProductBrand.checked = false;
            hideViewProductBtn.checked = true;
            showCategoriesSidebar.checked = true;
            enableSearch.checked = true;
            enableCartCheckbox.checked = true;
            enableFreeShipping.checked = false;
            if (freeShippingMinValueInput) freeShippingMinValueInput.value = 0;
            viewProductTextInput.value = 'Ver Produto';
            desktopColumnsInput.value = 'auto';
            mobileColumnsInput.value = '2';
            if (catalogSortDefaultSelect) catalogSortDefaultSelect.value = 'relevance';
            
            // Banner de aviso no topo - restaurar para padrão
            if (topBannerEnabledCheckbox) topBannerEnabledCheckbox.checked = false;
            if (topBannerTextInput) topBannerTextInput.value = '';
            applyTopBanner({ topBannerEnabled: false, topBannerText: '' });
            
            // Imagem de fundo do banner - restaurar para padrão (remove do servidor se houver)
            handleRemoveHeroBg();
            applyHeroBackground({ heroBackgroundImage: '' });

            // Logo da loja - restaurar para padrão (remove do servidor se houver)
            handleRemoveStoreLogo();
            applyStoreLogo({ storeLogo: '' });
            
            // Configurações de tema - restaurar para padrão
            applyTheme('light');
            loadThemesInterface();
            updateThemeControls('light');
            darkMode.checked = false;
            
            // Modo de exibição do catálogo - restaurar para padrão
            if (catalogLayoutSelect) catalogLayoutSelect.value = 'grid';
            applyCatalogLayout();
            syncCatalogLayoutPicker();
            
            // Backup e exportação
            backupFrequency.value = 'weekly';
            
            // Atualizar display controls
            displayControls.forEach(btn => {
                btn.classList.remove('active');
                if (btn.getAttribute('data-items') === '12') {
                    btn.classList.add('active');
                    itemsPerPage = 12;
                }
            });
            
            // Salvar as configurações padrão
            if (auth.currentUser) {
                const defaultSettings = {
                    name: systemNameInput.value,
                    slogan: systemSloganInput.value,
                    description: systemDescriptionInput.value,
                    currency: systemCurrencyInput.value,
                    timezone: systemTimezoneInput.value,
                    heroTitle: heroTitleInput.value,
                    heroSubtitle: heroSubtitleInput.value,
                    heroBtnText: heroBtnTextInput.value,
                    contactEmail: contactEmailInput.value,
                    contactPhone: contactPhoneInput.value,
                    contactAddress: contactAddressInput.value,
                    whatsappNumber: whatsappNumber.value,
                    showMap: showMapCheckbox.checked,
                    mapIframe: mapIframeInput.value,
                    footerCopyright: footerCopyrightInput.value,
                    footerFacebook: footerFacebookInput.value,
                    footerInstagram: footerInstagramInput.value,
                    footerTiktok: footerTiktokInput ? footerTiktokInput.value : '',
                    footerYoutube: footerYoutubeInput ? footerYoutubeInput.value : '',
                    footerBusinessHours: footerBusinessHoursInput.value,
                    showStockStatus: showStockStatus.checked,
                    hideProductBrand: hideProductBrand.checked,
                    hideViewProductBtn: hideViewProductBtn.checked,
                    showCategoriesSidebar: showCategoriesSidebar.checked,
                    enableSearch: enableSearch.checked,
                    enableCart: enableCartCheckbox.checked,
                    enableFreeShipping: enableFreeShipping.checked,
                    freeShippingMinValue: 0,
                    viewProductText: viewProductTextInput.value,
                    desktopColumns: desktopColumnsInput.value,
                    mobileColumns: mobileColumnsInput.value,
                    itemsPerPage: itemsPerPage,
                    catalogSortDefault: 'relevance',
                    topBannerEnabled: false,
                    topBannerText: '',
                    heroBackgroundImage: '',
                    heroBackgroundImageDeleteHash: '',
                    storeLogo: '',
                    storeLogoDeleteHash: '',
                    backupFrequency: backupFrequency.value,
                    catalogLayout: catalogLayoutSelect ? catalogLayoutSelect.value : 'grid',
                    updatedAt: appBackend.firestore.FieldValue.serverTimestamp()
                };
                
                db.collection('settings').doc('system').set(defaultSettings)
                .then(() => {
                    systemSettings = defaultSettings;
                    whatsappSettings.number = defaultSettings.whatsappNumber;
                    updateFooter();
                    applyDisplaySettings();
                    applyGridSettings();
                    applyCatalogLayout();
                    updateMapDisplay();
                    
                    heroTitle.textContent = defaultSettings.heroTitle;
                    heroSubtitle.textContent = defaultSettings.heroSubtitle;
                    viewProductsBtn.textContent = defaultSettings.heroBtnText;
                    
                    showToast('Configurações restauradas para os valores padrão e salvas.');
                })
                .catch(error => {
                    console.error('Erro ao salvar configurações padrão:', error);
                    showToast('Configurações restauradas localmente, mas houve erro ao salvar no servidor.', 'error');
                });
            } else {
                showToast('Configurações restauradas localmente (faça login para salvar no servidor).');
                applyDisplaySettings();
                applyGridSettings();
                updateMapDisplay();
                
                heroTitle.textContent = heroTitleInput.value;
                heroSubtitle.textContent = heroSubtitleInput.value;
                viewProductsBtn.textContent = heroBtnTextInput.value;
            }
        }
        
        // Função para atualizar exibição do mapa
        function updateMapDisplay() {
            const sidebarLocationItem = document.getElementById('sidebar-location-item');
            
            // Não mostrar o mapa se o usuário for administrador (estiver logado)
            if (auth.currentUser) {
                mapSection.style.display = 'none';
                mapContainer.innerHTML = '';
                if (sidebarLocationItem) sidebarLocationItem.style.display = 'none';
                return;
            }
            
            if (showMapCheckbox.checked && mapIframeInput.value.trim() !== '') {
                mapSection.style.display = 'block';
                mapContainer.innerHTML = mapIframeInput.value;
                if (sidebarLocationItem) sidebarLocationItem.style.display = 'block';
            } else {
                mapSection.style.display = 'none';
                mapContainer.innerHTML = '';
                if (sidebarLocationItem) sidebarLocationItem.style.display = 'none';
            }
        }
        
        // Atualizar estatísticas do sistema
        function updateSystemStats() {
            statProducts.textContent = allProducts.length;
            statCategories.textContent = allCategories.length;
            
            // Atualizar última atualização se já foi salva
            if (lastUpdateData.timestamp) {
                updateLastUpdateDisplay(lastUpdateData.timestamp);
            }
        }
        
        // Exportar produtos para CSV
        function exportProductsToCSV() {
            if (allProducts.length === 0) {
                showToast('Não há produtos para exportar.', 'error');
                return;
            }
            
            // Criar cabeçalho CSV
            let csv = 'Nome,Descrição,Categoria,Marca,Preço,Preço Original,Estoque,Status\n';
            
            // Adicionar dados dos produtos
            allProducts.forEach(product => {
                const row = [
                    `"${product.title.replace(/"/g, '""')}"`,
                    `"${(product.description || '').replace(/"/g, '""')}"`,
                    `"${product.category || ''}"`,
                    `"${product.brand || ''}"`,
                    product.price,
                    product.oldPrice || '',
                    product.stock,
                    product.stockStatus
                ];
                csv += row.join(',') + '\n';
            });
            
            // Criar arquivo CSV
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `produtos_guaraestoque_${new Date().toISOString().split('T')[0]}.csv`;
            link.click();
            
            URL.revokeObjectURL(url);
            showToast('Produtos exportados com sucesso para CSV!');
        }
        
        // Criar backup do sistema
        function createSystemBackup() {
            const backupData = {
                products: allProducts,
                categories: allCategories,
                settings: systemSettings,
                theme: {
                    theme: currentTheme,
                    darkMode: darkMode.checked
                },
                timestamp: new Date().toISOString()
            };
            
            const backupJson = JSON.stringify(backupData, null, 2);
            const blob = new Blob([backupJson], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `backup_guaraestoque_${new Date().toISOString().split('T')[0]}.json`;
            link.click();
            
            URL.revokeObjectURL(url);
            showToast('Backup do sistema criado com sucesso!');
        }
        
        // Atualizar footer com as configurações
        function updateFooter() {
            footerSystemName.textContent = systemNameInput.value;
            footerSystemDescription.textContent = systemDescriptionInput.value;
            footerAddress.textContent = contactAddressInput.value;
            footerPhone.textContent = contactPhoneInput.value;
            footerEmail.textContent = contactEmailInput.value;
            footerCopyright.textContent = footerCopyrightInput.value;
            footerBusinessHours.textContent = footerBusinessHoursInput.value;
            
            // Atualizar links das redes sociais
            if (footerFacebookInput.value) {
                footerFacebookLink.href = footerFacebookInput.value;
                footerFacebookLink.style.display = 'block';
            } else {
                footerFacebookLink.style.display = 'none';
            }
            
            if (footerInstagramInput.value) {
                footerInstagramLink.href = footerInstagramInput.value;
                footerInstagramLink.style.display = 'block';
            } else {
                footerInstagramLink.style.display = 'none';
            }
            
            if (footerTiktokInput && footerTiktokInput.value) {
                footerTiktokLink.href = footerTiktokInput.value;
                footerTiktokLink.style.display = 'block';
            } else if (footerTiktokLink) {
                footerTiktokLink.style.display = 'none';
            }
            
            if (footerYoutubeInput && footerYoutubeInput.value) {
                footerYoutubeLink.href = footerYoutubeInput.value;
                footerYoutubeLink.style.display = 'block';
            } else if (footerYoutubeLink) {
                footerYoutubeLink.style.display = 'none';
            }
            
            // Atualizar link do WhatsApp
            if (whatsappNumber.value) {
                footerWhatsappLink.href = `https://wa.me/${whatsappNumber.value}`;
                footerWhatsappLink.style.display = 'block';
            } else {
                footerWhatsappLink.style.display = 'none';
            }
        }
        
        // Auth state observer
        auth.onAuthStateChanged((user) => {
            // Carregar configurações do sistema para todos os usuários
            loadSystemSettings();
            
            const productsSection = document.getElementById('products-section');
            const productsGrid = document.getElementById('products-grid');
            
            if (user) {
                // User is signed in
                adminControls.style.display = 'block';
                // Change sidebar login button to logout
                sidebarLoginLink.innerHTML = '<i class="fas fa-sign-out-alt"></i><span>Logout</span>';
                sidebarLoginLink.setAttribute('data-section', 'logout');
                updateSystemStats();
                const accountEmailEl = document.getElementById('account-current-email');
                if (accountEmailEl) accountEmailEl.textContent = user.email || '';
                // Carregar temas na interface
                loadThemesInterface();
                
                // Aplicar visibilidade baseada na aba atual
                if (currentAdminTab === 'manage-products') {
                    if (productsSection) productsSection.style.display = '';
                    if (productsGrid) productsGrid.style.display = '';
                } else {
                    if (productsSection) productsSection.style.display = 'none';
                    if (productsGrid) productsGrid.style.display = 'none';
                }
            } else {
                // User is signed out
                adminControls.style.display = 'none';
                // Change sidebar button back to login
                sidebarLoginLink.innerHTML = '<i class="fas fa-sign-in-alt"></i><span>Login</span>';
                sidebarLoginLink.setAttribute('data-section', 'login');
                
                // Garantir que produtos apareçam quando deslogado
                if (productsSection) productsSection.style.display = '';
                if (productsGrid) productsGrid.style.display = '';
            }
            // Reload products to show/hide admin buttons
            loadProducts();
            loadCategories();
        });
        
        // Carregar categorias do Firestore
        function loadCategories() {
            db.collection('categories').orderBy('name').get()
                .then((querySnapshot) => {
                    allCategories = [];
                    sidebarCategoriesSubmenu.innerHTML = '';
                    productCategorySelect.innerHTML = '<option value="">Selecione uma categoria</option>';
                    
                    // Adicionar item "Todos os Produtos" no submenu
                    const allItem = document.createElement('li');
                    const allLink = document.createElement('a');
                    allLink.href = '#';
                    allLink.setAttribute('data-category', 'all');
                    allLink.innerHTML = '<span>Todos os Produtos</span>';
                    allLink.addEventListener('click', (e) => {
                        e.preventDefault();
                        currentCategory = 'all';
                        currentSearchQuery = '';
                        searchInput.value = '';
                        filterAndDisplayProducts();
                        closeSidebar();
                    });
                    allItem.appendChild(allLink);
                    sidebarCategoriesSubmenu.appendChild(allItem);
                    
                    if (!querySnapshot.empty) {
                        querySnapshot.forEach((doc) => {
                            const category = doc.data();
                            const categoryId = doc.id;
                            
                            allCategories.push({
                                id: categoryId,
                                ...category
                            });
                            
                            // Adicionar categoria ao submenu do sidebar
                            const categoryItem = document.createElement('li');
                            const categoryLink = document.createElement('a');
                            categoryLink.href = '#';
                            categoryLink.setAttribute('data-category', category.name);
                            categoryLink.innerHTML = `<span>${category.name}</span>`;
                            
                            categoryLink.addEventListener('click', (e) => {
                                e.preventDefault();
                                currentCategory = category.name;
                                currentSearchQuery = '';
                                searchInput.value = '';
                                filterAndDisplayProducts();
                                closeSidebar();
                            });
                            
                            categoryItem.appendChild(categoryLink);
                            sidebarCategoriesSubmenu.appendChild(categoryItem);
                            
                            // Adicionar opção no select do formulário de produto
                            const option = document.createElement('option');
                            option.value = category.name;
                            option.textContent = category.name;
                            productCategorySelect.appendChild(option);
                        });
                    }
                    
                    // Aplicar configurações de exibição da sidebar
                    if (showCategoriesSidebar && sidebarCategoriesToggle) {
                        const categoriesItem = sidebarCategoriesToggle.closest('li');
                        if (categoriesItem) {
                            categoriesItem.style.display = showCategoriesSidebar.checked ? 'block' : 'none';
                        }
                    }
                    
                    // Atualizar estatísticas
                    updateSystemStats();
                })
                .catch((error) => {
                    console.error('Error loading categories: ', error);
                });
        }
        
        // Carregar gerenciamento de categorias
        function loadCategoriesManagement() {
            categoriesGrid.innerHTML = '';
            
            if (allCategories.length === 0) {
                categoriesGrid.innerHTML = `
                    <div style="grid-column: 1 / -1; text-align: center; padding: 2rem;">
                        <i class="fas fa-tags" style="font-size: 3rem; color: #ccc; margin-bottom: 1rem;"></i>
                        <h3>Nenhuma categoria cadastrada</h3>
                        <p>Utilize o botão "Criar Nova Categoria" para adicionar categorias.</p>
                    </div>
                `;
                return;
            }
            
            allCategories.forEach(category => {
                const card = document.createElement('div');
                card.className = 'category-admin-card';
                card.innerHTML = `
                    <div class="name">${category.name}</div>
                    <button class="delete-btn" data-id="${category.id}">
                        <i class="fas fa-trash"></i> Excluir
                    </button>
                `;
                
                categoriesGrid.appendChild(card);
            });
            
            // Adicionar eventos aos botões de deletar
            document.querySelectorAll('.category-admin-card .delete-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const categoryId = e.target.closest('.delete-btn').dataset.id;
                    deleteCategory(categoryId);
                });
            });
        }

        // Load products from Firestore
        function loadProducts() {
            loadingSpinner.style.display = 'block';
            productsGrid.innerHTML = '';
            productsGrid.appendChild(loadingSpinner);
            
            db.collection('products').orderBy('createdAt', 'desc').get()
                .then((querySnapshot) => {
                    productsGrid.innerHTML = '';
                    allProducts = [];
                    
                    if (querySnapshot.empty) {
                        productsGrid.innerHTML = `
                            <div style="grid-column: 1 / -1; text-align: center; padding: 2rem;">
                                <i class="fas fa-box" style="font-size: 3rem; color: #ccc; margin-bottom: 1rem;"></i>
                                <h3>Nenhum produto cadastrado</h3>
                                <p>Utilize o painel do administrador para adicionar produtos ao catálogo.</p>
                            </div>
                        `;
                        updateSystemStats();
                        return;
                    }
                    
                    querySnapshot.forEach((doc) => {
                        const product = doc.data();
                        const productId = doc.id;
                        const images = product.imageUrls || [product.imageUrl || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'];
                        
                        // Adicionar à lista de todos os produtos
                        allProducts.push({
                            id: productId,
                            ...product,
                            images
                        });
                    });
                    
                    // Embaralhar produtos para exibição aleatória ao carregar
                    allProducts = shuffleArray(allProducts);
                    
                    // Atualizar estatísticas
                    updateSystemStats();
                    
                    // Exibir produtos após carregar
                    filterAndDisplayProducts();
                })
                .catch((error) => {
                    console.error('Error loading products: ', error);
                    productsGrid.innerHTML = `
                        <div style="grid-column: 1 / -1; text-align: center; padding: 2rem;">
                            <i class="fas fa-exclamation-triangle" style="font-size: 3rem; color: #cc0000; margin-bottom: 1rem;"></i>
                            <h3>Erro ao carregar produtos</h3>
                            <p>Verifique sua conexão com a internet e tente novamente.</p>
                            ${auth.currentUser ? `
                            <p class="alert alert-warning" style="margin-top: 1rem;">
                                <i class="fas fa-exclamation-circle"></i>
                                <strong>Problema de permissões:</strong> Configure as regras de segurança do Firestore.
                            </p>
                            ` : ''}
                        </div>
                    `;
                });
        }
        
        // Exibir um cartão de produto
        function displayProductCard(productId, product, images) {
            const productCard = document.createElement('div');
            productCard.className = 'product-card';
            
            // Verificar se tem desconto
            let discountBadge = '';
            if (product.oldPrice && product.oldPrice > product.price) {
                const discountPercent = calculateDiscountPercentage(product.oldPrice, product.price);
                discountBadge = `<div class="discount-badge">${discountPercent}% OFF</div>`;
            }
            
            // Verificar se tem frete grátis
            let freeShippingBadge = '';
            // Badge de frete grátis oculto no card (visível apenas no modal)
            
            // Determinar texto do status do estoque (aplicando configuração)
            let stockText = '';
            let stockClass = '';
            if (showStockStatus.checked) {
                switch(product.stockStatus) {
                    case 'in-stock':
                        stockText = `Em estoque (${product.stock} unidades)`;
                        stockClass = 'in-stock';
                        break;
                    case 'low-stock':
                        stockText = `Estoque baixo (${product.stock} unidades)`;
                        stockClass = 'low-stock';
                        break;
                    case 'out-of-stock':
                        stockText = 'Fora de estoque';
                        stockClass = 'out-of-stock';
                        break;
                    default:
                        if (product.stock > 5) {
                            stockText = `Em estoque (${product.stock} unidades)`;
                            stockClass = 'in-stock';
                        } else if (product.stock > 0) {
                            stockText = `Estoque baixo (${product.stock} unidades)`;
                            stockClass = 'low-stock';
                        } else {
                            stockText = 'Fora de estoque';
                            stockClass = 'out-of-stock';
                        }
                }
            }
            
            // Criar exibição de preço
            let priceDisplay = '';
            if (product.oldPrice && product.oldPrice > product.price) {
                // Preço antigo acima do atual nos cards também
                priceDisplay = `
                    <div style="margin-bottom: 0.5rem; line-height: 1.3;">
                        <span class="product-price">R$ ${product.price.toLocaleString('pt-BR', {minimumFractionDigits: 2})}</span>
                        ${freeShippingBadge}
                        <span class="product-old-price" style="display: block; font-size: 0.9rem;">De: R$ ${product.oldPrice.toLocaleString('pt-BR', {minimumFractionDigits: 2})}</span>
                    </div>
                `;
            } else {
                priceDisplay = `
                    <div>
                        <span class="product-price">R$ ${product.price.toLocaleString('pt-BR', {minimumFractionDigits: 2})}</span>
                        ${freeShippingBadge}
                    </div>
                `;
            }
            
            const viewBtnText = systemSettings.viewProductText || 'Ver Produto';
            const hideViewBtn = systemSettings.hideViewProductBtn !== false;
            const showAdminControls = auth.currentUser;
            const cardDescriptionHtml = (currentCatalogLayout === 'menu' && product.description)
                ? `<p class="product-card-description">${escapeHtml(product.description)}</p>`
                : '';
            
            productCard.innerHTML = `
                <div class="product-image">
                    <img src="${images[0]}" alt="${product.title}">
                    ${discountBadge}
                    ${images.length > 1 ? `<div class="image-badge">+${images.length-1}</div>` : ''}
                </div>
                <div class="product-details">
                    <h3 class="product-title">${product.title}</h3>
                    ${cardDescriptionHtml}
                    ${priceDisplay}
                    ${showStockStatus.checked ? `<div class="product-status ${stockClass}">${stockText}</div>` : ''}
                    ${!hideViewBtn ? `<button class="view-product-btn" data-id="${productId}">
                        <i class="fas fa-eye"></i> ${viewBtnText}
                    </button>` : ''}
                    ${showAdminControls ? `
                    <div class="quick-edit-controls">
                        <button class="quick-edit-btn" data-id="${productId}">
                            <i class="fas fa-edit"></i> Editar
                        </button>
                        <button class="quick-edit-btn" data-id="${productId}" data-action="stock">
                            <i class="fas fa-boxes"></i> Estoque
                        </button>
                        <button class="copy-link-btn" data-id="${productId}">
                            <i class="fas fa-link"></i> Link
                        </button>
                        <button class="delete-product-btn" data-id="${productId}">
                            <i class="fas fa-trash"></i> Apagar
                        </button>
                    </div>
                    ` : ''}
                </div>
            `;
            
            productsGrid.appendChild(productCard);
            
            // Evento para o botão "Ver Produto"
            const viewProductBtn = productCard.querySelector('.view-product-btn');
            if (viewProductBtn) {
                viewProductBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    openProductModal({
                        id: productId,
                        ...product,
                        images
                    });
                });
            }
            
            // Tornar o produto clicável para abrir modal (exceto no botão)
            productCard.addEventListener('click', (e) => {
                if (!e.target.closest('.quick-edit-controls') && 
                    !e.target.closest('.copy-link-btn') &&
                    !e.target.closest('.delete-product-btn') &&
                    !e.target.closest('.view-product-btn')) {
                    openProductModal({
                        id: productId,
                        ...product,
                        images
                    });
                }
            });
            
            // Adicionar eventos aos botões de edição rápida (admin real ou demo)
            if (showAdminControls) {
                const editBtns = productCard.querySelectorAll('.quick-edit-btn');
                editBtns.forEach(btn => {
                    btn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        const btnProductId = btn.getAttribute('data-id');
                        const action = btn.getAttribute('data-action');
                        const productData = allProducts.find(p => p.id === btnProductId);
                        
                        if (action === 'stock') {
                            openQuickStockModal(productData);
                        } else {
                            openEditProductModal(productData);
                        }
                    });
                });
                
                // Adicionar evento ao botão de copiar link
                const copyLinkBtn = productCard.querySelector('.copy-link-btn');
                if (copyLinkBtn) {
                    copyLinkBtn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        const productLink = generateProductLink(productId);
                        copyToClipboard(productLink);
                    });
                }

                // Adicionar evento ao botão de apagar
                const deleteBtn = productCard.querySelector('.delete-product-btn');
                if (deleteBtn) {
                    deleteBtn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        const btnProductId = deleteBtn.getAttribute('data-id');
                        deleteProduct(btnProductId);
                    });
                }
            }
        }
        
        // Atualizar ano atual no footer
        document.getElementById('current-year').textContent = new Date().getFullYear();
        
        // Initial load
        loadProducts();
        loadCategories();
        checkUrlForProduct();
        loadThemeFromFirestore();
        loadThemesInterface();
        loadCartFromLocalStorage();
        // Definir a aba inicial como ativa
        switchAdminTab('manage-products');




