from datetime import datetime, timedelta, timezone

from flask import Blueprint, render_template, request, redirect, url_for, flash, abort, jsonify, g
from flask_login import current_user, login_required
from sqlalchemy import func

from .models import (
    db, Tenant, Order, OrderStatusEvent, Customer, StatEvent, Document,
    Plan, Subscription, ORDER_STATUSES, ORDER_STATUS_LABELS,
)
from .traffic_utils import TRAFFIC_SOURCE_LABELS

orders_admin_bp = Blueprint("orders_admin", __name__, url_prefix="/loja/<slug>/painel")


def _tenant_or_404(slug):
    tenant = Tenant.query.filter_by(slug=slug, active=True).first()
    if not tenant:
        abort(404)
    return tenant


def _require_owner(tenant):
    if not current_user.is_authenticated or getattr(current_user, "tenant_id", None) != tenant.id:
        return redirect(url_for("tenant.login_page", slug=tenant.slug, next=request.path))
    return None


@orders_admin_bp.before_request
def _guard():
    slug = request.view_args.get("slug") if request.view_args else None
    if not slug:
        return None
    tenant = _tenant_or_404(slug)
    resp = _require_owner(tenant)
    if resp:
        return resp
    g.tenant = tenant
    return None


# ---------------------------------------------------------------------------
# Pedidos
# ---------------------------------------------------------------------------

@orders_admin_bp.get("/pedidos")
def orders_list(slug):
    tenant = g.tenant
    status_filter = request.args.get("status") or ""
    search = (request.args.get("q") or "").strip()

    query = Order.query.filter_by(tenant_id=tenant.id)
    if status_filter in ORDER_STATUSES:
        query = query.filter_by(status=status_filter)
    if search:
        query = query.join(Customer, Order.customer_id == Customer.id, isouter=True).filter(
            db.or_(Customer.name.ilike(f"%{search}%"), Customer.phone.ilike(f"%{search}%"))
        )
    orders = query.order_by(Order.created_at.desc()).limit(200).all()

    return render_template(
        "admin/orders_list.html",
        tenant=tenant,
        orders=orders,
        statuses=ORDER_STATUSES,
        status_labels=ORDER_STATUS_LABELS,
        status_filter=status_filter,
        search=search,
    )


@orders_admin_bp.get("/pedidos/<order_id>")
def order_detail(slug, order_id):
    tenant = g.tenant
    order = Order.query.filter_by(tenant_id=tenant.id, id=order_id).first()
    if not order:
        abort(404)
    return render_template(
        "admin/order_detail.html",
        tenant=tenant,
        order=order,
        statuses=ORDER_STATUSES,
        status_labels=ORDER_STATUS_LABELS,
    )


@orders_admin_bp.post("/pedidos/<order_id>/status")
def order_update_status(slug, order_id):
    tenant = g.tenant
    order = Order.query.filter_by(tenant_id=tenant.id, id=order_id).first()
    if not order:
        abort(404)
    new_status = request.form.get("status")
    note = (request.form.get("note") or "").strip() or None
    if new_status not in ORDER_STATUSES:
        flash("Status inválido.", "error")
        return redirect(url_for("orders_admin.order_detail", slug=slug, order_id=order_id))

    order.status = new_status
    db.session.add(OrderStatusEvent(order_id=order.id, status=new_status, note=note))
    db.session.commit()
    flash("Status do pedido atualizado.", "success")
    return redirect(url_for("orders_admin.order_detail", slug=slug, order_id=order_id))


# ---------------------------------------------------------------------------
# Clientes
# ---------------------------------------------------------------------------

@orders_admin_bp.get("/clientes")
def customers_list(slug):
    tenant = g.tenant
    search = (request.args.get("q") or "").strip()
    query = Customer.query.filter_by(tenant_id=tenant.id)
    if search:
        query = query.filter(db.or_(Customer.name.ilike(f"%{search}%"), Customer.phone.ilike(f"%{search}%")))
    customers = query.order_by(Customer.created_at.desc()).limit(200).all()

    order_counts = dict(
        db.session.query(Order.customer_id, func.count(Order.id))
        .filter(Order.tenant_id == tenant.id)
        .group_by(Order.customer_id)
        .all()
    )
    return render_template(
        "admin/customers_list.html",
        tenant=tenant, customers=customers, search=search, order_counts=order_counts,
    )


@orders_admin_bp.get("/clientes/<customer_id>")
def customer_detail(slug, customer_id):
    tenant = g.tenant
    customer = Customer.query.filter_by(tenant_id=tenant.id, id=customer_id).first()
    if not customer:
        abort(404)
    orders = Order.query.filter_by(tenant_id=tenant.id, customer_id=customer.id).order_by(Order.created_at.desc()).all()
    return render_template("admin/customer_detail.html", tenant=tenant, customer=customer, orders=orders)


# ---------------------------------------------------------------------------
# Início (home do painel: estatísticas + visão geral da loja)
# ---------------------------------------------------------------------------

ONLINE_WINDOW_SECONDS = 90


def _online_now_count(tenant):
    since = datetime.now(timezone.utc) - timedelta(seconds=ONLINE_WINDOW_SECONDS)
    return (
        db.session.query(func.count(func.distinct(StatEvent.visitor_id)))
        .filter(
            StatEvent.tenant_id == tenant.id,
            StatEvent.event_type == "heartbeat",
            StatEvent.created_at >= since,
            StatEvent.visitor_id.isnot(None),
        )
        .scalar()
        or 0
    )


DEVICE_LABELS = {"desktop": "Computador", "mobile": "Celular", "tablet": "Tablet"}


@orders_admin_bp.get("/estatisticas/online.json")
def online_now(slug):
    """Endpoint leve para o contador 'Online agora' se atualizar sozinho
    na tela, sem recarregar a página inteira."""
    tenant = g.tenant
    return jsonify({"online": _online_now_count(tenant)})


@orders_admin_bp.get("/estatisticas")
def stats(slug):
    tenant = g.tenant
    days = 14
    since = datetime.now(timezone.utc) - timedelta(days=days)

    counts = dict(
        db.session.query(StatEvent.event_type, func.count(StatEvent.id))
        .filter(StatEvent.tenant_id == tenant.id, StatEvent.created_at >= since)
        .group_by(StatEvent.event_type)
        .all()
    )

    daily_rows = (
        db.session.query(
            func.date(StatEvent.created_at).label("day"),
            StatEvent.event_type,
            func.count(StatEvent.id),
        )
        .filter(StatEvent.tenant_id == tenant.id, StatEvent.created_at >= since)
        .group_by("day", StatEvent.event_type)
        .order_by("day")
        .all()
    )

    by_day = {}
    for day, event_type, cnt in daily_rows:
        day_key = str(day)
        by_day.setdefault(day_key, {"visit": 0, "product_view": 0, "cart_add": 0, "order": 0})
        by_day[day_key][event_type] = cnt

    top_products_rows = (
        db.session.query(StatEvent.ref_id, func.count(StatEvent.id).label("views"))
        .filter(
            StatEvent.tenant_id == tenant.id,
            StatEvent.event_type == "product_view",
            StatEvent.created_at >= since,
            StatEvent.ref_id.isnot(None),
        )
        .group_by(StatEvent.ref_id)
        .order_by(func.count(StatEvent.id).desc())
        .limit(5)
        .all()
    )

    # --- de onde vem o tráfego, dispositivo, navegador e país -----------
    # (calculado a partir das visitas — cada evento 'visit' já carrega
    # essas informações, coletadas sem serviço externo: ver traffic_utils.py)

    def _breakdown(column, limit=8):
        rows = (
            db.session.query(column, func.count(StatEvent.id))
            .filter(
                StatEvent.tenant_id == tenant.id,
                StatEvent.event_type == "visit",
                StatEvent.created_at >= since,
                column.isnot(None),
            )
            .group_by(column)
            .order_by(func.count(StatEvent.id).desc())
            .limit(limit)
            .all()
        )
        total = sum(cnt for _, cnt in rows) or 1
        return [
            {"key": key, "count": cnt, "pct": round(cnt * 100 / total)}
            for key, cnt in rows
        ]

    traffic_sources = _breakdown(StatEvent.traffic_source)
    for row in traffic_sources:
        row["label"] = TRAFFIC_SOURCE_LABELS.get(row["key"], row["key"])

    device_breakdown = _breakdown(StatEvent.device_type)
    for row in device_breakdown:
        row["label"] = DEVICE_LABELS.get(row["key"], row["key"])

    browser_breakdown = _breakdown(StatEvent.browser, limit=6)
    for row in browser_breakdown:
        row["label"] = row["key"]

    country_breakdown = _breakdown(StatEvent.country_name, limit=8)
    for row in country_breakdown:
        row["label"] = row["key"]

    online_now_count = _online_now_count(tenant)

    # --- informações extras da home, além das estatísticas de tráfego ---

    recent_orders = (
        Order.query.filter_by(tenant_id=tenant.id)
        .order_by(Order.created_at.desc())
        .limit(5)
        .all()
    )
    pending_orders_count = Order.query.filter_by(tenant_id=tenant.id, status="novo").count()
    products_count = Document.query.filter_by(tenant_id=tenant.id, collection="products").count()
    subscription = Subscription.query.filter_by(tenant_id=tenant.id).first()

    settings_doc = Document.query.filter_by(tenant_id=tenant.id, collection="settings", doc_id="system").first()
    has_whatsapp_number = bool((settings_doc.data or {}).get("whatsappNumber")) if settings_doc else False

    trial_days_left = None
    if subscription and subscription.status == "trial" and subscription.current_period_end:
        end = subscription.current_period_end
        if end.tzinfo is None:
            end = end.replace(tzinfo=timezone.utc)
        trial_days_left = max(0, (end - datetime.now(timezone.utc)).days)

    return render_template(
        "admin/stats.html",
        tenant=tenant,
        days=days,
        counts=counts,
        by_day=sorted(by_day.items()),
        top_products=top_products_rows,
        traffic_sources=traffic_sources,
        device_breakdown=device_breakdown,
        browser_breakdown=browser_breakdown,
        country_breakdown=country_breakdown,
        online_now_count=online_now_count,
        recent_orders=recent_orders,
        pending_orders_count=pending_orders_count,
        products_count=products_count,
        subscription=subscription,
        trial_days_left=trial_days_left,
        has_whatsapp_number=has_whatsapp_number,
        status_labels=ORDER_STATUS_LABELS,
    )


# ---------------------------------------------------------------------------
# Plano / cobrança (visão da loja — gestão real fica no superadmin)
# ---------------------------------------------------------------------------

@orders_admin_bp.get("/plano")
def plan_view(slug):
    tenant = g.tenant
    subscription = Subscription.query.filter_by(tenant_id=tenant.id).first()
    plans = Plan.query.filter_by(active=True).order_by(Plan.sort_order).all()
    return render_template("admin/plan.html", tenant=tenant, subscription=subscription, plans=plans)


# ---------------------------------------------------------------------------
# SEO e domínio
# ---------------------------------------------------------------------------

@orders_admin_bp.get("/seo")
def seo_view(slug):
    tenant = g.tenant
    return render_template("admin/seo.html", tenant=tenant)


@orders_admin_bp.post("/seo")
def seo_save(slug):
    tenant = g.tenant
    tenant.seo_title = (request.form.get("seo_title") or "").strip()[:160] or None
    tenant.seo_description = (request.form.get("seo_description") or "").strip()[:300] or None
    tenant.seo_keywords = (request.form.get("seo_keywords") or "").strip()[:300] or None
    tenant.seo_og_image = (request.form.get("seo_og_image") or "").strip()[:500] or None

    custom_domain = (request.form.get("custom_domain") or "").strip().lower() or None
    if custom_domain:
        clash = Tenant.query.filter(Tenant.custom_domain == custom_domain, Tenant.id != tenant.id).first()
        if clash:
            flash("Esse domínio já está em uso por outra loja.", "error")
            return redirect(url_for("orders_admin.seo_view", slug=slug))
    tenant.custom_domain = custom_domain

    db.session.commit()
    flash("Configurações de SEO/domínio salvas.", "success")
    return redirect(url_for("orders_admin.seo_view", slug=slug))
