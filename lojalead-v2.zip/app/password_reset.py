"""
password_reset.py
-----------------------------------------------------------------------
Fluxo de "esqueci minha senha", sem depender de nenhum serviço externo
obrigatório:

- Gera um token = "<user_id>.<segredo aleatório>". Só o HASH do segredo é
  guardado no banco (TenantUser.reset_token_hash), igual a uma senha —
  então mesmo se o banco vazar, o token não pode ser recriado a partir dele.
- Expira em 1 hora (RESET_TOKEN_TTL_MINUTES).
- Tenta enviar por e-mail de verdade via SMTP **somente se** as variáveis de
  ambiente MAIL_SERVER / MAIL_USERNAME / MAIL_PASSWORD estiverem configuradas
  (ver README). Isso é opcional: o projeto continua "sem serviços de
  terceiros" por padrão — se nada estiver configurado, o link de redefinição
  é apenas exibido na tela (modo desenvolvimento/local) e registrado no
  console do servidor, para não travar o fluxo em ambientes sem SMTP.
-----------------------------------------------------------------------
"""
import os
import secrets
import smtplib
from datetime import datetime, timedelta
from email.message import EmailMessage

from werkzeug.security import generate_password_hash, check_password_hash

RESET_TOKEN_TTL_MINUTES = 60


def _now():
    # Naive UTC (sem tzinfo) de propósito: o SQLite não guarda timezone, então
    # o valor lido de volta do banco também vem naive. Comparar aware x naive
    # levanta TypeError, então mantemos os dois lados naive por consistência.
    return datetime.utcnow()


def generate_reset_token(user) -> str:
    """Gera e grava no usuário um novo token de redefinição. Retorna o token
    completo (user_id.segredo) que deve ir no link enviado/mostrado."""
    secret = secrets.token_urlsafe(32)
    user.reset_token_hash = generate_password_hash(secret)
    user.reset_token_expires_at = _now() + timedelta(minutes=RESET_TOKEN_TTL_MINUTES)
    return f"{user.id}.{secret}"


def find_user_for_token(token: str, TenantUser):
    """Valida um token e retorna o TenantUser correspondente, ou None se o
    token for inválido, de outro usuário, ou tiver expirado."""
    if not token or "." not in token:
        return None
    user_id, secret = token.split(".", 1)
    user = TenantUser.query.filter_by(id=user_id).first()
    if not user or not user.reset_token_hash or not user.reset_token_expires_at:
        return None
    if user.reset_token_expires_at < _now():
        return None
    if not check_password_hash(user.reset_token_hash, secret):
        return None
    return user


def clear_reset_token(user):
    user.reset_token_hash = None
    user.reset_token_expires_at = None


def mail_is_configured() -> bool:
    return bool(os.environ.get("MAIL_SERVER") and os.environ.get("MAIL_USERNAME"))


def send_reset_email(to_email: str, reset_url: str, store_name: str) -> bool:
    """Tenta enviar o e-mail via SMTP configurado por variáveis de ambiente.
    Retorna True se enviou de verdade, False se não havia SMTP configurado
    (nesse caso quem chamou deve mostrar o link na tela como alternativa)."""
    if not mail_is_configured():
        print(f"[password_reset] SMTP não configurado. Link de redefinição para "
              f"{to_email}: {reset_url}")
        return False

    server = os.environ["MAIL_SERVER"]
    port = int(os.environ.get("MAIL_PORT", "587"))
    username = os.environ["MAIL_USERNAME"]
    password = os.environ.get("MAIL_PASSWORD", "")
    use_tls = os.environ.get("MAIL_USE_TLS", "true").lower() != "false"
    sender = os.environ.get("MAIL_DEFAULT_SENDER", username)

    msg = EmailMessage()
    msg["Subject"] = f"Redefinição de senha — {store_name}"
    msg["From"] = sender
    msg["To"] = to_email
    msg.set_content(
        f"Recebemos um pedido para redefinir a senha da sua conta em {store_name}.\n\n"
        f"Se foi você, clique no link abaixo (válido por {RESET_TOKEN_TTL_MINUTES} minutos):\n"
        f"{reset_url}\n\n"
        f"Se não foi você, ignore este e-mail — sua senha continua a mesma."
    )

    try:
        with smtplib.SMTP(server, port, timeout=10) as smtp:
            if use_tls:
                smtp.starttls()
            smtp.login(username, password)
            smtp.send_message(msg)
        return True
    except Exception as exc:  # noqa: BLE001 - qualquer falha de SMTP cai no fallback
        print(f"[password_reset] Falha ao enviar e-mail via SMTP ({exc}). "
              f"Link de redefinição para {to_email}: {reset_url}")
        return False
