import uuid
from datetime import datetime, timezone

from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


def now_utc():
    return datetime.now(timezone.utc)


def new_id():
    return uuid.uuid4().hex


class Tenant(db.Model):
    """Uma loja (tenant) do SaaS. Ex: slug 'guaraestoque' -> /loja/guaraestoque"""
    __tablename__ = "tenants"

    id = db.Column(db.String(32), primary_key=True, default=new_id)
    slug = db.Column(db.String(64), unique=True, nullable=False, index=True)
    store_name = db.Column(db.String(120), nullable=False)
    plan = db.Column(db.String(30), default="trial")  # legado; ver Subscription/Plan
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=now_utc)

    # Domínio próprio (ex: "minhaLoja.com.br"), opcional. O subdomínio
    # automático (<slug>.BASE_DOMAIN) não precisa de coluna: é resolvido
    # direto a partir do slug em tempo de request.
    custom_domain = db.Column(db.String(255), unique=True, nullable=True, index=True)

    # SEO por loja (usado no <head> da vitrine, ver tenant.storefront)
    seo_title = db.Column(db.String(160), nullable=True)
    seo_description = db.Column(db.String(300), nullable=True)
    seo_keywords = db.Column(db.String(300), nullable=True)
    seo_og_image = db.Column(db.String(500), nullable=True)

    order_seq = db.Column(db.Integer, nullable=False, default=0)  # contador do nº do pedido

    users = db.relationship("TenantUser", backref="tenant", cascade="all, delete-orphan")
    documents = db.relationship("Document", backref="tenant", cascade="all, delete-orphan")
    customers = db.relationship("Customer", backref="tenant", cascade="all, delete-orphan")
    orders = db.relationship("Order", backref="tenant", cascade="all, delete-orphan")

    def next_order_number(self):
        self.order_seq = (self.order_seq or 0) + 1
        return self.order_seq


class TenantUser(UserMixin, db.Model):
    """O(s) administrador(es)/dono(s) de uma loja."""
    __tablename__ = "tenant_users"

    id = db.Column(db.String(32), primary_key=True, default=new_id)
    tenant_id = db.Column(db.String(32), db.ForeignKey("tenants.id"), nullable=False, index=True)
    email = db.Column(db.String(255), nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=now_utc)

    # Recuperação de senha ("esqueci minha senha"): guardamos só o HASH do
    # token (nunca o token em texto puro) + prazo de validade. O token que
    # circula no link de e-mail é "<user_id>.<segredo>"; validamos o segredo
    # contra este hash (mesma lógica de senha) e checamos a expiração.
    reset_token_hash = db.Column(db.String(255), nullable=True)
    reset_token_expires_at = db.Column(db.DateTime, nullable=True)

    __table_args__ = (
        db.UniqueConstraint("tenant_id", "email", name="uq_tenant_email"),
    )

    def set_password(self, raw_password: str):
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password: str) -> bool:
        return check_password_hash(self.password_hash, raw_password)

    def get_id(self):
        # flask-login precisa de um id global único (não só por tenant)
        return f"{self.tenant_id}:{self.id}"


class Document(db.Model):
    """
    Armazenamento genérico de documentos, imitando o modelo do Firestore
    (collection/doc/data em JSON), isolado por tenant.
    Isso permite que o script.js original (que usa db.collection(x).doc(y))
    continue funcionando quase sem alterações, através do cliente local em
    static/js/backend-client.js — sem nenhuma dependência do Firebase.
    """
    __tablename__ = "documents"

    row_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tenant_id = db.Column(db.String(32), db.ForeignKey("tenants.id"), nullable=False, index=True)
    collection = db.Column(db.String(80), nullable=False, index=True)
    doc_id = db.Column(db.String(80), nullable=False)
    data = db.Column(db.JSON, nullable=False, default=dict)
    created_at = db.Column(db.DateTime, default=now_utc)
    updated_at = db.Column(db.DateTime, default=now_utc, onupdate=now_utc)

    __table_args__ = (
        db.UniqueConstraint("tenant_id", "collection", "doc_id", name="uq_tenant_collection_doc"),
    )

    def to_public(self):
        d = dict(self.data or {})
        d["id"] = self.doc_id
        return d


# ---------------------------------------------------------------------------
# Pedidos, clientes e histórico de status
# ---------------------------------------------------------------------------

DELIVERY_TYPES = ("retirada", "entrega")

ORDER_STATUSES = (
    "novo",
    "confirmado",
    "preparando",
    "pronto",
    "saiu_entrega",
    "concluido",
    "cancelado",
)

ORDER_STATUS_LABELS = {
    "novo": "Novo",
    "confirmado": "Confirmado",
    "preparando": "Preparando",
    "pronto": "Pronto",
    "saiu_entrega": "Saiu para entrega",
    "concluido": "Concluído",
    "cancelado": "Cancelado",
}


class Customer(db.Model):
    """Cliente de uma loja, identificado por telefone dentro do tenant."""
    __tablename__ = "customers"

    id = db.Column(db.String(32), primary_key=True, default=new_id)
    tenant_id = db.Column(db.String(32), db.ForeignKey("tenants.id"), nullable=False, index=True)
    name = db.Column(db.String(160), nullable=False)
    phone = db.Column(db.String(30), nullable=False, index=True)
    email = db.Column(db.String(255), nullable=True)
    address = db.Column(db.String(400), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=now_utc)

    orders = db.relationship("Order", backref="customer")

    __table_args__ = (
        db.UniqueConstraint("tenant_id", "phone", name="uq_tenant_customer_phone"),
    )


class Order(db.Model):
    """Um pedido feito na vitrine (checkout -> WhatsApp)."""
    __tablename__ = "orders"

    id = db.Column(db.String(32), primary_key=True, default=new_id)
    tenant_id = db.Column(db.String(32), db.ForeignKey("tenants.id"), nullable=False, index=True)
    customer_id = db.Column(db.String(32), db.ForeignKey("customers.id"), nullable=True, index=True)
    order_number = db.Column(db.Integer, nullable=False)

    status = db.Column(db.String(30), nullable=False, default="novo", index=True)
    delivery_type = db.Column(db.String(20), nullable=False, default="retirada")  # retirada | entrega
    delivery_address = db.Column(db.String(400), nullable=True)
    payment_method = db.Column(db.String(60), nullable=True)
    notes = db.Column(db.Text, nullable=True)

    items = db.Column(db.JSON, nullable=False, default=list)  # snapshot: [{id,title,price,quantity}]
    subtotal = db.Column(db.Float, nullable=False, default=0)
    shipping_fee = db.Column(db.Float, nullable=False, default=0)
    total = db.Column(db.Float, nullable=False, default=0)

    whatsapp_message = db.Column(db.Text, nullable=True)

    created_at = db.Column(db.DateTime, default=now_utc)
    updated_at = db.Column(db.DateTime, default=now_utc, onupdate=now_utc)

    status_events = db.relationship(
        "OrderStatusEvent", backref="order", cascade="all, delete-orphan",
        order_by="OrderStatusEvent.created_at",
    )

    __table_args__ = (
        db.UniqueConstraint("tenant_id", "order_number", name="uq_tenant_order_number"),
    )

    @property
    def status_label(self):
        return ORDER_STATUS_LABELS.get(self.status, self.status)

    def to_public(self):
        return {
            "id": self.id,
            "orderNumber": self.order_number,
            "status": self.status,
            "statusLabel": self.status_label,
            "deliveryType": self.delivery_type,
            "deliveryAddress": self.delivery_address,
            "paymentMethod": self.payment_method,
            "notes": self.notes,
            "items": self.items,
            "subtotal": self.subtotal,
            "shippingFee": self.shipping_fee,
            "total": self.total,
            "customerName": self.customer.name if self.customer else None,
            "customerPhone": self.customer.phone if self.customer else None,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
            "updatedAt": self.updated_at.isoformat() if self.updated_at else None,
        }


class OrderStatusEvent(db.Model):
    """Histórico de mudanças de status de um pedido."""
    __tablename__ = "order_status_events"

    id = db.Column(db.String(32), primary_key=True, default=new_id)
    order_id = db.Column(db.String(32), db.ForeignKey("orders.id"), nullable=False, index=True)
    status = db.Column(db.String(30), nullable=False)
    note = db.Column(db.String(300), nullable=True)
    created_at = db.Column(db.DateTime, default=now_utc)


# ---------------------------------------------------------------------------
# Planos e assinaturas (billing)
# ---------------------------------------------------------------------------

SUBSCRIPTION_STATUSES = ("trial", "active", "past_due", "canceled")


class Plan(db.Model):
    """Plano oferecido pelo SaaS (gerenciado pelo superadmin)."""
    __tablename__ = "plans"

    id = db.Column(db.String(32), primary_key=True, default=new_id)
    code = db.Column(db.String(40), unique=True, nullable=False)  # ex: "starter"
    name = db.Column(db.String(80), nullable=False)
    price_cents = db.Column(db.Integer, nullable=False, default=0)  # em centavos (R$)
    max_products = db.Column(db.Integer, nullable=True)  # None = ilimitado
    max_orders_per_month = db.Column(db.Integer, nullable=True)
    active = db.Column(db.Boolean, default=True)
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=now_utc)

    subscriptions = db.relationship("Subscription", backref="plan")

    @property
    def price_display(self):
        return f"R$ {self.price_cents / 100:.2f}".replace(".", ",")


class Subscription(db.Model):
    """Assinatura de uma loja a um plano. Não processa pagamento real —
    é o registro interno de billing que o superadmin (ou uma integração
    de pagamento futura) atualiza."""
    __tablename__ = "subscriptions"

    id = db.Column(db.String(32), primary_key=True, default=new_id)
    tenant_id = db.Column(db.String(32), db.ForeignKey("tenants.id"), nullable=False, unique=True, index=True)
    plan_id = db.Column(db.String(32), db.ForeignKey("plans.id"), nullable=True)
    status = db.Column(db.String(20), nullable=False, default="trial")
    current_period_end = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=now_utc)
    updated_at = db.Column(db.DateTime, default=now_utc, onupdate=now_utc)

    tenant = db.relationship("Tenant", backref=db.backref("subscription", uselist=False))


# ---------------------------------------------------------------------------
# Estatísticas (visitas, visualizações de produto, carrinho, pedidos)
# ---------------------------------------------------------------------------

class StatEvent(db.Model):
    """Evento leve de estatística. Uma linha por evento; agregações são
    feitas por query (COUNT/GROUP BY), sem tabelas de resumo separadas."""
    __tablename__ = "stat_events"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tenant_id = db.Column(db.String(32), db.ForeignKey("tenants.id"), nullable=False, index=True)
    event_type = db.Column(db.String(20), nullable=False, index=True)  # visit | product_view | cart_add | order | heartbeat
    ref_id = db.Column(db.String(64), nullable=True)  # ex: id do produto
    created_at = db.Column(db.DateTime, default=now_utc, index=True)

    # --- de onde veio o acesso (tráfego) ---
    visitor_id = db.Column(db.String(40), nullable=True, index=True)  # gerado no navegador (localStorage), identifica visitantes/"online agora"
    referrer_host = db.Column(db.String(255), nullable=True)  # domínio de origem (ex: instagram.com), quando o navegador informa
    traffic_source = db.Column(db.String(20), nullable=True)  # instagram | facebook | whatsapp | google | tiktok | direct | other

    # --- dispositivo/navegador (a partir do User-Agent, sem serviço externo) ---
    device_type = db.Column(db.String(10), nullable=True)  # desktop | mobile | tablet
    browser = db.Column(db.String(30), nullable=True)  # Chrome, Safari, Firefox, Edge, Instagram, ...

    # --- localização por IP (somente país — dado 100% local/offline via
    # geoip2fast; estado/cidade exigiriam uma base paga tipo MaxMind
    # GeoLite2 City, que não vem embutida e por isso não é preenchida) ---
    country_code = db.Column(db.String(2), nullable=True)
    country_name = db.Column(db.String(80), nullable=True)


# ---------------------------------------------------------------------------
# Superadmin (equipe LojaLead, gerencia todas as lojas/assinaturas)
# ---------------------------------------------------------------------------

class SuperAdmin(UserMixin, db.Model):
    __tablename__ = "super_admins"

    id = db.Column(db.String(32), primary_key=True, default=new_id)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=now_utc)

    def set_password(self, raw_password: str):
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password: str) -> bool:
        return check_password_hash(self.password_hash, raw_password)

    def get_id(self):
        return f"superadmin:{self.id}"
