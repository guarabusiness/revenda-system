import os

from flask import Flask, render_template
from flask_login import LoginManager
from flask_wtf import CSRFProtect
from flask_migrate import Migrate

from .models import db, TenantUser, SuperAdmin

migrate = Migrate()


def create_app():
    app = Flask(__name__)

    basedir = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-change-me")
    app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get(
        "DATABASE_URL", f"sqlite:///{os.path.join(basedir, 'lojalead.db')}"
    )
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    # Cookie de sessão só é enviado em navegação/top-level ou requests
    # same-site — isso já bloqueia a maior parte dos ataques de CSRF em
    # requisições feitas via JS (fetch) a partir de outro domínio, mesmo
    # sem token, servindo de segunda camada de defesa além do CSRFProtect
    # abaixo (que cobre os formulários HTML clássicos).
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

    # Todas as imagens enviadas pelas lojas ficam salvas em disco, na própria
    # máquina que hospeda o servidor (nada é enviado para Firebase/imgBB/etc.)
    app.config["UPLOAD_FOLDER"] = os.environ.get(
        "UPLOAD_FOLDER", os.path.join(basedir, "uploads")
    )
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
    app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024  # limite geral de request (10MB)

    db.init_app(app)
    migrate.init_app(app, db, directory=os.path.join(basedir, "migrations"))

    login_manager = LoginManager()
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(composite_id):
        # get_id() do TenantUser retorna "tenant_id:user_id"; do SuperAdmin,
        # "superadmin:user_id" — o prefixo diferencia as duas sessões.
        if composite_id.startswith("superadmin:"):
            return SuperAdmin.query.get(composite_id.split(":", 1)[1])
        try:
            tenant_id, user_id = composite_id.split(":", 1)
        except ValueError:
            return None
        return TenantUser.query.filter_by(id=user_id, tenant_id=tenant_id).first()

    from .tenant import tenant_bp
    from .api import api_bp
    from .orders_admin import orders_admin_bp
    from .superadmin import superadmin_bp
    from .public_checkout import checkout_bp
    from .domain_check import domain_check_bp

    app.register_blueprint(tenant_bp)
    app.register_blueprint(api_bp)
    app.register_blueprint(orders_admin_bp)
    app.register_blueprint(superadmin_bp)
    app.register_blueprint(checkout_bp)
    app.register_blueprint(domain_check_bp)

    import click

    @app.cli.command("create-superadmin")
    @click.argument("email")
    @click.argument("password")
    def create_superadmin(email, password):
        """Cria (ou redefine a senha de) um usuário superadmin da plataforma."""
        email = email.strip().lower()
        admin = SuperAdmin.query.filter_by(email=email).first()
        if admin:
            admin.set_password(password)
            click.echo(f"Senha atualizada para superadmin {email}")
        else:
            admin = SuperAdmin(email=email)
            admin.set_password(password)
            db.session.add(admin)
            click.echo(f"Superadmin {email} criado")
        db.session.commit()

    # ------------------------------------------------------------------
    # Subdomínio / domínio próprio: <slug>.BASE_DOMAIN ou um domínio
    # cadastrado em tenant.custom_domain servem a vitrine direto na raiz
    # ("/"), sem precisar de /loja/<slug>. Não interfere em nenhuma outra
    # rota (signup, login, api, etc. continuam iguais).
    # ------------------------------------------------------------------
    base_domain = os.environ.get("BASE_DOMAIN", "")

    @app.before_request
    def _resolve_domain_tenant():
        from flask import g, request
        from sqlalchemy.exc import OperationalError, ProgrammingError

        g.domain_tenant = None
        if request.path != "/":
            return
        host = request.host.split(":")[0].lower()

        from .models import Tenant

        # Se o banco ainda não tiver sido migrado (tabela `tenants`
        # inexistente) ou estiver momentaneamente inacessível, não deixamos
        # essa consulta auxiliar derrubar a página com um 500 — apenas
        # seguimos sem tenant de domínio (a landing normal é exibida).
        try:
            # aceita tanto "minhaloja.com.br" quanto "www.minhaloja.com.br"
            # mesmo que o dono da loja tenha cadastrado só uma das duas formas
            bare_host = host[4:] if host.startswith("www.") else host
            www_host = "www." + bare_host
            tenant = Tenant.query.filter(
                Tenant.active.is_(True),
                Tenant.custom_domain.in_([bare_host, www_host]),
            ).first()
            if not tenant and base_domain and host.endswith("." + base_domain):
                slug = host[: -(len(base_domain) + 1)]
                tenant = Tenant.query.filter_by(slug=slug, active=True).first()
            g.domain_tenant = tenant
        except (OperationalError, ProgrammingError) as exc:
            app.logger.warning(
                "[lojalead] Não foi possível consultar tenants (banco sem "
                "migrations aplicadas?): %s", exc
            )
            g.domain_tenant = None

    # Proteção CSRF (Flask-WTF) para os formulários HTML clássicos
    # (signup, esqueci-senha, redefinir-senha). A API (`api_bp`) e as rotas
    # públicas de checkout/estatísticas (`checkout_bp`) são chamadas via
    # fetch/JSON pelo próprio JS da vitrine — sem formulário HTML e sem
    # token — então ficam isentas do CSRFProtect, protegidas pelo
    # SESSION_COOKIE_SAMESITE acima.
    csrf = CSRFProtect()
    csrf.init_app(app)
    csrf.exempt(api_bp)
    csrf.exempt(checkout_bp)

    @app.errorhandler(404)
    def not_found(_error):
        return render_template("404.html"), 404

    # O schema do banco é versionado por migrations (pasta `migrations/`,
    # via Flask-Migrate/Alembic) em vez de `db.create_all()` solto no
    # factory — isso é necessário para que ALTERAÇÕES de schema em bancos
    # que já têm dados (ex.: adicionar uma coluna nova) funcionem em
    # produção; `create_all()` só cria tabelas que não existem, nunca
    # altera as existentes.
    #
    # Continuamos rodando `flask db upgrade` manualmente sempre que o
    # schema mudar (novas colunas/tabelas em um banco que já tem dados).
    # Mas se o servidor sobe e a tabela `tenants` nem existe ainda — banco
    # novo, zerado — isso quase sempre significa que a pessoa esqueceu
    # aquele passo do README, e antes disso TODA rota que toca o banco
    # (incluindo a landing, via `_resolve_domain_tenant` acima) quebrava
    # com um 500. Para acabar com essa classe de erro, aplicamos as
    # migrations automaticamente nesse caso específico (banco vazio); se
    # a tabela já existe, nada é feito aqui — updates de schema em bancos
    # com dados continuam exigindo `flask db upgrade` manual, de propósito.
    with app.app_context():
        from sqlalchemy import inspect
        if not inspect(db.engine).has_table("tenants"):
            try:
                from flask_migrate import upgrade as migrate_upgrade
                migrate_upgrade(directory=os.path.join(basedir, "migrations"))
                print("\n[lojalead] Banco de dados vazio detectado — migrations aplicadas automaticamente.\n")
            except Exception as exc:
                print(
                    "\n[lojalead] Banco de dados vazio e as migrations automáticas "
                    f"falharam ({exc}).\n"
                    "[lojalead] Rode `flask db upgrade` manualmente antes de usar o "
                    "servidor (ver README > Como rodar).\n"
                )

    return app
