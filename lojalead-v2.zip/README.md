# LojaLead SaaS

SaaS multi-tenant em Flask onde qualquer pessoa se cadastra e ganha sua
própria loja virtual em `/loja/<slug>`, com vitrine pública e painel
administrativo embutido na mesma página. Não depende de nenhum serviço de
terceiros (sem Firebase, sem imgBB) — banco de dados e imagens ficam no
próprio servidor.

## Como rodar

```bash
cd lojalead-saas
pip install -r requirements.txt
export FLASK_APP=run.py
flask db upgrade      # cria/atualiza as tabelas do banco
python run.py
# abra http://localhost:5000
```

Se você esquecer o `flask db upgrade`, o servidor ainda sobe, mas avisa no
console e as rotas que usam o banco retornam 500 até o comando ser rodado.

Variáveis de ambiente opcionais:

```bash
DATABASE_URL=postgresql://...        # troca o SQLite padrão por outro banco
UPLOAD_FOLDER=/caminho/customizado    # pasta de imagens (padrão: uploads/)
MAIL_SERVER=smtp.seuservidor.com      # para "esqueci minha senha" enviar e-mail de verdade
MAIL_PORT=587
MAIL_USERNAME=voce@seudominio.com
MAIL_PASSWORD=sua-senha-ou-senha-de-app
MAIL_USE_TLS=true
MAIL_DEFAULT_SENDER=voce@seudominio.com
```

Sem `MAIL_*` configurado, o link de redefinição de senha aparece direto na
tela e no console (modo desenvolvimento).

Para acessar o painel de superadmin (`/superadmin`), crie um usuário via CLI:

```bash
flask create-superadmin admin@suaempresa.com "sua-senha"
```

Para subdomínio automático por loja (`<slug>.SEU-DOMINIO`), configure:

```bash
BASE_DOMAIN=seudominio.com
```

Domínio próprio (ex: `minhaloja.com.br`) é configurado por loja, direto no
painel em SEO & Domínio — não precisa de variável de ambiente, só apontar o
DNS do domínio do cliente para este servidor.

## Deploy com HTTPS automático (domínio próprio de cada loja)

Este repositório já inclui tudo que é preciso para o fluxo "o cliente só
aponta o DNS e o HTTPS sai sozinho": `Dockerfile` (app + gunicorn),
`docker-compose.yml` (app + Caddy) e `Caddyfile` (proxy reverso com
certificado automático). Passo a passo num servidor Linux com IP público e
as portas 80/443 livres:

1. `cp .env.example .env` e preencha `SECRET_KEY`, `BASE_DOMAIN` e,
   opcionalmente, `DATABASE_URL` (Postgres é recomendado para produção com
   várias lojas ativas; sem isso, usa SQLite num volume persistente) e os
   `MAIL_*`.
2. Aponte o DNS de `BASE_DOMAIN` (registro `A`) para o IP deste servidor.
   Isso cobre a landing/signup e os subdomínios automáticos
   `<slug>.BASE_DOMAIN`.
3. Edite o e-mail de aviso no topo do `Caddyfile` (usado pela Let's
   Encrypt para avisar sobre expiração/erro de renovação de certificado).
4. `docker compose up -d --build`.
5. `docker compose exec app flask create-superadmin admin@suaempresa.com "sua-senha"`
   para acessar `/superadmin`.

A partir daqui, **o único passo que sobra para cada loja usar um domínio
próprio é**: o dono da loja cadastra o domínio em
`SEO & Domínio` no painel, e aponta o DNS desse domínio (registro `A`) para
o mesmo IP do servidor. Na primeira visita a esse domínio, o Caddy:

1. Recebe a requisição para o host novo (ex.: `minhaloja.com.br`);
2. Antes de emitir qualquer certificado, chama
   `GET /internal/domain-check?domain=minhaloja.com.br` na própria
   aplicação (`app/domain_check.py`) para confirmar que esse host
   realmente pertence a uma loja ativa (`Tenant.custom_domain`, incluindo a
   variação com/sem `www.`) — isso existe para que domínios aleatórios
   apontados por engano (ou de propósito) para o IP do servidor não
   consumam o limite semanal de emissões da Let's Encrypt nem atrapalhem
   as lojas legítimas;
3. Só então pede o certificado via ACME (desafio HTTP-01, porta 80) e
   passa a servir esse domínio em HTTPS — sem reiniciar nada, sem cadastrar
   o domínio manualmente no servidor.

Limitações a ter em mente:
- **DNS é responsabilidade do dono da loja** — o app não valida nem avisa
  se o apontamento está errado; enquanto o DNS não propagar, o domínio
  simplesmente não resolve para este servidor.
- Certificado leva alguns segundos na primeira visita (é quando o Caddy
  negocia com a Let's Encrypt); visitas seguintes já usam o certificado em
  cache.
- Portas 80 e 443 precisam estar livres e acessíveis publicamente neste
  servidor — sem elas, o desafio HTTP-01 falha e nenhum certificado é
  emitido.
- Perder o volume `caddy_data` (ver `docker-compose.yml`) derruba o HTTPS
  de todas as lojas até os certificados serem re-emitidos.

## Arquitetura

- **Multi-tenant por slug**: tabela `tenants` (uma linha por loja) +
  `tenant_users` (login/senha dos administradores, sempre vinculados a um
  `tenant_id`) + `documents` — um armazenamento genérico de documentos
  `(tenant_id, collection, doc_id, data JSON)` que cobre tudo que a vitrine
  precisa (`products`, `categories`, `settings/system`, `settings/theme`)
  sem precisar de migração de schema a cada campo novo salvo pelo front.
- **Front-end quase original**: o `script.js` do projeto original (que
  falava direto com Firebase/Firestore) foi mantido sem reescrever a lógica
  de UI. Em vez disso, `app/static/js/backend-client.js` implementa a mesma
  API (`firebase.auth()`, `firebase.firestore()`,
  `collection/doc/get/set/update/delete`, `FieldValue.serverTimestamp()`)
  mas por baixo dos panos faz `fetch()` para o backend Flask
  (`/api/<slug>/...`). O namespace global é `window.appBackend`.
- **Imagens**: enviadas via `POST /api/<slug>/upload`, gravadas em disco em
  `uploads/<slug>/<arquivo>` (pasta configurável por `UPLOAD_FOLDER`),
  servidas por `GET /api/<slug>/uploads/<arquivo>` e removidas por
  `DELETE /api/<slug>/upload/<arquivo>`.

### Rotas principais

| Rota | O que faz |
|---|---|
| `GET /` | Landing page do SaaS |
| `GET/POST /signup` | Cria uma nova loja (tenant) + usuário admin + configurações padrão |
| `GET /loja/<slug>` | Serve a vitrine/admin daquela loja |
| `POST/GET /api/<slug>/auth/*` | Login/logout/sessão/troca de senha do admin daquela loja |
| `GET/PUT/PATCH/DELETE /api/<slug>/docs/<collection>/<id>` | CRUD genérico de "documentos" (produtos, categorias, settings) |
| `GET /api/<slug>/docs/<collection>` | Lista documentos de uma coleção (`?orderBy=campo&dir=asc/desc`) |
| `GET/POST /esqueci-senha`, `GET/POST /redefinir-senha/<token>` | Recuperação de senha |

### Estrutura de pastas

```
lojalead-saas/
  run.py                     # entrypoint (python run.py)
  requirements.txt
  migrations/                # Flask-Migrate/Alembic: histórico de schema do banco
  app/
    __init__.py               # app factory, extensões, blueprints, CSRF, 404
    models.py                 # Tenant, TenantUser (+ reset de senha), Document
    tenant.py                 # landing, signup, storefront, esqueci/redefinir senha
    api.py                    # API REST genérica tipo-Firestore + auth + troca de senha
    password_reset.py         # geração/validação de token + envio de e-mail
    templates/
      landing.html, signup.html, storefront.html, login.html,
      forgot_password.html, reset_password.html, 404.html
      admin/                    # painel server-rendered: pedidos, clientes,
                                 # estatísticas, plano, SEO/domínio
      superadmin/                # login e painel da equipe LojaLead
    static/
      css/styles.css
      css/admin.css             # visual próprio do painel/superadmin (não usa
                                 # a cor do tema da loja)
      js/script.js               # original, com auth/db/upload/conta apontando para o backend local
      js/backend-client.js      # window.appBackend, 100% local, sem Firebase
  uploads/                    # imagens dos produtos, salvas em disco por loja (uploads/<slug>/...)
```

### Pedidos, clientes e WhatsApp (novo)
- Checkout de verdade: `POST /api/<slug>/checkout` cria `Customer` +
  `Order` no banco (não é mais só uma mensagem montada no navegador),
  calcula subtotal/frete/total, grava um `OrderStatusEvent` inicial e
  devolve a URL `wa.me` com a mensagem já formatada.
- No front, o botão "Finalizar Compra" abre um modal (nome, telefone,
  retirada/entrega, endereço se entrega, forma de pagamento opcional,
  observações) antes de enviar pro WhatsApp.
- Painel em `/loja/<slug>/painel/pedidos`: lista com filtro por status e
  busca por cliente/telefone; detalhe do pedido com itens, dados de
  entrega, mensagem enviada ao WhatsApp, troca de status e histórico
  completo (timeline).
- Painel de clientes em `/loja/<slug>/painel/clientes`: lista e detalhe
  com o histórico de pedidos de cada cliente (cliente é identificado por
  telefone dentro do tenant).

### Estatísticas (novo)
- `POST /api/<slug>/stats/track` registra eventos leves (`visit`,
  `product_view`, `cart_add`) disparados pelo `script.js` (visita à
  vitrine, abrir um produto, adicionar ao carrinho); pedidos concluídos
  no checkout também geram um evento `order`.
- Painel em `/loja/<slug>/painel/estatisticas`: contadores dos últimos 14
  dias (visitas, produtos vistos, itens no carrinho, pedidos), gráfico de
  barras simples por dia e produtos mais vistos.

### Planos, assinatura e superadmin (novo)
- Modelos `Plan` (código, nome, preço, limites de produtos/pedidos) e
  `Subscription` (loja → plano + status: trial/active/past_due/canceled).
  **Não há integração de gateway de pagamento** — é só o registro interno
  de billing que o superadmin atualiza manualmente (ou uma integração
  futura poderia atualizar via webhook).
- Painel da loja em `/loja/<slug>/painel/plano`: mostra o plano/status
  atual e os planos disponíveis (somente leitura).
- Painel da equipe LojaLead em `/superadmin` (login próprio, modelo
  `SuperAdmin`, criado via `flask create-superadmin`): visão geral,
  lista/detalhe de lojas (ativar/desativar, atribuir plano e status de
  assinatura), CRUD simples de planos.

### SEO e domínio (novo)
- Cada loja tem `seo_title`, `seo_description`, `seo_keywords`,
  `seo_og_image` (editáveis em `/loja/<slug>/painel/seo`), renderizados
  no `<head>` da vitrine no servidor (título, meta description/keywords,
  Open Graph, canonical) — não depende de JS rodar para o crawler ver.
- `sitemap.xml` e `robots.txt` por loja (`/loja/<slug>/sitemap.xml` e
  `/loja/<slug>/robots.txt`), listando a home e cada produto.
- **Subdomínio automático**: com `BASE_DOMAIN=seudominio.com` configurado,
  `<slug>.seudominio.com` serve a vitrine direto na raiz, sem precisar de
  `/loja/<slug>`.
- **Domínio próprio**: cada loja pode cadastrar um domínio customizado
  (ex: `minhaloja.com.br`) no painel de SEO; basta apontar o DNS do
  domínio do cliente para este servidor. Resolvido por um
  `before_request` que casa `request.host` com `Tenant.custom_domain`.

## Funcionalidades

### Conta e segurança
- Cadastro de loja com slug único, autenticação isolada por tenant (sessão
  via cookie). Cada loja tem um único usuário administrador (removido o
  suporte a múltiplos admins por loja — complexidade desnecessária para a
  fase inicial do projeto).
- **Recuperação de senha** ("esqueci minha senha"): link de uso único,
  válido por 1 hora, hash do token no banco. Envio por e-mail via SMTP puro
  se `MAIL_*` estiver configurado; senão o link aparece na tela/console.
- **Trocar senha de dentro do painel** (Configurações > Minha Conta).
- Proteção CSRF (Flask-WTF) nos formulários HTML clássicos; a API JSON usa
  `SESSION_COOKIE_SAMESITE=Lax` em vez de token CSRF.
- Migrations versionadas via Flask-Migrate/Alembic (`flask db migrate` /
  `flask db upgrade` / `flask db downgrade`).
- Página 404 amigável.

### Modo de exibição do catálogo
A loja pode escolher como os produtos aparecem na vitrine, em
Configurações > Catálogo — isso é puramente visual e não depende de
tipo/segmento de negócio, então qualquer loja pode trocar livremente.

Modos disponíveis: **Grade** (cards, padrão), **Lista** (uma linha por
item), **Cardápio** (destaque para descrição) e **Compacto** (cards
menores, mais itens visíveis por tela). A troca é aplicada com
pré-visualização em tempo real (`catalogLayout` em `settings/system`).

### Configurações da loja (painel admin > Configurações)
Tudo abaixo fica salvo em `settings/system` (ou `settings/theme` para o
tema), sem precisar de migração de banco — é armazenamento de documento
livre (JSON).

- **Geral**: nome, slogan, descrição, moeda, fuso horário.
- **Banner de aviso no topo**: liga/desliga + texto livre (ex.: "Frete
  grátis acima de R$100"), exibido acima do cabeçalho da loja.
- **Banner principal (hero)**: título, subtítulo, texto do botão, e agora
  também **imagem de fundo customizada** (upload próprio, some se você
  remover — volta para a cor do tema).
- **Tema**: seleção entre os temas prontos, modo escuro, e agora também
  **cor personalizada** (toggle "Usar cor personalizada" + seletor de cor
  primária/secundária, que sobrepõe o tema escolhido).
- **Catálogo**: ver seção "Modo de exibição do catálogo" acima.
- **Contato**: WhatsApp, e-mail, telefone, endereço, mapa (iframe do Google
  Maps).
- **Rodapé**: copyright, horário de funcionamento, Facebook, Instagram e
  agora também **TikTok e YouTube**.
- **Exibição**: status de estoque, marca, botão "Ver Produto", sidebar de
  categorias, busca, carrinho, colunas desktop/mobile, itens por página, e
  agora também **ordenação padrão do catálogo** (relevância / menor preço /
  maior preço / mais recentes / nome A-Z).
- **Frete Grátis**: toggle liga/desliga (já existia) + **valor mínimo de
  compra** (novo) — quando configurado, o carrinho mostra "Faltam R$X para
  Frete Grátis" e depois "Você ganhou Frete Grátis!" conforme o cliente
  adiciona itens.
- **Backup e Exportação**: exportar produtos, frequência de backup.

## O que já está pronto e testado

- [x] Estrutura Flask (app factory, blueprints, SQLAlchemy, Flask-Login).
- [x] Cadastro de lojas, autenticação isolada por tenant, API genérica
      tipo-Firestore com isolamento multi-tenant confirmado por teste.
- [x] Shim JS completo (auth + firestore + `serverTimestamp`).
- [x] Vitrine servindo o front original quase intacto.
- [x] Recuperação de senha, troca de senha no painel, 404 amigável, CSRF,
      migrations de banco — todos testados via `test_client` do Flask
      (signup → storefront → login/logout → CRUD → isolamento entre lojas).
- [x] Modo de exibição do catálogo (grade, lista, cardápio, compacto) —
      independente de segmento/tipo de negócio.
- [x] **Nesta rodada**: banner de aviso no topo, ordenação padrão do
      catálogo, valor mínimo para Frete Grátis (com indicador no
      carrinho), redes sociais extras no rodapé (TikTok/YouTube), imagem de
      fundo customizada do banner (upload), cor personalizada além dos
      temas prontos. Testado via `test_client`: signup → storefront renderiza
      todos os novos campos → login → `PATCH /api/<slug>/docs/settings/system`
      persiste e retorna corretamente todos os novos campos.
- [x] **Nesta rodada (pedidos/clientes/estatísticas/planos/superadmin/SEO/domínio)**:
      testado ponta-a-ponta via `test_client` com banco SQLite limpo:
      - `POST /api/<slug>/checkout` cria `Customer`+`Order`, calcula
        subtotal/frete/total, mensagem de WhatsApp formatada corretamente
        (conferido o texto gerado linha a linha).
      - Painel de pedidos: lista, detalhe, troca de status (grava
        `OrderStatusEvent`) — todas as rotas retornam 200.
      - Painel de clientes: lista e detalhe retornam 200.
      - `POST /api/<slug>/stats/track` grava evento; painel de
        estatísticas (`/painel/estatisticas`) retorna 200.
      - Painel de plano (`/painel/plano`) e SEO (`/painel/seo`) retornam 200.
      - Superadmin: login, dashboard, lista de lojas, atualizar
        assinatura de uma loja, ativar/desativar loja, criar plano — todas
        as rotas testadas e retornando 200/302 conforme esperado; acesso
        sem login redireciona para `/superadmin/login` (confirmado).
      - Subdomínio (`<slug>.BASE_DOMAIN`) e domínio próprio
        (`Tenant.custom_domain`) testados via `Host` header simulado: ambos
        servem a vitrine correta na raiz `/`; um host desconhecido continua
        caindo na landing page genérica.
      - `<title>`/meta description/OG tags no `<head>` da vitrine
        confirmados no HTML retornado.
      - Migração Alembic gerada e aplicada sem erros
        (`d34c66eb0600_pedidos_clientes_planos_assinaturas_...py`).
      - **Não testado por falta de browser real**: o modal de checkout no
        front (`storefront.html`/`script.js`) foi revisado por leitura de
        código e validado por `node -c` (sintaxe), mas o clique real no
        botão "Finalizar Compra" → preencher modal → abrir WhatsApp não foi
        clicado numa tela de verdade.

## O que falta (para a próxima IA / desenvolvedor continuar)

### Prioridade alta
1. **Testar clicando na UI de verdade, num navegador real.** Sem acesso a
   um browser neste ambiente, a verificação desta rodada foi feita por
   auditoria de código + simulação via `test_client`/API, não por clique
   real. Já confirmado por esse caminho (então o risco aqui é menor do que
   parece, mas ainda não é 100%):
   - Upload → salvar como imagem de fundo do banner → trocar por outra →
     apagar: simulado ponta-a-ponta via API (`POST /upload` →
     `PATCH settings/system` → `DELETE /upload/<arquivo>` → confirma 404
     depois de apagado). O que **não** foi possível verificar é o
     `FileReader`/preview no `<input type="file">` em si, que só existe no
     browser.
   - Cor personalizada vs. troca de tema: **não há conflito** —
     `applyTheme` só mexe em `classList` (`theme-*`), nunca em
     `.style`, e `applyCustomColor` seta `--primary`/`--secondary` via
     `style.setProperty` (inline), que tem prioridade sobre a classe CSS
     independentemente da ordem de execução. Revisado no código, não
     precisa retestar essa parte.
   - `fa-tiktok` e `fa-youtube` **confirmados existentes** no Font Awesome
     Free 6.4.0 (brands) via busca — não é preciso trocar ícone.
   - Ainda faltam ver na tela mesmo (não dá pra confirmar só por código):
     alinhamento/visual do banner de aviso no topo, do indicador de Frete
     Grátis no carrinho, e do color picker na aba Tema.
2. **CSS do modo escuro**: `.top-announcement-banner` e
   `.free-shipping-progress` usam `var(--primary)`/`var(--input-bg)` (já
   existentes no sistema de temas), mas não foram vistas visualmente no
   modo escuro nem nos temas mais claros/escuros — só a variável foi
   conferida no CSS, não o resultado renderizado.

### Prioridade média
3. **Clicar de verdade em navegador** no modal de checkout novo (nome,
   telefone, retirada/entrega, endereço) e no painel de pedidos/clientes/
   estatísticas/SEO/superadmin — tudo foi validado por `test_client` e
   leitura de código, não por clique real numa tela.
4. Área "minha conta" fora da loja, unificando várias lojas do mesmo dono
   (hoje cada login é 1 loja).

### Prioridade baixa / evolução do SaaS
5. **Cobrança real**: `Plan`/`Subscription` existem e o superadmin já
   consegue atribuir plano/status manualmente, mas não há gateway de
   pagamento (Stripe, Mercado Pago, etc.) integrado — é só o registro
   interno.
6. **Rate limiting / proteção de força bruta** no login, "esqueci minha
   senha", troca de senha e no checkout público.
7. **Rodar em produção com Docker/HTTPS de verdade** (ex.: em nuvem gerenciada
   com terminação TLS própria, ou revisar renovação de certificado sob carga
   real) — o `Dockerfile`/`docker-compose.yml`/`Caddyfile` deste repositório
   cobrem o caso comum (um servidor, IP fixo, portas 80/443 livres), ver
   seção "Deploy com HTTPS automático" abaixo, mas não foram testados sob
   tráfego real nem em outro tipo de hospedagem.
8. Múltiplas imagens no banner (carrossel) em vez de uma única imagem de
   fundo.
9. Favicon customizado por loja.
10. Múltiplos administradores por loja ("Equipe") foi removido por decisão
    do dono do projeto — complexidade desnecessária para a fase inicial.
    Cada loja tem só um usuário admin agora. Se algum dia for
    reintroduzido: banco (`TenantUser`) já suporta N usuários por
    `tenant_id` sem mudança de schema — só falta recriar as rotas de
    CRUD em `api.py` (listar/adicionar/remover membro) e a aba/modal
    correspondente no front.
11. `StatEvent` grava uma linha por evento sem expiração — para lojas com
    muito tráfego, vale rodar uma limpeza periódica dos eventos antigos
    (ex.: manter só os últimos 90 dias).
12. O painel de pedidos/clientes/estatísticas/SEO é server-rendered
    (Jinja), separado da SPA principal em `storefront.html`. Foi uma
    escolha deliberada para reduzir risco de mexer nos ~3700 linhas de
    `script.js` já existentes; se quiser integrar tudo numa SPA só, dá
    para migrar depois reaproveitando as rotas/JSON já prontos.

